# -*- coding: utf-8 -*-
from django.db import models
from django.contrib.auth.models import User
from django.utils.translation import gettext_lazy as _
from django.utils import timezone
import uuid

from organizations.models import Organization
from .event import Event


class EventPoll(models.Model):
    """
    Modèle pour les sondages de planification d'événements.
    Permet la création de sondages pour déterminer les meilleures dates pour un événement.
    """
    POLL_STATUS_CHOICES = [
        ('active', _('Actif')),
        ('closed', _('Clôturé')),
        ('finalized', _('Finalisé')),  # Quand une date a été choisie
        ('cancelled', _('Annulé')),
    ]

    RESPONSE_TYPE_CHOICES = [
        ('yes_no', _('Oui/Non')),
        ('yes_maybe_no', _('Oui/Peut-être/Non')),
        ('availability', _('Disponibilité (matin/après-midi/soir)')),
    ]

    # Information de base
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    title = models.CharField(_('Titre'), max_length=200)
    description = models.TextField(_('Description'), blank=True)
    
    # Relation avec l'événement (optionnel, car un sondage peut exister avant la création de l'événement)
    event = models.OneToOneField(
        Event, 
        on_delete=models.SET_NULL, 
        null=True, 
        blank=True, 
        related_name='poll',
        verbose_name=_('Événement associé')
    )
    
    # Organisation propriétaire du sondage
    organization = models.ForeignKey(
        Organization,
        on_delete=models.CASCADE,
        related_name='event_polls',
        verbose_name=_('Organisation')
    )
    
    # Paramètres du sondage
    status = models.CharField(_('Statut'), max_length=20, choices=POLL_STATUS_CHOICES, default='active')
    response_type = models.CharField(
        _('Type de réponse'), 
        max_length=20, 
        choices=RESPONSE_TYPE_CHOICES, 
        default='yes_maybe_no'
    )
    allow_comments = models.BooleanField(_('Autoriser les commentaires'), default=True)
    allow_multiple_votes = models.BooleanField(_('Autoriser votes multiples'), default=False)
    show_participants = models.BooleanField(_('Afficher les participants'), default=True)
    show_vote_counts = models.BooleanField(_('Afficher les décomptes de votes'), default=True)
    
    # Dates limites
    created_at = models.DateTimeField(_('Créé le'), auto_now_add=True)
    updated_at = models.DateTimeField(_('Mis à jour le'), auto_now=True)
    expires_at = models.DateTimeField(_('Expire le'), null=True, blank=True)
    finalized_at = models.DateTimeField(_('Finalisé le'), null=True, blank=True)
    
    # Créateur et gestionnaire
    created_by = models.ForeignKey(
        User, 
        on_delete=models.SET_NULL, 
        null=True, 
        related_name='created_polls',
        verbose_name=_('Créé par')
    )
    
    # Options avancées stockées en JSON
    settings = models.JSONField(_('Paramètres avancés'), default=dict, blank=True)
    
    # Type d'événement envisagé (pour les sondages avant création d'événement)
    event_type = models.CharField(
        _("Type d'événement"), 
        max_length=20, 
        choices=Event.TYPE_CHOICES,
        null=True,
        blank=True
    )
    
    # URL de partage unique
    share_url_code = models.CharField(_('Code URL de partage'), max_length=20, unique=True, blank=True)
    
    class Meta:
        verbose_name = _('Sondage d\'événement')
        verbose_name_plural = _('Sondages d\'événements')
        ordering = ['-created_at']
    
    def __str__(self):
        return self.title
    
    def save(self, *args, **kwargs):
        # Générer un code URL de partage s'il n'existe pas
        if not self.share_url_code:
            self.share_url_code = str(uuid.uuid4())[:8]
        super().save(*args, **kwargs)
    
    @property
    def is_active(self):
        """Vérifie si le sondage est actif."""
        if self.status != 'active':
            return False
        if self.expires_at and self.expires_at < timezone.now():
            return False
        return True
    
    @property
    def total_responses(self):
        """Retourne le nombre total de réponses au sondage."""
        return PollResponse.objects.filter(
            option__poll=self
        ).distinct('user').count()
    
    @property
    def selected_option(self):
        """Retourne l'option qui a été sélectionnée pour l'événement."""
        if self.status == 'finalized':
            return self.options.filter(is_selected=True).first()
        return None
    
    def finalize_with_option(self, option):
        """Finalise le sondage avec l'option choisie et crée/met à jour l'événement."""
        if not isinstance(option, PollOption) or option.poll != self:
            raise ValueError(_("Option de sondage invalide"))
        
        with models.transaction.atomic():
            # Marquer l'option comme sélectionnée
            option.is_selected = True
            option.save()
            
            # Mettre à jour le statut du sondage
            self.status = 'finalized'
            self.finalized_at = timezone.now()
            
            # Créer ou mettre à jour l'événement
            if self.event:
                # Mettre à jour l'événement existant
                self.event.start_date = option.date
                self.event.end_date = option.date  # Par défaut même jour
                if option.start_time:
                    self.event.start_time = option.start_time
                if option.end_time:
                    self.event.end_time = option.end_time
                self.event.save()
            else:
                # Créer un nouvel événement
                event = Event(
                    title=self.title,
                    description=self.description,
                    event_type=self.event_type or 'other',
                    organization=self.organization,
                    start_date=option.date,
                    end_date=option.date,
                    start_time=option.start_time,
                    end_time=option.end_time,
                    created_by=self.created_by
                )
                event.save()
                self.event = event
            
            self.save()
            
            # Créer des statistiques sur les réponses
            self.create_statistics()
            
            return self.event
    
    def create_statistics(self):
        """Crée des statistiques sur les réponses au sondage."""
        if not hasattr(self, 'statistics'):
            stats = EventStatistics(
                poll=self,
                total_participants=self.total_responses,
                response_data=self.get_response_stats()
            )
            stats.save()
        else:
            self.statistics.total_participants = self.total_responses
            self.statistics.response_data = self.get_response_stats()
            self.statistics.updated_at = timezone.now()
            self.statistics.save()
    
    def get_response_stats(self):
        """Calcule des statistiques sur les réponses."""
        stats = {}
        options = self.options.all()
        
        for option in options:
            option_stats = {
                'date': option.date.isoformat(),
                'option_id': str(option.id),
                'total_responses': option.responses.count(),
                'responses': {
                    'yes': option.responses.filter(response='yes').count(),
                    'maybe': option.responses.filter(response='maybe').count(),
                    'no': option.responses.filter(response='no').count(),
                },
                'is_selected': option.is_selected,
            }
            
            if option.start_time:
                option_stats['start_time'] = option.start_time.isoformat()
            if option.end_time:
                option_stats['end_time'] = option.end_time.isoformat()
                
            stats[str(option.id)] = option_stats
            
        return stats


class PollOption(models.Model):
    """
    Options de date/heure pour un sondage d'événement.
    """
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    poll = models.ForeignKey(
        EventPoll, 
        on_delete=models.CASCADE, 
        related_name='options',
        verbose_name=_('Sondage')
    )
    
    # Date et plage horaire
    date = models.DateField(_('Date'))
    start_time = models.TimeField(_('Heure de début'), null=True, blank=True)
    end_time = models.TimeField(_('Heure de fin'), null=True, blank=True)
    all_day = models.BooleanField(_('Toute la journée'), default=False)
    
    # Priorité d'affichage
    order = models.PositiveSmallIntegerField(_('Ordre'), default=0)
    
    # Indique si cette option a été sélectionnée comme date finale
    is_selected = models.BooleanField(_('Sélectionnée'), default=False)
    
    # Lieu spécifique (si différent pour chaque option)
    location = models.CharField(_('Lieu'), max_length=200, blank=True)
    
    # Métadonnées
    created_at = models.DateTimeField(_('Créé le'), auto_now_add=True)
    
    class Meta:
        verbose_name = _('Option de sondage')
        verbose_name_plural = _('Options de sondage')
        ordering = ['date', 'start_time', 'order']
        unique_together = [['poll', 'date', 'start_time']]
    
    def __str__(self):
        if self.all_day:
            return f"{self.date.strftime('%d/%m/%Y')} ({_('Toute la journée')})"
        elif self.start_time and self.end_time:
            return f"{self.date.strftime('%d/%m/%Y')} {self.start_time.strftime('%H:%M')} - {self.end_time.strftime('%H:%M')}"
        elif self.start_time:
            return f"{self.date.strftime('%d/%m/%Y')} {self.start_time.strftime('%H:%M')}"
        else:
            return f"{self.date.strftime('%d/%m/%Y')}"
    
    @property
    def yes_count(self):
        """Nombre de réponses 'Oui'."""
        return self.responses.filter(response='yes').count()
    
    @property
    def maybe_count(self):
        """Nombre de réponses 'Peut-être'."""
        return self.responses.filter(response='maybe').count()
    
    @property
    def no_count(self):
        """Nombre de réponses 'Non'."""
        return self.responses.filter(response='no').count()
    
    @property
    def total_responses(self):
        """Nombre total de réponses."""
        return self.responses.count()
    
    @property
    def score(self):
        """Score calculé pour cette option (pour trier par popularité)."""
        # On attribue 2 points pour chaque "oui", 1 point pour chaque "peut-être"
        return (self.yes_count * 2) + self.maybe_count


class PollResponse(models.Model):
    """
    Réponses des utilisateurs aux options du sondage.
    """
    RESPONSE_CHOICES = [
        ('yes', _('Oui')),
        ('maybe', _('Peut-être')),
        ('no', _('Non')),
    ]
    
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    option = models.ForeignKey(
        PollOption, 
        on_delete=models.CASCADE, 
        related_name='responses',
        verbose_name=_('Option')
    )
    user = models.ForeignKey(
        User, 
        on_delete=models.CASCADE, 
        related_name='poll_responses',
        verbose_name=_('Utilisateur')
    )
    
    # Réponse
    response = models.CharField(_('Réponse'), max_length=10, choices=RESPONSE_CHOICES)
    comment = models.TextField(_('Commentaire'), blank=True)
    
    # Métadonnées
    created_at = models.DateTimeField(_('Créé le'), auto_now_add=True)
    updated_at = models.DateTimeField(_('Mis à jour le'), auto_now=True)
    
    # Pour l'anonymat (si activé dans les paramètres du sondage)
    is_anonymous = models.BooleanField(_('Anonyme'), default=False)
    
    class Meta:
        verbose_name = _('Réponse au sondage')
        verbose_name_plural = _('Réponses aux sondages')
        ordering = ['-created_at']
        unique_together = [['option', 'user']]
    
    def __str__(self):
        if self.is_anonymous:
            return f"{_('Utilisateur anonyme')} - {self.option} - {self.get_response_display()}"
        return f"{self.user.get_full_name() or self.user.username} - {self.option} - {self.get_response_display()}"


class EventReminder(models.Model):
    """
    Rappels programmables pour les événements.
    """
    REMINDER_TYPE_CHOICES = [
        ('email', _('Email')),
        ('sms', _('SMS')),
        ('notification', _('Notification in-app')),
        ('all', _('Tous')),
    ]
    
    # Options pour l'envoi à des groupes spécifiques
    SEND_TO_CHOICES = [
        ('all', _('Tous les participants')),
        ('registered', _('Inscrits seulement')),
        ('confirmed', _('Confirmés seulement')),
        ('not_confirmed', _('Non confirmés')),
        ('custom', _('Liste personnalisée')),
    ]
    
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    
    # Événement associé au rappel
    event = models.ForeignKey(
        Event, 
        on_delete=models.CASCADE, 
        related_name='reminders',
        verbose_name=_('Événement')
    )
    
    # Configuration du rappel
    title = models.CharField(_('Titre'), max_length=200)
    message = models.TextField(_('Message'))
    reminder_type = models.CharField(
        _('Type de rappel'), 
        max_length=20, 
        choices=REMINDER_TYPE_CHOICES, 
        default='notification'
    )
    
    # Timing du rappel
    time_before_event = models.DurationField(
        _('Temps avant l\'événement'),
        help_text=_('Durée avant l\'événement pour envoyer le rappel (ex: 1 jour, 2 heures)')
    )
    send_at = models.DateTimeField(
        _('Envoyer à'), 
        null=True, 
        blank=True,
        help_text=_('Date et heure exactes pour envoyer le rappel (prioritaire sur "temps avant")')
    )
    
    # État du rappel
    is_sent = models.BooleanField(_('Envoyé'), default=False)
    sent_at = models.DateTimeField(_('Envoyé le'), null=True, blank=True)
    is_enabled = models.BooleanField(_('Activé'), default=True)
    
    # Pour spécifier le groupe de destinataires
    send_to = models.CharField(_('Envoyer à'), max_length=20, choices=SEND_TO_CHOICES, default='all')
    
    # Résultats d'envoi
    delivery_status = models.JSONField(_('Statut de livraison'), default=dict, blank=True)
    open_rate = models.FloatField(_('Taux d\'ouverture'), null=True, blank=True)
    
    # Destinataires
    recipients = models.ManyToManyField(
        User, 
        related_name='event_reminders',
        verbose_name=_('Destinataires'),
        blank=True,
        help_text=_('Destinataires spécifiques (vide = tous les participants)')
    )
    
    # Métadonnées
    created_at = models.DateTimeField(_('Créé le'), auto_now_add=True)
    updated_at = models.DateTimeField(_('Mis à jour le'), auto_now=True)
    created_by = models.ForeignKey(
        User, 
        on_delete=models.SET_NULL, 
        null=True, 
        related_name='created_reminders',
        verbose_name=_('Créé par')
    )
    
    # Options avancées
    settings = models.JSONField(_('Paramètres avancés'), default=dict, blank=True)
    
    class Meta:
        verbose_name = _('Rappel d\'événement')
        verbose_name_plural = _('Rappels d\'événements')
        ordering = ['event', 'send_at']
    
    def __str__(self):
        return f"{self.title} - {self.event.title}"
    
    @property
    def is_scheduled(self):
        """Vérifie si le rappel est programmé et pas encore envoyé."""
        return self.is_enabled and not self.is_sent
        
    @property
    def is_due(self):
        """Vérifie si le rappel est dû pour être envoyé."""
        if self.is_sent or not self.is_enabled:
            return False
            
        now = timezone.now()
        send_time = self.calculated_send_time
        return send_time and now >= send_time
    
    @property
    def calculated_send_time(self):
        """Calcule le moment d'envoi prévu pour le rappel."""
        if self.send_at:
            return self.send_at
        
        if self.event.start_time:
            event_datetime = timezone.make_aware(
                timezone.datetime.combine(self.event.start_date, self.event.start_time)
            )
        else:
            # Par défaut, on considère que l'événement commence à 9h du matin
            event_datetime = timezone.make_aware(
                timezone.datetime.combine(self.event.start_date, timezone.datetime.time(9, 0))
            )
        
        return event_datetime - self.time_before_event
    
    def mark_as_sent(self):
        """Marque le rappel comme envoyé."""
        self.is_sent = True
        self.sent_at = timezone.now()
        self.save()
    
    def get_recipient_list(self):
        """Obtient la liste des destinataires."""
        if self.recipients.exists():
            return self.recipients.all()
        
        # Filtrer selon l'option send_to
        if self.send_to == 'all':
            return User.objects.filter(
                event_participations__event=self.event
            ).distinct()
        elif self.send_to == 'registered':
            return User.objects.filter(
                event_participations__event=self.event,
                event_participations__status='registered'
            ).distinct()
        elif self.send_to == 'confirmed':
            return User.objects.filter(
                event_participations__event=self.event,
                event_participations__status='confirmed'
            ).distinct()
        elif self.send_to == 'not_confirmed':
            return User.objects.filter(
                event_participations__event=self.event,
                event_participations__status='registered'
            ).exclude(
                event_participations__status='confirmed'
            ).distinct()
        
        # Par défaut: tous les participants enregistrés ou confirmés
        return User.objects.filter(
            event_participations__event=self.event,
            event_participations__status__in=['registered', 'confirmed']
        ).distinct()


class EventStatistics(models.Model):
    """
    Statistiques sur les événements et les sondages.
    """
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    
    # Associations
    event = models.OneToOneField(
        Event, 
        on_delete=models.CASCADE, 
        related_name='statistics',
        verbose_name=_('Événement'),
        null=True,
        blank=True
    )
    poll = models.OneToOneField(
        EventPoll, 
        on_delete=models.CASCADE, 
        related_name='statistics',
        verbose_name=_('Sondage'),
        null=True,
        blank=True
    )
    
    # Données statistiques
    total_participants = models.PositiveIntegerField(_('Nombre total de participants'), default=0)
    response_rate = models.FloatField(_('Taux de réponse'), null=True, blank=True)
    
    # Données détaillées stockées en JSON
    response_data = models.JSONField(_('Données de réponse'), default=dict)
    participation_data = models.JSONField(_('Données de participation'), default=dict, blank=True)
    
    # Analyse temporelle
    first_response_at = models.DateTimeField(_('Première réponse à'), null=True, blank=True)
    last_response_at = models.DateTimeField(_('Dernière réponse à'), null=True, blank=True)
    median_response_time = models.DurationField(_('Temps de réponse médian'), null=True, blank=True)
    
    # Métadonnées
    created_at = models.DateTimeField(_('Créé le'), auto_now_add=True)
    updated_at = models.DateTimeField(_('Mis à jour le'), auto_now=True)
    
    class Meta:
        verbose_name = _('Statistiques d\'événement')
        verbose_name_plural = _('Statistiques d\'événements')
    
    def __str__(self):
        if self.event:
            return f"Stats: {self.event.title}"
        elif self.poll:
            return f"Stats de sondage: {self.poll.title}"
        return f"Stats #{self.id}"
    
    @property
    def has_event_data(self):
        """Vérifie si les statistiques concernent un événement finalisé."""
        return self.event is not None
    
    @property
    def has_poll_data(self):
        """Vérifie si les statistiques concernent un sondage."""
        return self.poll is not None
    
    def update_from_event(self, event):
        """Met à jour les statistiques à partir d'un événement."""
        if not event:
            return
        
        self.event = event
        self.total_participants = event.participants.count()
        
        # Collecter les données de participation
        participation_data = {
            'status_counts': {
                'registered': event.participants.filter(status='registered').count(),
                'confirmed': event.participants.filter(status='confirmed').count(),
                'waitlist': event.participants.filter(status='waitlist').count(),
                'cancelled': event.participants.filter(status='cancelled').count(),
            },
            'attended_count': event.participants.filter(attended=True).count(),
            'payment_status': {
                'pending': event.participants.filter(payment_status='pending').count(),
                'paid': event.participants.filter(payment_status='paid').count(),
                'refunded': event.participants.filter(payment_status='refunded').count(),
            }
        }
        
        self.participation_data = participation_data
        self.updated_at = timezone.now()
        self.save()
    
    def get_popular_dates(self, limit=3):
        """Retourne les dates les plus populaires d'un sondage."""
        if not self.poll:
            return []
        
        popular_options = []
        for option_id, data in self.response_data.items():
            option_data = {
                'id': option_id,
                'date': data.get('date'),
                'start_time': data.get('start_time'),
                'end_time': data.get('end_time'),
                'yes_count': data.get('responses', {}).get('yes', 0),
                'maybe_count': data.get('responses', {}).get('maybe', 0),
                'total_responses': data.get('total_responses', 0),
                'score': (data.get('responses', {}).get('yes', 0) * 2) + 
                         data.get('responses', {}).get('maybe', 0)
            }
            popular_options.append(option_data)
        
        # Trier par score décroissant
        popular_options.sort(key=lambda x: x['score'], reverse=True)
        
        return popular_options[:limit]


class PollQuestion(models.Model):
    """
    Questions personnalisées pour les sondages.
    Permet d'ajouter des questions supplémentaires au-delà des disponibilités.
    """
    QUESTION_TYPE_CHOICES = [
        ('text', _('Texte libre')),
        ('choice', _('Choix multiple')),
        ('rating', _('Notation (1-5)')),
        ('yes_no', _('Oui/Non')),
        ('date', _('Date')),
        ('time', _('Heure')),
        ('number', _('Nombre')),
    ]
    
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    poll = models.ForeignKey(
        EventPoll,
        on_delete=models.CASCADE,
        related_name='custom_questions',
        verbose_name=_('Sondage')
    )
    
    # Question
    question_text = models.CharField(_('Question'), max_length=500)
    question_type = models.CharField(
        _('Type de question'),
        max_length=20,
        choices=QUESTION_TYPE_CHOICES,
        default='text'
    )
    
    # Options pour les questions à choix multiple
    choices = models.JSONField(
        _('Choix disponibles'),
        default=list,
        blank=True,
        help_text=_('Liste des options pour les questions à choix multiple')
    )
    
    # Configuration
    is_required = models.BooleanField(_('Obligatoire'), default=False)
    order = models.PositiveIntegerField(_('Ordre'), default=1)
    help_text = models.CharField(_('Texte d\'aide'), max_length=200, blank=True)
    
    # Métadonnées
    created_at = models.DateTimeField(_('Créé le'), auto_now_add=True)
    
    class Meta:
        verbose_name = _('Question personnalisée')
        verbose_name_plural = _('Questions personnalisées')
        ordering = ['order', 'created_at']
        unique_together = [['poll', 'order']]
    
    def __str__(self):
        return f"{self.poll.title} - {self.question_text[:50]}"


class PollQuestionResponse(models.Model):
    """
    Réponses aux questions personnalisées des sondages.
    """
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    question = models.ForeignKey(
        PollQuestion,
        on_delete=models.CASCADE,
        related_name='responses',
        verbose_name=_('Question')
    )
    user = models.ForeignKey(
        User,
        on_delete=models.CASCADE,
        related_name='poll_question_responses',
        verbose_name=_('Utilisateur')
    )
    
    # Réponse (format flexible pour différents types)
    response_text = models.TextField(_('Réponse texte'), blank=True)
    response_number = models.FloatField(_('Réponse numérique'), null=True, blank=True)
    response_date = models.DateField(_('Réponse date'), null=True, blank=True)
    response_time = models.TimeField(_('Réponse heure'), null=True, blank=True)
    response_choice = models.CharField(_('Choix sélectionné'), max_length=200, blank=True)
    
    # Métadonnées
    created_at = models.DateTimeField(_('Créé le'), auto_now_add=True)
    updated_at = models.DateTimeField(_('Mis à jour le'), auto_now=True)
    
    class Meta:
        verbose_name = _('Réponse à une question')
        verbose_name_plural = _('Réponses aux questions')
        ordering = ['-created_at']
        unique_together = [['question', 'user']]
    
    def __str__(self):
        response = self.response_text or str(self.response_number) or str(self.response_date) or str(self.response_time) or self.response_choice
        return f"{self.user.username} - {self.question.question_text[:30]} - {response[:30]}"
    
    def get_response_value(self):
        """Retourne la valeur de la réponse selon le type de question."""
        if self.response_text:
            return self.response_text
        elif self.response_number is not None:
            return self.response_number
        elif self.response_date:
            return self.response_date
        elif self.response_time:
            return self.response_time
        elif self.response_choice:
            return self.response_choice
        return None