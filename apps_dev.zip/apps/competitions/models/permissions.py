# competitions/models/permissions.py
from django.db import models
from django.utils.translation import gettext_lazy as _
from django.contrib.auth.models import User

# Import des modèles d'organisation
from organizations.models import Organization, OrganizationMember, OrganizationRole

class ClubRole(models.Model):
    """Définit des rôles personnalisés pour les utilisateurs au sein d'une organisation."""
    
    name = models.CharField(_("Nom"), max_length=100)
    organization = models.ForeignKey('organizations.Organization', on_delete=models.CASCADE, related_name='roles')
    description = models.TextField(_("Description"), blank=True)
    is_default = models.BooleanField(_("Rôle par défaut"), default=False)
    created_at = models.DateTimeField(_("Créé le"), auto_now_add=True)
    updated_at = models.DateTimeField(_("Mis à jour le"), auto_now=True)
    
    # Permissions au niveau de l'organisation
    can_manage_practitioners = models.BooleanField(_("Gérer les pratiquants"), default=False)
    can_manage_registrations = models.BooleanField(_("Gérer les inscriptions"), default=False)
    can_manage_competitions = models.BooleanField(_("Gérer les compétitions"), default=False)
    can_manage_judges = models.BooleanField(_("Gérer les juges"), default=False)
    can_manage_grades = models.BooleanField(_("Gérer les grades"), default=False)
    can_manage_roles = models.BooleanField(_("Gérer les rôles"), default=False)
    
    def __str__(self):
        return f"{self.name} ({self.organization.name})"
    
    class Meta:
        verbose_name = _("Rôle d'organisation")
        verbose_name_plural = _("Rôles d'organisation")
        unique_together = ['name', 'organization']  # Corrigé de 'club' à 'organization'


class UserClubRole(models.Model):
    """Associe un utilisateur à un ou plusieurs rôles dans une organisation."""
    
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='organizations')
    organization = models.ForeignKey('organizations.Organization', on_delete=models.CASCADE, related_name='user_roles')
    role = models.ForeignKey(ClubRole, on_delete=models.CASCADE, related_name='users')
    assigned_by = models.ForeignKey(
        User, 
        on_delete=models.SET_NULL, 
        null=True, 
        blank=True, 
        related_name='assigned_roles'
    )
    assigned_at = models.DateTimeField(_("Assigné le"), auto_now_add=True)
    is_active = models.BooleanField(_("Actif"), default=True)
    
    def __str__(self):
        return f"{self.user.username} - {self.role.name} ({self.organization.name})"  # Corrigé de 'club' à 'organization'
    
    class Meta:
        verbose_name = _("Rôle d'utilisateur")
        verbose_name_plural = _("Rôles d'utilisateur")
        unique_together = ['user', 'organization', 'role']  # Corrigé de 'club' à 'organization'