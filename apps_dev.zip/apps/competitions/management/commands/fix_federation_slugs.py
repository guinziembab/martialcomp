"""
Management command to fix Federation objects that have empty or None slug fields
"""
from django.core.management.base import BaseCommand
from django.utils.text import slugify
from django.db import models
from competitions.models import Federation

class Command(BaseCommand):
    help = 'Fix Federation objects that have empty or None slug fields'

    def handle(self, *args, **options):
        self.stdout.write("Checking Federation slug fields...")
        
        try:
            # Get all federations
            all_federations = Federation.objects.all()
            self.stdout.write(f"Found {all_federations.count()} total federations")
            
            # Find federations with empty or null slugs
            problematic_federations = all_federations.filter(
                models.Q(slug__isnull=True) | models.Q(slug='')
            )
            
            self.stdout.write(f"Found {problematic_federations.count()} federations with empty/null slugs")
            
            # List all federations to see current state
            self.stdout.write("\nCurrent federation slug states:")
            for federation in all_federations:
                self.stdout.write(
                    f"  ID: {federation.id}, Name: '{federation.name}', Slug: '{federation.slug}'"
                )
            
            # Fix each problematic federation
            fixed_count = 0
            for federation in problematic_federations:
                original_slug = slugify(federation.name)
                if not original_slug:
                    # If name is empty or only special characters, use 'federation-{id}'
                    original_slug = f'federation-{federation.id}'
                
                # Ensure uniqueness
                slug = original_slug
                counter = 1
                while Federation.objects.filter(slug=slug).exclude(id=federation.id).exists():
                    slug = f"{original_slug}-{counter}"
                    counter += 1
                
                # Update the federation without triggering save() method
                # to avoid any potential side effects
                Federation.objects.filter(id=federation.id).update(slug=slug)
                fixed_count += 1
                
                self.stdout.write(
                    f"Fixed federation '{federation.name}' (ID: {federation.id}) with slug '{slug}'"
                )
            
            self.stdout.write(
                self.style.SUCCESS(f'Successfully fixed {fixed_count} federation slugs')
            )
            
            # Verify all federations now have slugs
            remaining_problematic = Federation.objects.filter(
                models.Q(slug__isnull=True) | models.Q(slug='')
            ).count()
            
            if remaining_problematic == 0:
                self.stdout.write(
                    self.style.SUCCESS('All federations now have proper slug fields!')
                )
            else:
                self.stdout.write(
                    self.style.WARNING(f'{remaining_problematic} federations still have empty slugs')
                )
            
        except Exception as e:
            self.stdout.write(
                self.style.ERROR(f'Error fixing federation slugs: {e}')
            )
            import traceback
            traceback.print_exc()