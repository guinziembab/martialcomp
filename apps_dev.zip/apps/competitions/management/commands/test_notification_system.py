from django.core.management.base import BaseCommand
from django.contrib.auth.models import User
from competitions.models.notifications import Notification
from django.utils import timezone
from datetime import timedelta

class Command(BaseCommand):
    help = 'Teste le système de notifications avec différents types et expirations'

    def add_arguments(self, parser):
        parser.add_argument(
            '--user',
            type=str,
            help='Nom d\'utilisateur spécifique pour les tests'
        )
        parser.add_argument(
            '--expire-soon',
            action='store_true',
            help='Créer des notifications qui expirent bientôt (pour tester le nettoyage)'
        )

    def handle(self, *args, **options):
        """Teste le système de notifications"""
        
        self.stdout.write(self.style.SUCCESS("🧪 TEST DU SYSTÈME DE NOTIFICATIONS"))
        self.stdout.write("=" * 50)
        
        # Récupérer l'utilisateur
        if options['user']:
            try:
                user = User.objects.get(username=options['user'])
                users = [user]
                self.stdout.write(f"👤 Test pour l'utilisateur: {user.username}")
            except User.DoesNotExist:
                self.stdout.write(self.style.ERROR(f"❌ Utilisateur {options['user']} non trouvé"))
                return
        else:
            users = User.objects.filter(is_active=True)[:5]  # Limiter à 5 utilisateurs pour le test
            self.stdout.write(f"👥 Test pour {users.count()} utilisateurs")
        
        # Notifications de test avec différents types
        test_notifications = [
            {
                'title': 'Test - Notification info',
                'message': 'Ceci est une notification de type info pour tester le système.',
                'notification_type': 'info',
                'priority': 'standard',
                'expires_at': timezone.now() + timedelta(hours=1) if options['expire_soon'] else None
            },
            {
                'title': 'Test - Notification succès',
                'message': 'Ceci est une notification de type succès avec priorité importante.',
                'notification_type': 'success',
                'priority': 'important',
                'action_url': '/competitions/competitions/',
                'action_text': 'Voir les compétitions'
            },
            {
                'title': 'Test - Notification avertissement',
                'message': 'Ceci est une notification de type avertissement avec priorité critique.',
                'notification_type': 'warning',
                'priority': 'critical',
                'expires_at': timezone.now() + timedelta(minutes=30) if options['expire_soon'] else None
            },
            {
                'title': 'Test - Notification erreur',
                'message': 'Ceci est une notification de type erreur pour tester l\'affichage.',
                'notification_type': 'error',
                'priority': 'critical',
                'action_url': '/profile/',
                'action_text': 'Compléter le profil'
            },
            {
                'title': 'Test - Notification avec expiration',
                'message': 'Cette notification expire bientôt pour tester le système de nettoyage.',
                'notification_type': 'info',
                'priority': 'standard',
                'expires_at': timezone.now() + timedelta(minutes=5) if options['expire_soon'] else timezone.now() + timedelta(days=7)
            }
        ]
        
        total_created = 0
        
        for user in users:
            self.stdout.write(f"\n👤 Création de notifications pour: {user.username}")
            
            for i, notif_data in enumerate(test_notifications):
                # Créer la notification
                notification = Notification.objects.create(
                    user=user,
                    title=notif_data['title'],
                    message=notif_data['message'],
                    notification_type=notif_data['notification_type'],
                    priority=notif_data['priority'],
                    action_url=notif_data.get('action_url'),
                    action_text=notif_data.get('action_text'),
                    expires_at=notif_data.get('expires_at')
                )
                
                status = "⏰" if notification.expires_at else "✅"
                self.stdout.write(f"   {status} Notification {i+1}: {notification.title}")
                if notification.expires_at:
                    self.stdout.write(f"      Expire le: {notification.expires_at.strftime('%d/%m/%Y %H:%M')}")
                
                total_created += 1
        
        # Statistiques
        total_notifications = Notification.objects.count()
        unread_notifications = Notification.objects.filter(is_read=False).count()
        expired_notifications = Notification.objects.filter(expires_at__lt=timezone.now()).count()
        
        self.stdout.write(f"\n📊 STATISTIQUES DU TEST")
        self.stdout.write("=" * 50)
        self.stdout.write(f"📊 Notifications créées: {total_created}")
        self.stdout.write(f"👥 Utilisateurs testés: {len(users)}")
        self.stdout.write(f"📝 Notifications par utilisateur: {len(test_notifications)}")
        
        self.stdout.write(f"\n📈 STATISTIQUES GLOBALES")
        self.stdout.write(f"   Total notifications en base: {total_notifications}")
        self.stdout.write(f"   Notifications non lues: {unread_notifications}")
        self.stdout.write(f"   Notifications expirées: {expired_notifications}")
        
        if options['expire_soon']:
            self.stdout.write(self.style.WARNING(f"\n⚠️ ATTENTION: Certaines notifications expirent bientôt!"))
            self.stdout.write("🧹 Utilisez 'python manage.py cleanup_expired_notifications' pour les nettoyer")
        
        self.stdout.write(self.style.SUCCESS(f"\n✅ Test terminé avec succès!"))
        self.stdout.write("🔔 Le système de notifications est maintenant testable dans tous les dashboards.")
        self.stdout.write("🌐 Accédez à un dashboard pour voir la cloche avec badge dynamique.") 