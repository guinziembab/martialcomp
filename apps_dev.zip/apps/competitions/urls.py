from django.urls import path, include

from competitions.views.welcome import welcome
from competitions.views.auth import login_view, logout_view 
from competitions.views.csrf_views import refresh_csrf_token

app_name = 'competitions'

urlpatterns = [
    # Page d'accueil principale
    path('', welcome, name='welcome'),
    
    # URLs Dashboard
    path('dashboard/', include('competitions.urls.dashboard', namespace='dashboard')),
    
    # URLs pour le module de combat (général)
    path('combat/', include('competitions.urls.combat', namespace='combat')),
    
    # URLs pour la gestion CSRF
    path('csrf/refresh/', refresh_csrf_token, name='refresh_csrf'),
    
    # URL de déconnexion
    path('logout/', logout_view, name='logout'),
]