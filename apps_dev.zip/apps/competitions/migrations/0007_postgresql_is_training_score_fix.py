# Generated manually for PostgreSQL production fix

from django.db import migrations, models

def check_column_exists(apps, schema_editor):
    """Vérifie si la colonne existe déjà"""
    if schema_editor.connection.vendor != 'postgresql':
        return False
        
    with schema_editor.connection.cursor() as cursor:
        cursor.execute("""
            SELECT column_name
            FROM information_schema.columns 
            WHERE table_schema = 'public' 
            AND table_name = 'competitions_technicalscoreresult'
            AND column_name = 'is_training_score';
        """)
        return cursor.fetchone() is not None

def add_column_if_not_exists(apps, schema_editor):
    """Ajoute la colonne seulement si elle n'existe pas"""
    if schema_editor.connection.vendor != 'postgresql':
        return
        
    if not check_column_exists(apps, schema_editor):
        with schema_editor.connection.cursor() as cursor:
            cursor.execute("""
                ALTER TABLE competitions_technicalscoreresult 
                ADD COLUMN is_training_score boolean NOT NULL DEFAULT false;
            """)
            
            cursor.execute("""
                COMMENT ON COLUMN competitions_technicalscoreresult.is_training_score 
                IS 'Si True, le score est donné par un juge en formation et ne compte pas dans le résultat';
            """)
            print("✅ Colonne is_training_score ajoutée avec succès")
    else:
        print("ℹ️  Colonne is_training_score existe déjà")

def remove_column_if_exists(apps, schema_editor):
    """Supprime la colonne pour la migration inverse"""
    if schema_editor.connection.vendor != 'postgresql':
        return
        
    if check_column_exists(apps, schema_editor):
        with schema_editor.connection.cursor() as cursor:
            cursor.execute("""
                ALTER TABLE competitions_technicalscoreresult 
                DROP COLUMN IF EXISTS is_training_score;
            """)
            print("✅ Colonne is_training_score supprimée")

class Migration(migrations.Migration):

    dependencies = [
        ('competitions', '0006_add_is_training_score'),
    ]

    operations = [
        # Migration qui gère les deux cas: colonne existante ou non
        migrations.RunPython(
            add_column_if_not_exists,
            remove_column_if_exists,
        ),
        
        # Synchronisation de l'état Django (toujours nécessaire)
        migrations.RunSQL(
            "SELECT 1;",  # No-op SQL
            reverse_sql="SELECT 1;",
            state_operations=[
                migrations.AddField(
                    model_name='technicalscoreresult',
                    name='is_training_score',
                    field=models.BooleanField(
                        default=False, 
                        help_text='Si True, le score est donné par un juge en formation et ne compte pas dans le résultat', 
                        verbose_name="Score d'entraînement"
                    ),
                ),
            ]
        ),
    ]