# Migration to add missing notification_type column

from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('competitions', '0008_fix_family_fields_null'),
    ]

    operations = [
        # Add notification_type column if it doesn't exist
        migrations.RunSQL(
            "ALTER TABLE competitions_notification ADD COLUMN IF NOT EXISTS notification_type VARCHAR(20) DEFAULT 'info';",
            reverse_sql="ALTER TABLE competitions_notification DROP COLUMN IF EXISTS notification_type;"
        ),
        # Add priority column if it doesn't exist  
        migrations.RunSQL(
            "ALTER TABLE competitions_notification ADD COLUMN IF NOT EXISTS priority VARCHAR(20) DEFAULT 'standard';",
            reverse_sql="ALTER TABLE competitions_notification DROP COLUMN IF EXISTS priority;"
        ),
        # Add action_url column if it doesn't exist
        migrations.RunSQL(
            "ALTER TABLE competitions_notification ADD COLUMN IF NOT EXISTS action_url VARCHAR(200);",
            reverse_sql="ALTER TABLE competitions_notification DROP COLUMN IF EXISTS action_url;"
        ),
        # Add action_text column if it doesn't exist
        migrations.RunSQL(
            "ALTER TABLE competitions_notification ADD COLUMN IF NOT EXISTS action_text VARCHAR(100);",
            reverse_sql="ALTER TABLE competitions_notification DROP COLUMN IF EXISTS action_text;"
        ),
        # Add expires_at column if it doesn't exist
        migrations.RunSQL(
            "ALTER TABLE competitions_notification ADD COLUMN IF NOT EXISTS expires_at TIMESTAMP;",
            reverse_sql="ALTER TABLE competitions_notification DROP COLUMN IF EXISTS expires_at;"
        ),
    ]