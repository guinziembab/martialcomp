from django.urls import path, include
from competitions.views.events import (
    event_list, create_event, event_detail, edit_event, delete_event, import_events
)

app_name = 'events'

urlpatterns = [
    # Liste des événements
    path('list/', event_list, name='event_list'),
    path('', event_list, name='event_list'),  # Alias
    
    # Créer un événement
    path('create/', create_event, name='create_event'),
    
    # Détail d'un événement
    path('<int:event_id>/', event_detail, name='event_detail'),
    
    # Modifier un événement
    path('<int:event_id>/edit/', edit_event, name='edit_event'),
    
    # Supprimer un événement
    path('<int:event_id>/delete/', delete_event, name='delete_event'),
    
    # Importer des événements
    path('import/', import_events, name='import_events'),
    
    # Sous-namespace pour la planification (compatibilité)
    path('planning/', include('competitions.urls.event_planning', namespace='planning')),
]