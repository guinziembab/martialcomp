from django.urls import path
from competitions.views.club.practitioners import (
    practitioners_list, practitioner_detail, practitioner_create, practitioner_update,
    create_user_for_practitioner, link_user_to_practitioner, practitioner_delete
)
from competitions.views.club.registrations import registrations_list, available_competitions
from competitions.views.club.competitions import club_competitions
from competitions.views.club.judges import judges_list, judge_add
from competitions.views.club.technical_scoring import technical_scoring
from competitions.views.club.import_export import import_export_data
from competitions.views.club.training import training_sessions
from competitions.views.club.results import club_competition_results
from competitions.views.dashboard.club import club_dashboard

app_name = 'club'

urlpatterns = [
    # Liste des pratiquants
    path('practitioners/', practitioners_list, name='practitioners'),
    
    # Ajouter un pratiquant
    path('practitioners/add/', practitioner_create, name='practitioner_add'),
    
    # Détail d'un pratiquant
    path('practitioners/<int:pk>/', practitioner_detail, name='practitioner_detail'),
    
    # Modifier un pratiquant
    path('practitioners/<int:practitioner_id>/edit/', practitioner_update, name='practitioner_edit'),
    
    # Créer un utilisateur pour un pratiquant
    path('practitioners/<int:practitioner_id>/create-user/', create_user_for_practitioner, name='create_user_for_practitioner'),
    
    # Lier un utilisateur à un pratiquant
    path('practitioners/<int:practitioner_id>/link-user/', link_user_to_practitioner, name='link_user_to_practitioner'),
    
    # Supprimer un pratiquant
    path('practitioners/<int:practitioner_id>/delete/', practitioner_delete, name='practitioner_delete'),
    
    # Liste des inscriptions
    path('registrations/', registrations_list, name='registrations_list'),
    
    # Compétitions disponibles pour inscription
    path('available-competitions/', available_competitions, name='available_competitions'),
    
    # Liste des juges
    path('judges/', judges_list, name='judges_list'),
    
    # Ajouter un juge
    path('judges/add/', judge_add, name='judge_add'),
    
    # Notation technique
    path('technical-scoring/', technical_scoring, name='technical_scoring'),
    
    # Import/Export
    path('import-export/', import_export_data, name='import_export'),
    
    # Sessions d'entraînement
    path('training-sessions/', training_sessions, name='training_sessions'),
    
    # Résultats du club
    path('results/', club_competition_results, name='results'),
    
    # Compétitions du club
    path('competitions/', club_competitions, name='competitions'),
    path('club-competitions/', club_competitions, name='club_competitions'),  # Alias
    
    # Dashboard club (alias pour compatibilité)
    path('dashboard/', club_dashboard, name='dashboard'),
    
    # URLs temporaires pour éviter les erreurs (à implémenter plus tard)
    path('bulk-registration/', practitioners_list, name='bulk_registration'),  # Temporaire
    path('manage-roles/', practitioners_list, name='manage_roles'),  # Temporaire
    path('practitioners/<int:practitioner_id>/qualifications/add/', practitioners_list, name='qualification_add'),  # Temporaire
]