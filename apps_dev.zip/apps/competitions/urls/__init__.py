from django.urls import path, include

from competitions.views.welcome import welcome
from competitions.views.auth import login_view, logout_view 
from competitions.views.csrf_views import refresh_csrf_token

app_name = 'competitions'

urlpatterns = [
    path('', welcome, name='welcome'),
    
    # URLs Dashboard
    path('dashboard/', include('competitions.urls.dashboard', namespace='dashboard')),
    
    # URLs Club
    path('club/', include('competitions.urls.club', namespace='club')),
    
    # URLs Compétitions
    path('competitions/', include('competitions.urls.competitions', namespace='competitions')),
    
    # URLs Événements
    path('events/', include('competitions.urls.events', namespace='events')),
    
    # URLs Planification d'événements
    path('event-planning/', include('competitions.urls.event_planning', namespace='event_planning')),
    
    # URLs QR Scanner
    path('qr/', include('competitions.urls.qr', namespace='qr')),
    
    # URLs pour le module de combat
    path('combat/', include('competitions.urls.combat', namespace='combat')),
    
    # URLs pour les pratiquants
    path('practitioner/', include('competitions.urls.practitioner', namespace='practitioner')),
    
    # URLs pour les notifications
    path('notifications/', include('competitions.urls.notifications', namespace='notifications')),
    
    # URLs pour la gestion CSRF
    path('csrf/refresh/', refresh_csrf_token, name='refresh_csrf'),
    
    # URL de déconnexion
    path('logout/', logout_view, name='logout'),
]