from django.urls import path
from competitions.views.competitions import (
    competition_list, competition_create, competition_detail, 
    manage_competition_registrations
)

app_name = 'competitions'

urlpatterns = [
    # Liste des compétitions
    path('list/', competition_list, name='list'),
    path('', competition_list, name='list'),  # Alias
    
    # Créer une compétition
    path('create/', competition_create, name='create'),
    
    # Détail d'une compétition
    path('<int:pk>/', competition_detail, name='detail'),
    
    # Gestion des inscriptions
    path('<int:competition_id>/registrations/', manage_competition_registrations, name='manage_registrations'),
]