from django.urls import path
from competitions.views.qr_scanner import scan_practitioner_qr, scan_history, mark_attendance_ajax, process_qr_scan

app_name = 'qr'

urlpatterns = [
    # Scanner QR Code
    path('scan/', scan_practitioner_qr, name='scan'),
    
    # Historique des scans
    path('history/', scan_history, name='history'),
    
    # Marquer la présence via AJAX
    path('mark-attendance/', mark_attendance_ajax, name='mark_attendance_ajax'),
    
    # Traiter un scan QR
    path('process-scan/', process_qr_scan, name='process_scan'),
]