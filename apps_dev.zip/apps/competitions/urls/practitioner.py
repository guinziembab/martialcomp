from django.urls import path
from competitions.views.practitioner_dashboard import dashboard
from competitions.views.practitioner_extra import (
    practitioner_events, practitioner_calendar, practitioner_notifications
)
from competitions.views.practitioner_finance import (
    practitioner_finance_dashboard, practitioner_invoices, practitioner_invoice_detail, 
    practitioner_payments, practitioner_transactions
)
from competitions.views.practitioner_training import training_dashboard, practitioner_training_schedule

app_name = 'practitioner'

urlpatterns = [
    # Dashboard principal
    path('dashboard/', dashboard, name='dashboard'),
    path('', dashboard, name='dashboard'),  # Alias
    
    # Événements et calendrier
    path('events/', practitioner_events, name='events'),
    path('calendar/', practitioner_calendar, name='calendar'),
    
    # Notifications
    path('notifications/', practitioner_notifications, name='notifications'),
    
    # Finance
    path('finance/', practitioner_finance_dashboard, name='finance_dashboard'),
    path('finance/invoices/', practitioner_invoices, name='invoice_list'),
    path('finance/invoices/<int:invoice_id>/', practitioner_invoice_detail, name='invoice_detail'),
    path('finance/payments/', practitioner_payments, name='payment_list'),
    path('finance/transactions/', practitioner_transactions, name='transaction_list'),
    
    # Entraînement
    path('training/', training_dashboard, name='training_dashboard'),
    path('training/schedule/', practitioner_training_schedule, name='training_schedule'),
    
    # URLs temporaires pour support tickets
    path('support/tickets/', practitioner_notifications, name='support_tickets'),  # Temporaire
]