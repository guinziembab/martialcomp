from django.shortcuts import redirect
import logging
import re

logger = logging.getLogger(__name__)

class OnboardingRedirectMiddleware:
    """
    Middleware pour rediriger les utilisateurs vers le processus d'onboarding
    après une connexion réussie si nécessaire, et intercepter les anciennes URLs d'onboarding.
    """
    
    def __init__(self, get_response):
        self.get_response = get_response
        
    def __call__(self, request):
        # Intercepter les URLs d'onboarding sans préfixe /competitions/
        path = request.path
        
        # Si c'est une URL d'onboarding directe sans competitions
        onboarding_pattern = r'^/(?:(?P<lang>[a-z]{2})/)?onboarding/(?P<step>[\w-]*)/?$'
        match = re.match(onboarding_pattern, path)
        
        if match:
            lang = match.group('lang') or ''
            step = match.group('step') or ''
            if step == '':
                step = ''
            
            # Construire la nouvelle URL
            if lang:
                new_path = f'/{lang}/competitions/onboarding/{step}/'
            else:
                new_path = f'/competitions/onboarding/{step}/'
            
            logger.info(f"Redirection onboarding: {path} -> {new_path}")
            return redirect(new_path)
            
        # Obtenir la réponse normale
        response = self.get_response(request)
        
        # Vérifier si l'utilisateur est authentifié
        if request.user.is_authenticated:
            # Exclure certaines URLs du processus de redirection
            excluded_paths = [
                '/competitions/onboarding/',
                '/competitions/dashboard/',
                '/onboarding/',
                '/dashboard/',
                '/accounts/',
                '/account/',
                '/admin/',
                '/static/',
                '/media/',
                '/api/',
                '/fr/competitions/onboarding/',
                '/en/competitions/onboarding/',
            ]
            
            # Vérifier si le chemin actuel est exclu
            if not any(path.startswith(excl) for excl in excluded_paths):
                try:
                    # Vérifier si l'utilisateur a un profil
                    if hasattr(request.user, 'profile'):
                        profile = request.user.profile
                        
                        # Protection contre les boucles infinies - si l'utilisateur est déjà sur une page d'onboarding
                        if '/onboarding/' in path:
                            # Ne pas rediriger si déjà sur une page d'onboarding
                            pass
                        elif not profile.onboarding_completed:
                            # Récupérer l'étape d'onboarding de l'utilisateur
                            onboarding_step = profile.onboarding_step or 'role'
                            
                            # Nettoyer l'étape d'onboarding (remplacer 'role_selection' par 'role')
                            if onboarding_step == 'role_selection':
                                onboarding_step = 'role'
                            
                            # Déterminer si nous avons un préfixe de langue
                            lang_match = re.match(r'^/([a-z]{2})/', path)
                            lang_prefix = lang_match.group(1) + '/' if lang_match else ''
                            
                            # Construire l'URL de redirection
                            redirect_url = f'/{lang_prefix}competitions/onboarding/{onboarding_step}/'
                            
                            # Ne rediriger que si nous sommes sur une page différente
                            if path != redirect_url:
                                logger.info(f"Redirection utilisateur {request.user.username} vers {redirect_url}")
                                return redirect(redirect_url)
                    else:
                        # Créer automatiquement un profil si il n'existe pas
                        from .models import UserProfile
                        profile = UserProfile.objects.create(
                            user=request.user,
                            role='spectator',
                            onboarding_completed=False,
                            onboarding_step='role'
                        )
                        logger.info(f"Profil créé automatiquement pour {request.user.username}")
                        
                except Exception as e:
                    # Log l'erreur mais ne pas bloquer la navigation
                    logger.error(f"Erreur dans le middleware d'onboarding pour {request.user.username}: {str(e)}")
                    # En cas d'erreur, marquer l'onboarding comme complété pour éviter les boucles
                    try:
                        if hasattr(request.user, 'profile'):
                            request.user.profile.onboarding_completed = True
                            request.user.profile.save()
                            logger.info(f"Onboarding marqué comme complété pour {request.user.username} après erreur")
                    except:
                        pass
        
        return response