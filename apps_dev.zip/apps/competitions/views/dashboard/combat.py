from django.shortcuts import render
from django.contrib.auth.decorators import login_required
from competitions.utils.decorators import federation_or_club_required
from django.utils.translation import gettext_lazy as _
from django.utils import timezone
from django.db.models import Count, Q
from competitions.models.combat import (
    CombatConfiguration, Equipe, Poule, Combat, ActionCombat
)
from competitions.models import Competition

@login_required
@federation_or_club_required
def combat_dashboard(request):
    """
    View for displaying the combat dashboard.
    Shows combat-related information and management options.
    """
    # Récupérer les statistiques réelles de la base de données
    total_combats = Combat.objects.count()
    total_equipes = Equipe.objects.count()
    total_poules = Poule.objects.count()
    total_actions = ActionCombat.objects.count()
    
    # Récupérer les configurations de combat récentes (5 dernières)
    configurations = CombatConfiguration.objects.all().order_by('-id')[:5]
    
    # Récupérer les équipes récentes (5 dernières)
    equipes = Equipe.objects.all().order_by('-created_at')[:5]
    
    # Récupérer les poules récentes (5 dernières)
    poules = Poule.objects.all().order_by('-id')[:5]
    
    # Récupérer les combats en cours
    combats_en_cours = Combat.objects.filter(status='en_cours').order_by('-debut_combat')[:10]
    
    # Récupérer les prochains combats (planifiés)
    prochains_combats = Combat.objects.filter(
        status='planifie',
        date_planifiee__gte=timezone.now()
    ).order_by('date_planifiee')[:10]
    
    # Récupérer les résultats récents (combats terminés)
    resultats_recents = Combat.objects.filter(
        status='termine'
    ).order_by('-fin_combat')[:10]
    
    # Préparer les données pour le nouveau template
    context = {
        'title': _('Tableau de bord Combat'),
        'combat_configurations': configurations,
        'teams': equipes,
        'poules': poules,
        'ongoing_combats': combats_en_cours,
        'upcoming_combats': prochains_combats,
        'recent_results': resultats_recents,
        'stats': {
            'total_combats': total_combats,
            'total_equipes': total_equipes,
            'total_poules': total_poules,
            'total_actions': total_actions,
            'ongoing_count': combats_en_cours.count(),
            'upcoming_count': prochains_combats.count(),
            'recent_count': resultats_recents.count()
        }
    }
    
    return render(request, 'competitions/dashboard/combat_modern.html', context)