from django.shortcuts import render
from django.contrib.auth.decorators import login_required
from django.utils.translation import gettext_lazy as _

@login_required
def dashboard_external_organizer(request):
    """Dashboard complet pour l’organisateur non-membre."""
    user = request.user
    # Récupérer les compétitions organisées par cet utilisateur (à adapter selon modèle)
    competitions = []  # À remplacer par la vraie requête si besoin
    return render(request, 'competitions/dashboard/external_organizer.html', {
        'user': user,
        'competitions': competitions,
    }) 