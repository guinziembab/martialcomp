"""
Vue dashboard pour les coaches - Version simplifiée
"""
import logging
from django.shortcuts import render, redirect
from django.contrib.auth.decorators import login_required
from django.utils.translation import gettext_lazy as _
from django.contrib import messages

from ...models import UserProfile, Practitioner, CoachProfile

logger = logging.getLogger(__name__)

@login_required
def coach_dashboard(request):
    """
    Tableau de bord pour les coaches.
    Version simplifiée qui redirige vers coach-multidiscipline.
    """
    try:
        # Vérifier l'authentification
        if not request.user.is_authenticated:
            from django.contrib.auth.views import redirect_to_login
            return redirect_to_login(request.get_full_path())
        
        # Récupérer le profil utilisateur
        try:
            profile = UserProfile.objects.get(user=request.user)
        except UserProfile.DoesNotExist:
            messages.warning(request, _("Profil utilisateur non trouvé."))
            return redirect('competitions:dashboard:home')
        
        # Vérifier le rôle
        logger.warning(f"DEBUG: Valeur du rôle pour {request.user.username}: '{profile.role}' (après strip/lower: '{profile.role.strip().lower()}')")
        messages.info(request, _(f"DEBUG: Votre rôle détecté est : '{profile.role}' (après strip/lower: '{profile.role.strip().lower()}')"))
        if profile.role.strip().lower() != 'coach':
            messages.warning(request, _("Ce tableau de bord est réservé aux coaches."))
            return redirect('competitions:dashboard:home')
        
        # Récupérer le pratiquant
        try:
            practitioner = Practitioner.objects.get(user=request.user)
        except Practitioner.DoesNotExist:
            messages.error(request, _("Profil coach non trouvé."))
            return redirect('competitions:dashboard:home')
        
        # Récupérer le profil coach
        try:
            coach_profile = CoachProfile.objects.get(practitioner=practitioner)
        except CoachProfile.DoesNotExist:
            # Créer le profil coach si nécessaire
            coach_profile = CoachProfile.objects.create(
                practitioner=practitioner,
                profile_type='multidisciplinary',
                teaching_philosophy=f'Coach - {practitioner.first_name} {practitioner.last_name}',
                years_teaching=5,
                hourly_rate_range='50-80',
                available_for_private_lessons=True,
                available_for_seminars=True,
                available_for_online_coaching=True
            )
        
        # Contexte pour le template
        context = {
            'user': request.user,
            'practitioner': practitioner,
            'coach_profile': coach_profile,
            'dashboard_type': 'coach',
            'page_title': _('Tableau de bord Coach'),
        }
        
        return render(request, 'competitions/dashboard/coach.html', context)
        
    except Exception as e:
        logger.error(f"Erreur dans coach_dashboard: {str(e)}")
        messages.error(request, _("Une erreur est survenue lors du chargement du tableau de bord."))
        return redirect('competitions:dashboard:home') 