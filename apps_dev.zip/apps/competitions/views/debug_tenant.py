from django.http import JsonResponse
from django.views.decorators.http import require_GET
from multitenant.models import Tenant, Domain
from competitions.models import Federation

@require_GET
def debug_tenant(request):
    """Vue de debug pour diagnostiquer les problèmes tenant"""
    
    data = {
        "host": request.get_host(),
        "tenant_detected": hasattr(request, 'tenant'),
        "tenant_info": None,
        "federation_found": False,
        "organization_found": False
    }
    
    if hasattr(request, 'tenant') and request.tenant:
        tenant = request.tenant
        data["tenant_info"] = {
            "name": tenant.name,
            "slug": tenant.slug,
            "id": str(tenant.id)
        }
        
        # Test recherche fédération
        if tenant.slug.startswith('fed-'):
            federation_slug = tenant.slug[4:]
            federation = Federation.objects.filter(slug=federation_slug).first()
            if federation:
                data["federation_found"] = True
                data["federation_info"] = {
                    "name": federation.name,
                    "slug": federation.slug,
                    "has_organization": bool(federation.organization)
                }
                
                if federation.organization:
                    data["organization_found"] = True
                    data["organization_info"] = {
                        "name": federation.organization.name,
                        "type": federation.organization.organization_type
                    }
    
    return JsonResponse(data, indent=2)
