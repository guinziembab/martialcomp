"""
Routeur dashboard simple - utilise les templates existants
"""
from django.shortcuts import render, redirect
from django.contrib.auth.decorators import login_required

@login_required
def dashboard_router(request):
    """Route intelligemment vers le bon dashboard selon le rôle du profil utilisateur"""
    user = request.user
    profile = getattr(user, 'profile', None)
    if profile:
        role = profile.role
        if role == 'coach':
            return redirect('/competitions/dashboard/coach/')
        elif role == 'club_manager':
            return redirect('/competitions/dashboard/club/')
        elif role == 'participant':
            return redirect('/competitions/dashboard/participant/')
        elif role == 'federation_admin':
            return redirect('/competitions/dashboard/federation/')
        elif role == 'referee':
            return redirect('/competitions/dashboard/referee/')
        elif role == 'judge':
            return redirect('/competitions/dashboard/judge/')
        elif role == 'pro':
            return redirect('/competitions/dashboard/pro/')
        elif role == 'manager':
            return redirect('/competitions/dashboard/manager/')
        elif role == 'spectator':
            return redirect('/competitions/dashboard/spectator/')
        elif role == 'external_organizer':
            return redirect('/competitions/dashboard/external_organizer/')
    # Fallback
    return redirect('/competitions/dashboard/spectator/')

@login_required
def club_dashboard_view(request):
    """Dashboard club"""
    context = {
        'user': request.user,
        'club_name': 'Dojo Sakura',
        'members_count': 45,
    }
    return render(request, 'competitions/dashboard/club.html', context)

@login_required  
def coach_dashboard_view(request):
    """Dashboard coach"""
    context = {'user': request.user}
    return render(request, 'competitions/dashboard/coach.html', context)

@login_required
def participant_dashboard_view(request):
    """Dashboard participant"""
    context = {'user': request.user}
    return render(request, 'competitions/dashboard/participant.html', context)

@login_required
def federation_dashboard_view(request):
    """Dashboard federation"""
    context = {'user': request.user}
    return render(request, 'competitions/dashboard/federation.html', context)
