"""
Vue de test pour valider le processus d'onboarding complet
"""
import logging
from django.shortcuts import render, redirect
from django.contrib.auth.decorators import login_required
from django.contrib.auth.models import User
from django.contrib.auth import login
from django.contrib import messages
from django.http import JsonResponse
from django.utils.translation import gettext_lazy as _
from django.urls import reverse
from ..models import UserProfile

logger = logging.getLogger(__name__)

def test_onboarding(request):
    """
    Vue de test pour simuler et tester l'onboarding complet.
    """
    context = {
        'user_authenticated': request.user.is_authenticated,
        'steps': [
            {'name': 'Création de compte', 'description': 'Inscription via formulaire ou OAuth'},
            {'name': 'Sélection de rôle', 'description': 'Choix du rôle (coach, participant, etc.)'},
            {'name': 'Configuration spécifique', 'description': 'Création organisation/profil'},
            {'name': 'Finalisation', 'description': 'Accès au dashboard'}
        ]
    }
    
    if request.user.is_authenticated:
        try:
            profile = request.user.profile
            context.update({
                'profile_exists': True,
                'current_role': profile.role,
                'onboarding_completed': profile.onboarding_completed,
                'onboarding_step': profile.onboarding_step
            })
        except:
            context['profile_exists'] = False
    
    return render(request, 'competitions/test_onboarding.html', context)

def test_onboarding_reset(request):
    """
    Réinitialise l'onboarding pour l'utilisateur connecté.
    """
    if request.user.is_authenticated:
        try:
            profile = request.user.profile
            profile.onboarding_completed = False
            profile.onboarding_step = 'role_selection'
            profile.role = 'spectator'
            profile.save()
            
            messages.success(request, _("Onboarding réinitialisé. Vous allez être redirigé."))
            return redirect('competitions:onboarding:role_selection')
            
        except Exception as e:
            logger.error(f"Erreur lors de la réinitialisation de l'onboarding: {str(e)}")
            messages.error(request, _("Erreur lors de la réinitialisation."))
    
    return redirect('competitions:test_onboarding')

def test_onboarding_api(request):
    """
    API pour tester l'état de l'onboarding.
    """
    if not request.user.is_authenticated:
        return JsonResponse({
            'authenticated': False,
            'message': 'Utilisateur non connecté'
        })
    
    try:
        profile = request.user.profile
        return JsonResponse({
            'authenticated': True,
            'profile_exists': True,
            'user': request.user.username,
            'role': profile.role,
            'onboarding_completed': profile.onboarding_completed,
            'onboarding_step': profile.onboarding_step,
            'next_url': reverse('competitions:onboarding:role_selection') if not profile.onboarding_completed else reverse('competitions:dashboard:index')
        })
    except:
        return JsonResponse({
            'authenticated': True,
            'profile_exists': False,
            'user': request.user.username,
            'message': 'Profil utilisateur non trouvé'
        })