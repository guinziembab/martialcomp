from django.views.generic import ListView
from django.db.models import Q
from ..utils.discipline_filtering import filter_queryset_by_discipline_federation


class BaseFilteredListView(ListView):
    """
    Classe de base pour toutes les vues listant des éléments à filtrer par discipline/fédération.
    
    Cette classe applique automatiquement le filtrage selon les disciplines et fédérations
    accessibles à l'utilisateur connecté.
    """
    
    def get_queryset(self):
        queryset = super().get_queryset()
        
        # Si l'utilisateur n'est pas authentifié ou est superuser, pas de filtrage
        if not self.request.user.is_authenticated or self.request.user.is_superuser:
            return queryset
        
        # Appliquer le filtrage par discipline/fédération
        return filter_queryset_by_discipline_federation(queryset, self.request.user)
    
    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        
        # Ajouter les disciplines accessibles au contexte
        if hasattr(self.request, 'user_disciplines'):
            context['user_disciplines'] = self.request.user_disciplines
            context['discipline_federation_mapping'] = self.request.discipline_federation_mapping
        
        return context


class BaseFilteredDetailView:
    """
    Mixin pour les vues de détail avec vérification d'accès par discipline.
    """
    
    def get_object(self, queryset=None):
        obj = super().get_object(queryset)
        
        # Vérifier l'accès à l'objet
        from ..utils.discipline_filtering import has_access_to_object
        if not has_access_to_object(self.request.user, obj):
            from django.core.exceptions import PermissionDenied
            raise PermissionDenied("Vous n'avez pas accès à cette ressource.")
        
        return obj 