from django.shortcuts import render, redirect
from django.contrib.auth import authenticate, login
from django.contrib import messages
from django.views.decorators.csrf import csrf_protect, ensure_csrf_cookie
from django.views.decorators.http import require_http_methods
from django.utils.translation import gettext_lazy as _
from django.middleware.csrf import get_token

@ensure_csrf_cookie
@csrf_protect  
@require_http_methods(["GET", "POST"])
def custom_login_view(request):
    """Vue de connexion professionnelle :
    - GET : affiche le template account/login.html (sauf si ?show_login=1, alors redirige vers accueil avec modale)
    - POST : traite la connexion comme avant
    """
    if request.method == "GET":
        if request.GET.get('show_login') == '1':
            return redirect('/fr/?show_login=1')
        get_token(request)
        return render(request, 'account/login.html', {})
    
    elif request.method == "POST":
        # DEBUG: Log des informations CSRF
        import logging
        logger = logging.getLogger(__name__)
        logger.warning(f'CSRF token reçu: {request.POST.get("csrfmiddlewaretoken", "MANQUANT")}')
        logger.warning(f'CSRF cookie: {request.META.get("CSRF_COOKIE", "MANQUANT")}')
        logger.warning(f'Utilisateur: {request.POST.get("login", "MANQUANT")}')
        # Traiter la connexion
        username = request.POST.get('login', '')
        password = request.POST.get('password', '')
        
        if username and password:
            user = authenticate(request, username=username, password=password)
            
            if user is not None:
                if user.is_active:
                    login(request, user)
                    
                    # Redirection selon le rôle
                    try:
                        from competitions.models.users import UserProfile
                        profile = UserProfile.objects.get(user=user)
                        
                        if profile.onboarding_completed:
                            # Redirection dashboard selon le rôle
                            role_map = {
                                'manager': '/fr/competitions/dashboard/manager/',
                                'club_manager': '/fr/competitions/dashboard/club/',
                                'federation_admin': '/fr/competitions/dashboard/federation/',
                                'participant': '/fr/competitions/dashboard/participant/',
                                'coach': '/fr/competitions/dashboard/coach/',
                                'referee': '/fr/competitions/dashboard/referee/',
                                'external_organizer': '/fr/competitions/dashboard/external_organizer/',
                                'spectator': '/fr/competitions/dashboard/spectator/'
                            }
                            role_key = str(profile.role).lower().strip()
                            if role_key == 'federation_admin':
                                from competitions.models import Federation
                                federation = Federation.objects.filter(owner=user).first() or Federation.objects.filter(administrators__user=user).first()
                                if federation:
                                    return redirect(f'/fr/competitions/federations/{federation.id}/dashboard/')
                                else:
                                    return redirect('/fr/competitions/federations/')
                            else:
                                return redirect(role_map.get(role_key, '/fr/competitions/dashboard/spectator/'))
                        else:
                            # Redirection onboarding
                            return redirect('/fr/competitions/onboarding/role/')
                            
                    except:
                        # Fallback vers spectator
                        return redirect('/fr/competitions/dashboard/spectator/')
                else:
                    messages.error(request, _("Votre compte est désactivé."))
            else:
                messages.error(request, _("Nom d'utilisateur ou mot de passe incorrect."))
        else:
            messages.error(request, _("Veuillez remplir tous les champs."))
        
        # En cas d'erreur, retour vers welcome avec modal
        return redirect('/fr/?show_login=1&error=1')
