from django.urls import path
from competitions.views.api import generate_license_number

urlpatterns = [
    path('generate-license-number/', generate_license_number, name='generate_license_number'),
] 