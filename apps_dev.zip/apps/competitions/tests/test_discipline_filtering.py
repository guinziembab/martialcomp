from django.test import TestCase, Client
from django.contrib.auth.models import User
from django.urls import reverse
from competitions.models import Club, Discipline, Federation, Competition
from organizations.models import Organization, Affiliation
from competitions.utils.discipline_filtering import get_user_access_context, filter_queryset_by_discipline_federation


class DisciplineFilteringTestCase(TestCase):
    """
    Tests pour vérifier que le filtrage par discipline fonctionne correctement.
    """
    
    def setUp(self):
        """Créer les données de test."""
        # Créer des disciplines
        self.karate = Discipline.objects.create(name="Karaté", is_active=True)
        self.judo = Discipline.objects.create(name="Judo", is_active=True)
        self.taekwondo = Discipline.objects.create(name="Taekwondo", is_active=True)
        
        # Créer des fédérations
        self.ffk = Federation.objects.create(name="Fédération Française de Karaté")
        self.ffjda = Federation.objects.create(name="Fédération Française de Judo")
        
        # Créer des organisations
        self.org_ffk = Organization.objects.create(
            name="FFK Org",
            organization_type='national_federation',
            old_federation_id=self.ffk.id
        )
        self.org_ffjda = Organization.objects.create(
            name="FFJDA Org", 
            organization_type='national_federation',
            old_federation_id=self.ffjda.id
        )
        
        # Créer un club multi-disciplines
        self.club = Club.objects.create(
            name="Dojo Central",
            owner=None
        )
        self.club.disciplines.add(self.karate, self.judo)
        
        # Créer l'organisation du club
        self.club_org = Organization.objects.create(
            name="Dojo Central Org",
            organization_type='club',
            old_club_id=self.club.id
        )
        self.club.organization = self.club_org
        self.club.save()
        
        # Créer des affiliations
        Affiliation.objects.create(
            parent_organization=self.org_ffk,
            child_organization=self.club_org,
            affiliation_type='member',
            is_active=True
        )
        Affiliation.objects.create(
            parent_organization=self.org_ffjda,
            child_organization=self.club_org,
            affiliation_type='member',
            is_active=True
        )
        
        # Créer un utilisateur
        self.user = User.objects.create_user(
            username="club_admin",
            password="password"
        )
        self.club.owner = self.user
        self.club.save()
        
        # Créer des compétitions
        self.comp_karate_ffk = Competition.objects.create(
            title="Compétition Karaté FFK",
            discipline=self.karate,
            federation=self.ffk,
            status='published'
        )
        self.comp_judo_ffjda = Competition.objects.create(
            title="Compétition Judo FFJDA",
            discipline=self.judo,
            federation=self.ffjda,
            status='published'
        )
        self.comp_taekwondo = Competition.objects.create(
            title="Compétition Taekwondo",
            discipline=self.taekwondo,
            federation=None,
            status='published'
        )
        
        # Client pour les tests
        self.client = Client()
    
    def test_get_user_access_context(self):
        """Test de la fonction get_user_access_context."""
        disciplines, mapping = get_user_access_context(self.user)
        
        # L'utilisateur devrait avoir accès à Karaté et Judo
        self.assertIn(self.karate, disciplines)
        self.assertIn(self.judo, disciplines)
        self.assertNotIn(self.taekwondo, disciplines)
        
        # Vérifier le mapping discipline -> fédérations
        self.assertIn(self.karate.id, mapping)
        self.assertIn(self.judo.id, mapping)
        self.assertIn(self.ffk, mapping[self.karate.id])
        self.assertIn(self.ffjda, mapping[self.judo.id])
    
    def test_filter_queryset_by_discipline_federation(self):
        """Test du filtrage de queryset par discipline/fédération."""
        # Récupérer toutes les compétitions
        all_competitions = Competition.objects.all()
        
        # Appliquer le filtrage
        filtered_competitions = filter_queryset_by_discipline_federation(
            all_competitions, self.user
        )
        
        # L'utilisateur devrait voir les compétitions de Karaté et Judo
        self.assertIn(self.comp_karate_ffk, filtered_competitions)
        self.assertIn(self.comp_judo_ffjda, filtered_competitions)
        self.assertNotIn(self.comp_taekwondo, filtered_competitions)
    
    def test_superuser_sees_all(self):
        """Test qu'un superuser voit toutes les compétitions."""
        # Créer un superuser
        superuser = User.objects.create_superuser(
            username="admin",
            email="admin@test.com",
            password="password"
        )
        
        all_competitions = Competition.objects.all()
        filtered_competitions = filter_queryset_by_discipline_federation(
            all_competitions, superuser
        )
        
        # Le superuser devrait voir toutes les compétitions
        self.assertEqual(filtered_competitions.count(), all_competitions.count())
    
    def test_anonymous_user_sees_nothing(self):
        """Test qu'un utilisateur anonyme ne voit rien."""
        all_competitions = Competition.objects.all()
        filtered_competitions = filter_queryset_by_discipline_federation(
            all_competitions, None
        )
        
        # Un utilisateur anonyme ne devrait voir aucune compétition
        self.assertEqual(filtered_competitions.count(), 0)
    
    def test_club_mono_discipline(self):
        """Test avec un club mono-discipline."""
        # Créer un club qui ne pratique que le Karaté
        mono_club = Club.objects.create(name="Club Karaté")
        mono_club.disciplines.add(self.karate)
        
        # Créer l'organisation du club
        mono_org = Organization.objects.create(
            name="Club Karaté Org",
            organization_type='club'
        )
        mono_club.organization = mono_org
        mono_club.save()
        
        # Créer un utilisateur pour ce club
        mono_user = User.objects.create_user(
            username="mono_user",
            password="password"
        )
        mono_club.owner = mono_user
        mono_club.save()
        
        # Tester le filtrage
        disciplines, mapping = get_user_access_context(mono_user)
        
        # L'utilisateur ne devrait voir que le Karaté
        self.assertIn(self.karate, disciplines)
        self.assertNotIn(self.judo, disciplines)
        self.assertNotIn(self.taekwondo, disciplines) 