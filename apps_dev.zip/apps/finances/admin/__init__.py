from django.contrib import admin
from django.contrib.admin.sites import AlreadyRegistered
from django.utils.html import format_html, format_html_join

# Import des modèles explicites au lieu d'utiliser *
from finances.models.transactions import Transaction, TransactionCategory, TransactionAttachment
from finances.models.payments import PaymentMethod, PaymentAttempt
from finances.models.invoices import Invoice, InvoiceItem
from finances.models.accounts import AccountingCategory, FinancialAccount, MembershipFee
from finances.models.subscription import FeatureFlag, SubscriptionTier

from finances.admin.transaction import TransactionAdmin
from finances.admin.payment import PaymentMethodAdmin, PaymentAttemptAdmin
from finances.admin.invoice import InvoiceAdmin, InvoiceItemAdmin
from finances.admin.account import AccountingCategoryAdmin, FinancialAccountAdmin, MembershipFeeAdmin

# Enregistrer les modèles avec leurs classes d'administration
admin.site.register(Transaction, TransactionAdmin)
admin.site.register(TransactionCategory)
admin.site.register(TransactionAttachment)
admin.site.register(PaymentMethod, PaymentMethodAdmin)
admin.site.register(PaymentAttempt, PaymentAttemptAdmin)
admin.site.register(Invoice, InvoiceAdmin)
admin.site.register(InvoiceItem, InvoiceItemAdmin)
admin.site.register(AccountingCategory, AccountingCategoryAdmin)

try:
    admin.site.register(FinancialAccount, FinancialAccountAdmin)
except AlreadyRegistered:
    pass

try:
    admin.site.register(MembershipFee, MembershipFeeAdmin)
except AlreadyRegistered:
    pass

class FeatureFlagAdmin(admin.ModelAdmin):
    list_display = ("display_name", "module", "complexity", "is_active", "is_always_enabled", "subscription_tiers_badges", "critical_indicator")
    list_filter = ("module", "complexity", "is_active", "subscription_tiers")
    search_fields = ("name", "display_name", "description")
    filter_horizontal = ("subscription_tiers",)
    actions = ["activate_features", "deactivate_features", "activate_for_package", "deactivate_for_package", "remove_from_package"]

    def subscription_tiers_badges(self, obj):
        return format_html_join(
            '',
            '<span style="background:#e0e0e0; color:#333; border-radius:8px; padding:2px 8px; margin:2px; font-size:0.9em;">{}</span>',
            ((tier.display_name,) for tier in obj.subscription_tiers.all())
        )
    subscription_tiers_badges.short_description = "Packages"

    def critical_indicator(self, obj):
        if obj.is_always_enabled:
            return format_html('<span style="color:#fff; background:#d9534f; border-radius:6px; padding:2px 8px; font-weight:bold;">CRITIQUE</span>')
        return ""
    critical_indicator.short_description = "Critique"

    def has_delete_permission(self, request, obj=None):
        if obj and obj.is_always_enabled and not request.user.is_superuser:
            return False
        return super().has_delete_permission(request, obj)

    def get_actions(self, request):
        actions = super().get_actions(request)
        # Empêcher la désactivation/suppression groupée des fonctionnalités critiques pour les non-superusers
        if not request.user.is_superuser:
            actions.pop('deactivate_features', None)
            actions.pop('delete_selected', None)
        return actions

    def activate_features(self, request, queryset):
        queryset.update(is_active=True)
    activate_features.short_description = "Activer les fonctionnalités sélectionnées"

    def deactivate_features(self, request, queryset):
        # Ne pas désactiver les fonctionnalités critiques
        for obj in queryset:
            if obj.is_always_enabled:
                continue
            obj.is_active = False
            obj.save()
    deactivate_features.short_description = "Désactiver les fonctionnalités sélectionnées (hors critiques)"

    def activate_for_package(self, request, queryset):
        from django.contrib import messages
        from .models.subscription import SubscriptionTier
        tier_id = request.POST.get('tier_id')
        if not tier_id:
            messages.error(request, "Veuillez sélectionner un package dans le filtre à gauche.")
            return
        try:
            tier = SubscriptionTier.objects.get(id=tier_id)
        except SubscriptionTier.DoesNotExist:
            messages.error(request, "Package introuvable.")
            return
        for feature in queryset:
            feature.subscription_tiers.add(tier)
        messages.success(request, f"Fonctionnalités activées pour le package {tier.display_name}.")
    activate_for_package.short_description = "Activer pour le package sélectionné (via filtre)"

    def deactivate_for_package(self, request, queryset):
        from django.contrib import messages
        from .models.subscription import SubscriptionTier
        tier_id = request.POST.get('tier_id')
        if not tier_id:
            messages.error(request, "Veuillez sélectionner un package dans le filtre à gauche.")
            return
        try:
            tier = SubscriptionTier.objects.get(id=tier_id)
        except SubscriptionTier.DoesNotExist:
            messages.error(request, "Package introuvable.")
            return
        for feature in queryset:
            feature.subscription_tiers.remove(tier)
        messages.success(request, f"Fonctionnalités désactivées pour le package {tier.display_name}.")
    deactivate_for_package.short_description = "Désactiver pour le package sélectionné (via filtre)"

    def remove_from_package(self, request, queryset):
        from django.contrib import messages
        from .models.subscription import SubscriptionTier
        tier_id = request.POST.get('tier_id')
        if not tier_id:
            messages.error(request, "Veuillez sélectionner un package dans le filtre à gauche.")
            return
        try:
            tier = SubscriptionTier.objects.get(id=tier_id)
        except SubscriptionTier.DoesNotExist:
            messages.error(request, "Package introuvable.")
            return
        for feature in queryset:
            feature.subscription_tiers.remove(tier)
        messages.success(request, f"Fonctionnalités supprimées du package {tier.display_name}.")
    remove_from_package.short_description = "Retirer des fonctionnalités du package sélectionné (via filtre)"

class SubscriptionTierAdmin(admin.ModelAdmin):
    list_display = ("display_name", "name", "max_members", "max_disciplines", "is_active")
    list_filter = ("is_active",)
    search_fields = ("name", "display_name", "description")

admin.site.register(FeatureFlag, FeatureFlagAdmin)
admin.site.register(SubscriptionTier, SubscriptionTierAdmin)