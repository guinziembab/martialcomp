from django.core.management.base import BaseCommand
from django.utils.translation import gettext as _
from finances.models import PaymentMethod


class Command(BaseCommand):
    help = 'Create default payment methods for the system'

    def add_arguments(self, parser):
        parser.add_argument(
            '--force',
            action='store_true',
            help='Force creation even if payment methods already exist',
        )

    def handle(self, *args, **options):
        force = options['force']
        
        # Check if payment methods already exist
        if PaymentMethod.objects.exists() and not force:
            self.stdout.write(
                self.style.WARNING(
                    'Payment methods already exist. Use --force to recreate them.'
                )
            )
            return

        # Default payment methods to create
        default_methods = [
            {
                'name': 'Espèces',
                'type': 'cash',
                'description': 'Paiement en espèces',
                'fee_fixed': 0.00,
                'fee_percentage': 0.00,
                'is_active': True,
                'config': {}
            },
            {
                'name': 'Carte bancaire',
                'type': 'card',
                'description': 'Paiement par carte bancaire',
                'fee_fixed': 0.30,
                'fee_percentage': 2.50,
                'is_active': True,
                'config': {}
            },
            {
                'name': 'Virement bancaire',
                'type': 'transfer',
                'description': 'Virement bancaire SEPA',
                'fee_fixed': 0.00,
                'fee_percentage': 0.00,
                'is_active': True,
                'config': {
                    'iban': '',
                    'bic': ''
                }
            },
            {
                'name': 'Chèque',
                'type': 'check',
                'description': 'Paiement par chèque',
                'fee_fixed': 0.00,
                'fee_percentage': 0.00,
                'is_active': True,
                'config': {}
            },
            {
                'name': 'Prélèvement automatique',
                'type': 'direct_debit',
                'description': 'Prélèvement automatique SEPA',
                'fee_fixed': 0.25,
                'fee_percentage': 0.00,
                'is_active': False,  # Disabled by default as it requires specific setup
                'config': {
                    'creditor_id': ''
                }
            },
            {
                'name': 'PayPal',
                'type': 'paypal',
                'description': 'Paiement en ligne via PayPal',
                'fee_fixed': 0.35,
                'fee_percentage': 3.40,
                'is_active': False,  # Disabled by default as it requires API keys
                'config': {
                    'client_id': '',
                    'environment': 'sandbox'
                }
            },
            {
                'name': 'Stripe',
                'type': 'stripe', 
                'description': 'Paiement en ligne via Stripe',
                'fee_fixed': 0.25,
                'fee_percentage': 1.40,
                'is_active': False,  # Disabled by default as it requires API keys
                'config': {
                    'public_key': '',
                    'webhook_secret': ''
                }
            }
        ]

        created_count = 0
        
        # Clear existing methods if force is used
        if force:
            PaymentMethod.objects.all().delete()
            self.stdout.write(
                self.style.SUCCESS('Cleared existing payment methods')
            )

        # Create default payment methods
        for method_data in default_methods:
            payment_method, created = PaymentMethod.objects.get_or_create(
                name=method_data['name'],
                type=method_data['type'],
                defaults=method_data
            )
            
            if created:
                created_count += 1
                self.stdout.write(
                    self.style.SUCCESS(
                        f'Created payment method: {payment_method.name}'
                    )
                )
            else:
                self.stdout.write(
                    self.style.WARNING(
                        f'Payment method already exists: {payment_method.name}'
                    )
                )

        self.stdout.write(
            self.style.SUCCESS(
                f'\nSummary: {created_count} payment methods created successfully.'
            )
        )
        
        # Display usage instructions
        self.stdout.write('\n' + '='*60)
        self.stdout.write(self.style.SUCCESS('PAYMENT METHODS SETUP COMPLETE'))
        self.stdout.write('='*60)
        self.stdout.write('\nNext steps:')
        self.stdout.write('1. Visit /finances/payments/methods/ to review the payment methods')
        self.stdout.write('2. Configure API keys for PayPal and Stripe if needed')
        self.stdout.write('3. Activate/deactivate payment methods as per your needs')
        self.stdout.write('4. Adjust fees according to your payment processor rates')
        self.stdout.write('\nNote: PayPal, Stripe, and Direct Debit are disabled by default')
        self.stdout.write('and require additional configuration before activation.')