from django.apps import AppConfig


class DocumentsConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'documents'
    verbose_name = 'Gestion Électronique des Documents'

    def ready(self):
        import documents.signals  # noqa