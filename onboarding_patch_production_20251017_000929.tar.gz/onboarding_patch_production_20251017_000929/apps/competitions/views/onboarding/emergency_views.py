"""
Vues d'urgence sécurisées pour l'onboarding
Ces vues incluent une gestion d'erreurs robuste
"""
from django.shortcuts import render, redirect
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.utils.translation import gettext as _
from django.views.decorators.http import require_http_methods
from django.db import transaction
import logging

from apps.competitions.models import Discipline, Club, Federation, UserProfile
from apps.competitions.forms.onboarding import (
    ClubCreationForm, 
    FederationCreationForm
)

logger = logging.getLogger('onboarding')


@login_required
@require_http_methods(['GET', 'POST'])
def safe_club_creation(request):
    """
    Version sécurisée de la création de club
    Gère tous les cas d'erreur possibles
    """
    try:
        # Vérifier que l'utilisateur a un profil
        if not hasattr(request.user, 'profile'):
            # Créer le profil si manquant
            profile = UserProfile.objects.create(
                user=request.user,
                role='club_manager'
            )
            logger.info(f"Created missing profile for user {request.user.email}")
        else:
            profile = request.user.profile
        
        # Vérifier les disciplines disponibles
        disciplines = Discipline.objects.filter(is_active=True)
        
        if not disciplines.exists():
            logger.warning("No active disciplines found, creating defaults")
            # Créer disciplines par défaut
            default_disciplines = ['Karaté', 'Judo', 'Taekwondo']
            for name in default_disciplines:
                Discipline.objects.get_or_create(
                    name=name,
                    defaults={'is_active': True}
                )
            disciplines = Discipline.objects.filter(is_active=True)
        
        if request.method == 'POST':
            form = ClubCreationForm(request.POST, request.FILES)
            
            if form.is_valid():
                try:
                    with transaction.atomic():
                        # Créer le club
                        club = form.save(commit=False)
                        club.owner = request.user
                        club.save()
                        
                        # Sauvegarder les relations many-to-many
                        form.save_m2m()
                        
                        # Si aucune discipline sélectionnée, ajouter la première
                        if not club.disciplines.exists():
                            club.disciplines.add(disciplines.first())
                            logger.info(f"Added default discipline to club {club.name}")
                        
                        # Mettre à jour le profil
                        profile.club = club
                        profile.onboarding_completed = True
                        profile.onboarding_step = 'completed'
                        profile.save()
                        
                        logger.info(
                            f"Club created successfully: {club.name} "
                            f"by user {request.user.email}"
                        )
                        
                        messages.success(
                            request,
                            _("Félicitations ! Votre club a été créé avec succès.")
                        )
                        return redirect('dashboard:club')
                
                except Exception as e:
                    logger.error(
                        f"Error saving club for user {request.user.email}: {e}",
                        exc_info=True
                    )
                    messages.error(
                        request,
                        _("Erreur lors de la création du club. "
                          "Veuillez réessayer ou contacter le support.")
                    )
            else:
                # Erreurs de validation
                logger.warning(
                    f"Form validation failed for user {request.user.email}: "
                    f"{form.errors}"
                )
                for field, errors in form.errors.items():
                    for error in errors:
                        messages.error(request, f"{field}: {error}")
        else:
            # GET request
            form = ClubCreationForm()
        
        context = {
            'form': form,
            'disciplines': disciplines,
            'step': 'club_creation',
            'progress': 60,  # 60% du processus
        }
        
        return render(
            request,
            'competitions/onboarding/club_creation.html',
            context
        )
    
    except Exception as e:
        # Erreur critique non gérée
        logger.critical(
            f"Critical error in safe_club_creation: {e}",
            exc_info=True,
            extra={'user': request.user.email if request.user else 'anonymous'}
        )
        messages.error(
            request,
            _("Une erreur technique critique est survenue. "
              "Notre équipe a été notifiée automatiquement.")
        )
        return redirect('onboarding:error')


@login_required
@require_http_methods(['GET', 'POST'])
def safe_federation_creation(request):
    """
    Version sécurisée de la création de fédération
    """
    try:
        # Vérifier le profil
        if not hasattr(request.user, 'profile'):
            profile = UserProfile.objects.create(
                user=request.user,
                role='federation_admin'
            )
            logger.info(f"Created missing profile for user {request.user.email}")
        else:
            profile = request.user.profile
        
        disciplines = Discipline.objects.filter(is_active=True)
        
        if not disciplines.exists():
            logger.warning("No active disciplines for federation")
            default_disciplines = ['Karaté', 'Judo', 'Taekwondo']
            for name in default_disciplines:
                Discipline.objects.get_or_create(
                    name=name,
                    defaults={'is_active': True}
                )
            disciplines = Discipline.objects.filter(is_active=True)
        
        if request.method == 'POST':
            form = FederationCreationForm(request.POST, request.FILES)
            
            if form.is_valid():
                try:
                    with transaction.atomic():
                        federation = form.save(commit=False)
                        federation.admin = request.user
                        federation.save()
                        form.save_m2m()
                        
                        if not federation.disciplines.exists():
                            federation.disciplines.add(disciplines.first())
                            logger.info(f"Added default discipline to federation {federation.name}")
                        
                        profile.onboarding_completed = True
                        profile.onboarding_step = 'completed'
                        profile.save()
                        
                        logger.info(
                            f"Federation created: {federation.name} "
                            f"by {request.user.email}"
                        )
                        
                        messages.success(
                            request,
                            _("Votre fédération a été créée avec succès.")
                        )
                        return redirect('competitions:dashboard:federations')
                
                except Exception as e:
                    logger.error(
                        f"Error creating federation: {e}",
                        exc_info=True
                    )
                    messages.error(
                        request,
                        _("Erreur lors de la création. Veuillez réessayer.")
                    )
            else:
                logger.warning(f"Form errors: {form.errors}")
                for field, errors in form.errors.items():
                    for error in errors:
                        messages.error(request, f"{field}: {error}")
        else:
            form = FederationCreationForm()
        
        context = {
            'form': form,
            'disciplines': disciplines,
            'step': 'federation_creation',
            'progress': 60,
        }
        
        return render(
            request,
            'competitions/onboarding/federation_creation.html',
            context
        )
    
    except Exception as e:
        logger.critical(f"Critical error in federation creation: {e}", exc_info=True)
        messages.error(
            request,
            _("Erreur technique. Notre équipe a été notifiée.")
        )
        return redirect('onboarding:error')


def onboarding_error(request):
    """Page d'erreur gracieuse pour l'onboarding"""
    return render(request, 'competitions/onboarding/error.html')


@login_required
def onboarding_complete(request):
    """Vue pour marquer l'onboarding comme terminé"""
    try:
        if hasattr(request.user, 'profile'):
            profile = request.user.profile
            profile.onboarding_completed = True
            profile.save()
            messages.success(
                request,
                _("Bienvenue sur MartialComp! Votre inscription est complète.")
            )
        
        # Rediriger selon le rôle
        if hasattr(request.user, 'profile'):
            role = request.user.profile.role
            if role == 'club_manager':
                return redirect('dashboard:club')
            elif role == 'federation_admin':
                return redirect('dashboard:federation')
        
        return redirect('dashboard')
    
    except Exception as e:
        logger.error(f"Error completing onboarding: {e}", exc_info=True)
        return redirect('dashboard')