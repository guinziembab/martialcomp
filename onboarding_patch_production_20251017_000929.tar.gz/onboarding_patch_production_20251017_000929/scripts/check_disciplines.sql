-- Script SQL pour vérifier les disciplines
SELECT COUNT(*) as total_disciplines FROM competitions_discipline;
SELECT COUNT(*) as active_disciplines FROM competitions_discipline WHERE is_active = true;
SELECT id, name, is_active FROM competitions_discipline ORDER BY name LIMIT 20;
