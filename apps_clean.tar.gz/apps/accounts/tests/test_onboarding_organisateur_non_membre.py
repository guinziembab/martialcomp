from django.test import Client, TestCase
from django.contrib.auth.models import User
from apps.organizations.models import Organization
from apps.accounts.models import OrganisateurNonMembre

class OrganisateurNonMembreOnboardingTest(TestCase):
    def setUp(self):
        self.client = Client()
        self.user = User.objects.create_user(username='testorg', password='testpass')
        self.org = Organization.objects.create(name='Test Org')
        self.profil = OrganisateurNonMembre.objects.create(user=self.user, organization=self.org)

    def test_onboarding_page(self):
        response = self.client.get('/accounts/onboarding/organisateur-non-membre/')
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, 'Profil : Organisateur non-membre')

    def test_dashboard_access(self):
        self.client.login(username='testorg', password='testpass')
        response = self.client.get('/accounts/dashboard/organisateur-non-membre/')
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, 'Tableau de bord - Organisateur non-membre') 
