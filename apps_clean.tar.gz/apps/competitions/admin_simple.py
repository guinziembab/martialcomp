"""
Configuration admin simplifiée pour Practitioner
Sans aucune référence aux disciplines pour éviter les erreurs
"""
from django.contrib import admin
from django.utils.translation import gettext_lazy as _
from apps.core.isolation import OrganizationIsolationMixin
from .models import Practitioner

@admin.register(Practitioner)
class SimplePractitionerAdmin(OrganizationIsolationMixin, admin.ModelAdmin):
    """Administration simplifiée sans disciplines"""
    
    list_display = (
        'full_name', 
        'get_organization',
        'birth_date', 
        'age', 
        'license_number'
    )
    list_filter = (
        'organization',
        'gender',
        'status'
    )
    search_fields = (
        'first_name', 
        'last_name', 
        'license_number',
        'email',
        'organization__name'
    )
    
    readonly_fields = ('age',)
    
    fieldsets = (
        (_('Informations personnelles'), {
            'fields': ('user', 'organization', 'first_name', 'last_name', 'birth_date', 'age', 'gender')
        }),
        (_('Informations de contact'), {
            'fields': ('email', 'phone', 'address', 'city', 'postal_code'),
            'classes': ('collapse',)
        }),
        (_('Documents et licences'), {
            'fields': ('license_number', 'medical_certificate_date', 'medical_certificate', 'parental_authorization'),
            'classes': ('collapse',)
        }),
        (_('Statut et métadonnées'), {
            'fields': ('status', 'is_active', 'notes', 'registration_date', 'membership_end_date'),
            'classes': ('collapse',)
        }),
    )
    
    def get_organization(self, obj):
        """Affiche l'organisation associée au pratiquant."""
        try:
            if hasattr(obj, 'organization') and obj.organization:
                return obj.organization.name
            return '-'
        except Exception as e:
            return f'Erreur: {e}'
    get_organization.short_description = 'Organisation'
    get_organization.admin_order_field = 'organization'
    
    def full_name(self, obj):
        try:
            return obj.full_name
        except Exception as e:
            return f'Erreur: {e}'
    full_name.short_description = 'Nom complet'
    full_name.admin_order_field = 'last_name'
    
    def get_queryset(self, request):
        queryset = super().get_queryset(request)
        try:
            queryset = queryset.select_related('organization', 'user')
        except Exception as e:
            pass
        return queryset