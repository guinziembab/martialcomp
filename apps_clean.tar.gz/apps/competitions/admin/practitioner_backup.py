from django.contrib import admin
from django.utils.translation import gettext_lazy as _
from django import forms
from django.core.exceptions import ValidationError
from django.db.models import Q
from apps.core.isolation import OrganizationIsolationMixin
from ..models import Practitioner

class SafeDisciplineFilter(admin.SimpleListFilter):
    """Filtre personnalisé pour les disciplines qui gère les erreurs"""
    title = _('Disciplines')
    parameter_name = 'disciplines'

    def lookups(self, request, model_admin):
        try:
            from ..models import Discipline
            return [(d.id, d.name) for d in Discipline.objects.all()]
        except Exception:
            return []

    def queryset(self, request, queryset):
        if self.value():
            try:
                return queryset.filter(disciplines__id=self.value())
            except Exception:
                return queryset
        return queryset

class PractitionerAdminForm(forms.ModelForm):
    """Formulaire personnalisé pour gérer les cas où les disciplines n'existent pas"""
    
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        
        try:
            from ..models import Discipline
            disciplines = Discipline.objects.all()
            if disciplines.exists():
                self.fields['disciplines'].queryset = disciplines
            else:
                self.fields['disciplines'].queryset = Discipline.objects.none()
                self.fields['disciplines'].help_text = "Aucune discipline disponible. Créez d'abord des disciplines."
        except Exception as e:
            if 'disciplines' in self.fields:
                self.fields['disciplines'].widget = forms.HiddenInput()
                self.fields['disciplines'].help_text = f"Erreur lors du chargement des disciplines: {e}"
    
    class Meta:
        model = Practitioner
        fields = '__all__'

@admin.register(Practitioner)
class PractitionerAdmin(OrganizationIsolationMixin, admin.ModelAdmin):
    form = PractitionerAdminForm
    
    list_display = (
        'full_name', 
        'get_organization',
        'birth_date', 
        'age', 
        'grade', 
        'get_disciplines',
        'license_number', 
        'medical_certificate_date'
    )
    list_filter = (
        'organization',
        'grade',
        SafeDisciplineFilter,  # Utilise le filtre sécurisé au lieu de 'disciplines'
        'gender',
        'status'
    )
    search_fields = (
        'first_name', 
        'last_name', 
        'license_number',
        'email',
        'disciplines__name',
        'organization__name'
    )
    
    readonly_fields = ('age',)
    filter_horizontal = ('disciplines',)
    
    fieldsets = (
        (_('Informations personnelles'), {
            'fields': ('user', 'organization', 'first_name', 'last_name', 'birth_date', 'age', 'gender')
        }),
        (_('Disciplines et grades'), {
            'fields': ('disciplines', 'primary_discipline', 'secondary_disciplines', 'grade', 'grade_text'),
            'classes': ('collapse',)
        }),
        (_('Informations de contact'), {
            'fields': ('email', 'phone', 'address', 'city', 'postal_code'),
            'classes': ('collapse',)
        }),
        (_('Documents et licences'), {
            'fields': ('license_number', 'medical_certificate_date', 'medical_certificate', 'parental_authorization'),
            'classes': ('collapse',)
        }),
        (_('Informations médicales'), {
            'fields': ('blood_group', 'allergies', 'medical_conditions'),
            'classes': ('collapse',)
        }),
        (_('Statut et métadonnées'), {
            'fields': ('status', 'is_active', 'notes', 'registration_date', 'membership_end_date'),
            'classes': ('collapse',)
        }),
    )

    def get_organization(self, obj):
        """Affiche l'organisation associée au pratiquant."""
        try:
            if hasattr(obj, 'organization') and obj.organization:
                return obj.organization.name
            return '-'
        except Exception as e:
            return f'Erreur: {e}'
    get_organization.short_description = 'Organisation'
    get_organization.admin_order_field = 'organization'
    
    def get_disciplines(self, obj):
        """Affiche la liste des disciplines pratiquées avec gestion d'erreur"""
        try:
            disciplines = obj.disciplines.all()
            if disciplines:
                return ', '.join([d.name for d in disciplines])
            return '-'
        except Exception as e:
            return f'Erreur: {e}'
    get_disciplines.short_description = 'Disciplines'
    get_disciplines.admin_order_field = 'disciplines'
    
    def full_name(self, obj):
        try:
            return obj.full_name
        except Exception as e:
            return f'Erreur: {e}'
    full_name.short_description = 'Nom complet'
    full_name.admin_order_field = 'last_name'
    
    def get_queryset(self, request):
        queryset = super().get_queryset(request)
        try:
            queryset = queryset.select_related('organization', 'user')
            queryset = queryset.prefetch_related('disciplines')
        except Exception as e:
            pass
        return queryset
    
    def formfield_for_foreignkey(self, db_field, request, **kwargs):
        try:
            if db_field.name == "organization":
                from apps.organizations.models import Organization
                kwargs["queryset"] = Organization.objects.filter(
                    organization_type__in=['club', 'academy']
                ).order_by('name')
        except Exception as e:
            pass
        return super().formfield_for_foreignkey(db_field, request, **kwargs)
    
    def formfield_for_manytomany(self, db_field, request, **kwargs):
        try:
            if db_field.name == "disciplines":
                from ..models import Discipline
                kwargs["queryset"] = Discipline.objects.all()
        except Exception as e:
            kwargs["queryset"] = Discipline.objects.none()
        return super().formfield_for_manytomany(db_field, request, **kwargs)
    
    def export_as_csv(self, request, queryset):
        """Action pour exporter les pratiquants en CSV"""
        import csv
        from django.http import HttpResponse
        
        response = HttpResponse(content_type='text/csv')
        response['Content-Disposition'] = 'attachment; filename="practitioners.csv"'
        
        writer = csv.writer(response)
        writer.writerow(['Nom', 'Prénom', 'Organisation', 'Email', 'Disciplines'])
        
        for practitioner in queryset:
            disciplines = ', '.join([d.name for d in practitioner.disciplines.all()])
            writer.writerow([
                practitioner.last_name,
                practitioner.first_name,
                practitioner.organization.name if practitioner.organization else '',
                practitioner.email or '',
                disciplines
            ])
        
        return response
    
    actions = ['export_as_csv']
    export_as_csv.short_description = "Exporter les pratiquants sélectionnés en CSV"