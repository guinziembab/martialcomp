from django.contrib import admin
from django.utils.translation import gettext_lazy as _
from django import forms
from django.core.exceptions import ValidationError
from django.db.models import Q, Prefetch
from apps.core.isolation import OrganizationIsolationMixin
from ..models import Practitioner

class SafeDisciplineFilter(admin.SimpleListFilter):
    """Filtre personnalisé pour les disciplines qui gère les erreurs"""
    title = _('Disciplines')
    parameter_name = 'disciplines'

    def lookups(self, request, model_admin):
        try:
            from ..models import Discipline
            # Only show disciplines that actually exist
            return [(d.id, d.name) for d in Discipline.objects.all().order_by('name')]
        except Exception as e:
            import logging
            logging.getLogger(__name__).error(f"Error loading disciplines for filter: {e}")
            return []

    def queryset(self, request, queryset):
        if self.value():
            try:
                # Use filter with exists check instead of direct get
                return queryset.filter(disciplines__id=self.value()).distinct()
            except Exception as e:
                import logging
                logging.getLogger(__name__).error(f"Error filtering by discipline: {e}")
                return queryset
        return queryset

class PractitionerAdminForm(forms.ModelForm):
    """Formulaire personnalisé pour gérer les cas où les disciplines n'existent pas"""
    
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        
        # Safely handle disciplines field
        if 'disciplines' in self.fields:
            try:
                from ..models import Discipline
                # Use exists() to check before accessing
                if Discipline.objects.exists():
                    self.fields['disciplines'].queryset = Discipline.objects.all().order_by('name')
                else:
                    self.fields['disciplines'].queryset = Discipline.objects.none()
                    self.fields['disciplines'].widget.attrs['disabled'] = True
                    self.fields['disciplines'].help_text = _("Aucune discipline disponible")
            except Exception as e:
                import logging
                logging.getLogger(__name__).error(f"Error setting up disciplines field: {e}")
                self.fields['disciplines'].queryset = Discipline.objects.none()
                self.fields['disciplines'].widget.attrs['disabled'] = True
    
    class Meta:
        model = Practitioner
        fields = '__all__'

# @admin.register(Practitioner)  # DÉSACTIVÉ - Conflit avec admin.py
class PractitionerAdmin(OrganizationIsolationMixin, admin.ModelAdmin):
    form = PractitionerAdminForm
    
    list_display = (
        'full_name', 
        'get_organization',
        'birth_date', 
        'age', 
        'grade', 
        'get_disciplines_safe',  # Changed to safe version
        'license_number', 
        'medical_certificate_date'
    )
    list_filter = (
        'organization',
        'grade',
        SafeDisciplineFilter,
        'gender',
        'status'
    )
    search_fields = (
        'first_name', 
        'last_name', 
        'license_number',
        'email',
        'organization__name'
    )
    
    readonly_fields = ('age',)
    filter_horizontal = ('disciplines',)
    
    fieldsets = (
        (_('Informations personnelles'), {
            'fields': ('user', 'organization', 'first_name', 'last_name', 'birth_date', 'age', 'gender')
        }),
        (_('Disciplines et grades'), {
            'fields': ('disciplines', 'primary_discipline', 'secondary_disciplines', 'grade', 'grade_text'),
            'classes': ('collapse',)
        }),
        (_('Informations de contact'), {
            'fields': ('email', 'phone', 'address', 'city', 'postal_code'),
            'classes': ('collapse',)
        }),
        (_('Documents et licences'), {
            'fields': ('license_number', 'medical_certificate_date', 'medical_certificate', 'parental_authorization'),
            'classes': ('collapse',)
        }),
        (_('Informations médicales'), {
            'fields': ('blood_group', 'allergies', 'medical_conditions'),
            'classes': ('collapse',)
        }),
        (_('Statut et métadonnées'), {
            'fields': ('status', 'is_active', 'notes', 'registration_date', 'membership_end_date'),
            'classes': ('collapse',)
        }),
    )

    def get_organization(self, obj):
        """Affiche l'organisation associée au pratiquant."""
        try:
            return obj.organization.name if obj.organization else '-'
        except Exception as e:
            import logging
            logging.getLogger(__name__).error(f"Error getting organization for practitioner {obj.id}: {e}")
            return _('Erreur')
    get_organization.short_description = _('Organisation')
    get_organization.admin_order_field = 'organization__name'
    
    def get_disciplines_safe(self, obj):
        """Affiche la liste des disciplines pratiquées avec gestion d'erreur complète"""
        try:
            # Use prefetch_related data if available
            if hasattr(obj, '_prefetched_objects_cache') and 'disciplines' in obj._prefetched_objects_cache:
                disciplines = obj._prefetched_objects_cache['disciplines']
            else:
                # Use exists() first to avoid unnecessary queries
                if obj.disciplines.exists():
                    disciplines = list(obj.disciplines.all())
                else:
                    return '-'
            
            if disciplines:
                return ', '.join([d.name for d in disciplines])
            return '-'
        except Exception as e:
            import logging
            logging.getLogger(__name__).error(f"Error getting disciplines for practitioner {obj.id}: {e}")
            return _('Erreur')
    get_disciplines_safe.short_description = _('Disciplines')
    
    def full_name(self, obj):
        try:
            return obj.full_name
        except Exception as e:
            import logging
            logging.getLogger(__name__).error(f"Error getting full name for practitioner {obj.id}: {e}")
            return f"{obj.first_name} {obj.last_name}"
    full_name.short_description = _('Nom complet')
    full_name.admin_order_field = 'last_name'
    
    def get_queryset(self, request):
        """Optimized queryset with safe prefetching"""
        queryset = super().get_queryset(request)
        try:
            # Use select_related for ForeignKey fields
            queryset = queryset.select_related('organization', 'user', 'grade')
            
            # Safe prefetch for disciplines
            from ..models import Discipline
            # Only prefetch if disciplines exist
            if Discipline.objects.exists():
                queryset = queryset.prefetch_related(
                    Prefetch('disciplines', queryset=Discipline.objects.all())
                )
        except Exception as e:
            import logging
            logging.getLogger(__name__).error(f"Error optimizing queryset: {e}")
            # Return base queryset if optimization fails
            pass
        return queryset
    
    def formfield_for_foreignkey(self, db_field, request, **kwargs):
        try:
            if db_field.name == "organization":
                from apps.organizations.models import Organization
                kwargs["queryset"] = Organization.objects.filter(
                    organization_type__in=['club', 'academy']
                ).order_by('name')
            elif db_field.name == "primary_discipline":
                from ..models import Discipline
                if Discipline.objects.exists():
                    kwargs["queryset"] = Discipline.objects.all().order_by('name')
                else:
                    kwargs["queryset"] = Discipline.objects.none()
        except Exception as e:
            import logging
            logging.getLogger(__name__).error(f"Error in formfield_for_foreignkey: {e}")
        return super().formfield_for_foreignkey(db_field, request, **kwargs)
    
    def formfield_for_manytomany(self, db_field, request, **kwargs):
        try:
            if db_field.name in ["disciplines", "secondary_disciplines"]:
                from ..models import Discipline
                if Discipline.objects.exists():
                    kwargs["queryset"] = Discipline.objects.all().order_by('name')
                else:
                    kwargs["queryset"] = Discipline.objects.none()
        except Exception as e:
            import logging
            logging.getLogger(__name__).error(f"Error in formfield_for_manytomany: {e}")
            # Ensure we always have a queryset
            if db_field.name in ["disciplines", "secondary_disciplines"]:
                from ..models import Discipline
                kwargs["queryset"] = Discipline.objects.none()
        return super().formfield_for_manytomany(db_field, request, **kwargs)
    
    def export_as_csv(self, request, queryset):
        """Action pour exporter les pratiquants en CSV"""
        import csv
        from django.http import HttpResponse
        
        response = HttpResponse(content_type='text/csv')
        response['Content-Disposition'] = 'attachment; filename="practitioners.csv"'
        
        writer = csv.writer(response)
        writer.writerow(['Nom', 'Prénom', 'Organisation', 'Email', 'Disciplines'])
        
        for practitioner in queryset:
            try:
                disciplines = ', '.join([d.name for d in practitioner.disciplines.all()])
            except:
                disciplines = '-'
            
            writer.writerow([
                practitioner.last_name,
                practitioner.first_name,
                practitioner.organization.name if practitioner.organization else '',
                practitioner.email or '',
                disciplines
            ])
        
        return response
    
    actions = ['export_as_csv']
    export_as_csv.short_description = "Exporter les pratiquants sélectionnés en CSV"

    class Media:
        css = {
            'all': ('admin/css/practitioner_admin.css',)
        }
        js = ('admin/js/practitioner_admin.js',)