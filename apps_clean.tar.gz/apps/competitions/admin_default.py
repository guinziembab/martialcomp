"""
Administration par défaut Django pour Practitioner
Utilise uniquement les fonctionnalités de base de Django admin
"""
from django.contrib import admin
from .models import Practitioner

# Désenregistrer toute administration existante
try:
    admin.site.unregister(Practitioner)
except:
    pass

# Enregistrer avec l'admin par défaut
admin.site.register(Practitioner)