"""
Management command pour créer un tenant de développement
"""
from django.core.management.base import BaseCommand
from django.utils import timezone
from apps.competitions.models import Federation
from apps.organizations.models import Organization
from apps.multitenant.models import Tenant
from apps.competitions.utils.subdomain_generator import SubdomainGenerator


class Command(BaseCommand):
    help = 'Crée un tenant pour une fédération en développement'

    def add_arguments(self, parser):
        parser.add_argument(
            'federation_slug',
            type=str,
            help='Slug de la fédération (ex: fedetest99)'
        )
        parser.add_argument(
            '--domain',
            type=str,
            default='localhost:8000',
            help='Domaine de base pour le développement (défaut: localhost:8000)'
        )

    def handle(self, *args, **options):
        federation_slug = options['federation_slug']
        base_domain = options['domain']
        
        self.stdout.write(f"ðŸ” Recherche de la fédération '{federation_slug}'...")
        
        try:
            federation = Federation.objects.get(slug=federation_slug)
            self.stdout.write(
                self.style.SUCCESS(f"âœ… Fédération trouvée: {federation.name}")
            )
        except Federation.DoesNotExist:
            self.stdout.write(
                self.style.ERROR(f"âŒ Fédération '{federation_slug}' non trouvée")
            )
            return
        
        if not federation.organization:
            self.stdout.write(
                self.style.ERROR("âŒ Aucune organisation associée Ã  cette fédération")
            )
            return
            
        self.stdout.write(f"âœ… Organisation associée: {federation.organization.name}")
        
        # Générer le sous-domaine
        generator = SubdomainGenerator()
        subdomain = generator.generate_subdomain(federation.organization)
        
        # Pour le dev local, utiliser un domaine simple
        dev_domain = f"{subdomain}.{base_domain}"
        schema_name = subdomain.replace('-', '_')[:63]
        
        self.stdout.write(f"ðŸ“ Sous-domaine généré: {subdomain}")
        self.stdout.write(f"ðŸŒ Domaine de dev: {dev_domain}")
        
        # Vérifier si un tenant existe déjÃ 
        existing_tenant = Tenant.objects.filter(slug=subdomain).first()
        if existing_tenant:
            self.stdout.write(
                self.style.WARNING(f"âš ï¸  Tenant existant: {existing_tenant.domain}")
            )
            if existing_tenant.is_active:
                self.stdout.write("   Status: Actif")
                return existing_tenant
            else:
                self.stdout.write("   Status: Inactif - Réactivation...")
                existing_tenant.is_active = True
                existing_tenant.domain = dev_domain
                existing_tenant.save()
                return existing_tenant
        
        # Créer le tenant pour le développement
        self.stdout.write("ðŸš€ Création du tenant de développement...")
        
        tenant = Tenant.objects.create(
            name=federation.organization.name,
            slug=subdomain,
            schema_name=schema_name,
            domain=dev_domain,
            continent='europe_west',
            country='FR',
            timezone='Europe/Paris',
            currency='EUR',
            language='fr',
            subscription_plan='masters',
            is_active=True,
            activated_at=timezone.now(),
            owner=federation.owner if federation.owner else None
        )
        
        self.stdout.write(
            self.style.SUCCESS("âœ… Tenant créé avec succès!")
        )
        self.stdout.write(f"   ðŸŒ Domaine: {tenant.domain}")
        self.stdout.write(f"   ðŸ“Š Schema: {tenant.schema_name}")
        self.stdout.write(f"   ðŸ‘¤ Propriétaire: {tenant.owner}")
        
        self.stdout.write("\n" + "="*50)
        self.stdout.write("ðŸ§ª INSTRUCTIONS POUR TESTER EN LOCAL:")
        self.stdout.write("="*50)
        self.stdout.write(f"1. Ajouter Ã  votre fichier hosts (C:\\Windows\\System32\\drivers\\etc\\hosts):")
        self.stdout.write(f"   127.0.0.1    {subdomain}.localhost")
        self.stdout.write(f"\n2. Démarrer le serveur Django:")
        self.stdout.write(f"   python manage.py runserver 0.0.0.0:8000")
        self.stdout.write(f"\n3. Accéder au sous-domaine:")
        self.stdout.write(f"   http://{subdomain}.localhost:8000")
        self.stdout.write("="*50)
        
        return tenant

