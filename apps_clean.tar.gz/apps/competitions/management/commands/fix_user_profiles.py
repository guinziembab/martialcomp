from django.core.management.base import BaseCommand
from django.contrib.auth import get_user_model
from apps.competitions.models import UserProfile

User = get_user_model()

class Command(BaseCommand):
    help = 'Fix tous les profils utilisateur problématiques'

    def add_arguments(self, parser):
        parser.add_argument(
            '--dry-run',
            action='store_true',
            help='Afficher les changements sans les appliquer'
        )
        parser.add_argument(
            '--complete-onboarding',
            action='store_true',
            help='Marquer tous les profils comme ayant complété l\'onboarding'
        )

    def handle(self, *args, **options):
        dry_run = options['dry_run']
        complete_onboarding = options['complete_onboarding']
        
        self.stdout.write("=== CORRECTION DES PROFILS UTILISATEUR ===\n")
        
        fixed_count = 0
        created_count = 0
        
        # Vérifier tous les utilisateurs
        for user in User.objects.all():
            try:
                profile = user.profile
                needs_fix = False
                changes = []
                
                # Vérifier si l'onboarding est en boucle
                if not profile.onboarding_completed and complete_onboarding:
                    if not dry_run:
                        profile.onboarding_completed = True
                        profile.onboarding_step = 'completed'
                    changes.append("onboarding complété")
                    needs_fix = True
                
                # Nettoyer les étapes d'onboarding obsolètes
                if profile.onboarding_step == 'role_selection':
                    if not dry_run:
                        profile.onboarding_step = 'role'
                    changes.append("étape d'onboarding nettoyée")
                    needs_fix = True
                
                # Définir un rÃ´le par défaut si manquant
                if not profile.role:
                    if not dry_run:
                        profile.role = 'spectator'
                    changes.append("rÃ´le défini")
                    needs_fix = True
                
                # Sauvegarder les changements
                if needs_fix:
                    if not dry_run:
                        profile.save()
                    fixed_count += 1
                    status = "ðŸ”§ CORRIGÃ‰" if not dry_run else "ðŸ“‹ Ã€ CORRIGER"
                    self.stdout.write(f"{status}: {user.username} - {', '.join(changes)}")
                
            except UserProfile.DoesNotExist:
                # Créer le profil manquant
                if not dry_run:
                    profile = UserProfile.objects.create(
                        user=user,
                        role='spectator',
                        onboarding_completed=complete_onboarding,
                        onboarding_step='completed' if complete_onboarding else 'role'
                    )
                created_count += 1
                status = "âœ… CRÃ‰Ã‰" if not dry_run else "ðŸ“‹ Ã€ CRÃ‰ER"
                self.stdout.write(f"{status}: Profil pour {user.username}")
        
        # Résumé
        self.stdout.write("\n" + "="*50)
        self.stdout.write("RÃ‰SUMÃ‰:")
        if dry_run:
            self.stdout.write(self.style.WARNING(f"MODE DRY-RUN - Aucun changement appliqué"))
        self.stdout.write(f"Profils corrigés: {fixed_count}")
        self.stdout.write(f"Profils créés: {created_count}")
        
        if dry_run:
            self.stdout.write("\nPour appliquer les changements:")
            self.stdout.write("python manage.py fix_user_profiles")
            if complete_onboarding:
                self.stdout.write("python manage.py fix_user_profiles --complete-onboarding")
        else:
            self.stdout.write(self.style.SUCCESS("âœ… Correction terminée"))

