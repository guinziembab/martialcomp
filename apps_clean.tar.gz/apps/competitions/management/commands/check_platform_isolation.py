# -*- coding: utf-8 -*-
"""
Script de vérification de l'étanchéité de la plateforme entre organisations
Directive de Segmentation MartialComp - Audit de Sécurité
"""

from django.core.management.base import BaseCommand
from django.contrib.auth.models import User
from django.db import connection
from django.apps import apps
from django.test import Client
import json
from datetime import datetime
import logging

logger = logging.getLogger(__name__)


class Command(BaseCommand):
    help = 'Vérifie l\'étanchéité de la plateforme entre organisations'
    
    def add_arguments(self, parser):
        parser.add_argument('--output', type=str, help='Fichier de sortie pour le rapport')
        parser.add_argument('--fix', action='store_true', help='Corriger automatiquement les problèmes détectés')
    
    def handle(self, *args, **options):
        self.report = {
            'timestamp': datetime.now().isoformat(),
            'tests': [],
            'vulnerabilities': [],
            'summary': {}
        }
        
        self.stdout.write(self.style.SUCCESS('Démarrage de l\'audit de segmentation...'))
        
        # Tests principaux
        self.test_user_organization_isolation()
        self.test_practitioner_visibility()
        self.test_competition_isolation()
        self.test_document_access()
        self.test_api_endpoints()
        self.test_admin_interface()
        
        # Générer le rapport
        self.generate_report(options.get('output'))
        
        # Corriger si demandé
        if options.get('fix'):
            self.fix_vulnerabilities()
    
    def test_user_organization_isolation(self):
        """Test 1: Vérifier que les utilisateurs ne voient que leur organisation."""
        self.stdout.write('Test 1: Isolation des utilisateurs par organisation...')
        
        test_result = {
            'name': 'User Organization Isolation',
            'status': 'PASSED',
            'details': [],
            'vulnerabilities': []
        }
        
        try:
            from apps.competitions.models import Organization
            from apps.membership.models import MembershipSubscription
            
            organizations = Organization.objects.all()[:5]  # Tester sur 5 orgs max
            
            for org in organizations:
                # Chercher des utilisateurs liés à cette organisation
                subscriptions = MembershipSubscription.objects.filter(
                    package__organization=org,
                    status='active'
                )[:5]
                
                for subscription in subscriptions:
                    user = subscription.practitioner.user
                    if user:
                        # Vérifier que l'utilisateur n'a accès qu'à son organisation
                        accessible_orgs = self._get_accessible_organizations(user)
                        
                        if len(accessible_orgs) > 1:
                            vulnerability = {
                                'severity': 'HIGH',
                                'user': user.username,
                                'organization': org.name,
                                'accessible_organizations': [o.name for o in accessible_orgs],
                                'description': f'Utilisateur a accès à {len(accessible_orgs)} organisations'
                            }
                            test_result['vulnerabilities'].append(vulnerability)
                            test_result['status'] = 'FAILED'
        
        except Exception as e:
            test_result['status'] = 'ERROR'
            test_result['details'].append(f'Erreur: {str(e)}')
        
        self.report['tests'].append(test_result)
        
        if test_result['status'] == 'PASSED':
            self.stdout.write(self.style.SUCCESS('  ✅ PASSED'))
        elif test_result['status'] == 'ERROR':
            self.stdout.write(self.style.WARNING(f'  ⚠️ ERROR - {test_result["details"]}'))
        else:
            self.stdout.write(self.style.ERROR(f'  ❌ FAILED - {len(test_result["vulnerabilities"])} vulnérabilités'))
    
    def test_practitioner_visibility(self):
        """Test 2: Vérifier que les pratiquants ne sont visibles qu'au sein de leur organisation."""
        self.stdout.write('Test 2: Isolation des pratiquants...')
        
        test_result = {
            'name': 'Practitioner Visibility',
            'status': 'PASSED',
            'details': [],
            'vulnerabilities': []
        }
        
        try:
            from apps.competitions.models import Practitioner, Organization
            
            # Prendre 2 organisations différentes
            orgs = list(Organization.objects.all()[:2])
            if len(orgs) < 2:
                test_result['status'] = 'SKIPPED'
                test_result['details'].append('Pas assez d\'organisations pour tester')
                self.report['tests'].append(test_result)
                return
            
            org1, org2 = orgs[0], orgs[1]
            
            # Récupérer les pratiquants de chaque organisation
            practitioners_org1 = list(Practitioner.objects.filter(organization=org1)[:5])
            practitioners_org2 = list(Practitioner.objects.filter(organization=org2)[:5])
            
            # Vérifier que les pratiquants de org1 ne sont pas visibles depuis org2
            for practitioner in practitioners_org1:
                # Simuler une requête depuis org2
                visible_from_org2 = self._check_practitioner_visibility(practitioner, org2)
                
                if visible_from_org2:
                    vulnerability = {
                        'severity': 'HIGH',
                        'practitioner': f'{practitioner.first_name} {practitioner.last_name}',
                        'origin_organization': org1.name,
                        'visible_from': org2.name,
                        'description': 'Pratiquant visible depuis une autre organisation'
                    }
                    test_result['vulnerabilities'].append(vulnerability)
                    test_result['status'] = 'FAILED'
        
        except Exception as e:
            test_result['status'] = 'ERROR'
            test_result['details'].append(f'Erreur: {str(e)}')
        
        self.report['tests'].append(test_result)
        
        if test_result['status'] == 'PASSED':
            self.stdout.write(self.style.SUCCESS('  ✅ PASSED'))
        elif test_result['status'] == 'SKIPPED':
            self.stdout.write(self.style.WARNING('  ⚠️ SKIPPED'))
        elif test_result['status'] == 'ERROR':
            self.stdout.write(self.style.WARNING(f'  ⚠️ ERROR - {test_result["details"]}'))
        else:
            self.stdout.write(self.style.ERROR(f'  ❌ FAILED - {len(test_result["vulnerabilities"])} vulnérabilités'))
    
    def test_competition_isolation(self):
        """Test 3: Vérifier l'isolation des compétitions (sauf participants)."""
        self.stdout.write('Test 3: Isolation des compétitions...')
        
        test_result = {
            'name': 'Competition Isolation',
            'status': 'PASSED',
            'details': [],
            'vulnerabilities': []
        }
        
        try:
            from apps.competitions.models import Competition
            
            competitions = Competition.objects.all()[:5]
            
            for competition in competitions:
                # Vérifier qui peut voir cette compétition
                visible_orgs = self._get_organizations_with_competition_access(competition)
                expected_orgs = self._get_expected_competition_visibility(competition)
                
                unexpected_access = set(visible_orgs) - set(expected_orgs)
                
                if unexpected_access:
                    vulnerability = {
                        'severity': 'MEDIUM',
                        'competition': competition.name,
                        'unexpected_access': [org.name for org in unexpected_access],
                        'description': 'Compétition visible par des organisations non autorisées'
                    }
                    test_result['vulnerabilities'].append(vulnerability)
                    test_result['status'] = 'FAILED'
        
        except Exception as e:
            test_result['status'] = 'ERROR'
            test_result['details'].append(f'Erreur: {str(e)}')
        
        self.report['tests'].append(test_result)
        
        if test_result['status'] == 'PASSED':
            self.stdout.write(self.style.SUCCESS('  ✅ PASSED'))
        elif test_result['status'] == 'ERROR':
            self.stdout.write(self.style.WARNING(f'  ⚠️ ERROR - {test_result["details"]}'))
        else:
            self.stdout.write(self.style.ERROR(f'  ❌ FAILED - {len(test_result["vulnerabilities"])} vulnérabilités'))
    
    def test_document_access(self):
        """Test 4: Vérifier l'accès aux documents."""
        self.stdout.write('Test 4: Isolation des documents...')
        
        test_result = {
            'name': 'Document Access Control',
            'status': 'PASSED',
            'details': [],
            'vulnerabilities': []
        }
        
        # Vérifier l'accès aux fichiers uploadés
        try:
            from apps.documents.models import Document
            documents = Document.objects.all()[:10]
            
            for document in documents:
                # Vérifier les permissions d'accès
                unauthorized_access = self._check_document_unauthorized_access(document)
                
                if unauthorized_access:
                    vulnerability = {
                        'severity': 'HIGH',
                        'document': document.name,
                        'unauthorized_users': unauthorized_access,
                        'description': 'Document accessible par des utilisateurs non autorisés'
                    }
                    test_result['vulnerabilities'].append(vulnerability)
                    test_result['status'] = 'FAILED'
        
        except ImportError:
            test_result['status'] = 'SKIPPED'
            test_result['details'].append('Module documents non disponible')
        except Exception as e:
            test_result['status'] = 'ERROR'
            test_result['details'].append(f'Erreur: {str(e)}')
        
        self.report['tests'].append(test_result)
        
        if test_result['status'] == 'PASSED':
            self.stdout.write(self.style.SUCCESS('  ✅ PASSED'))
        elif test_result['status'] == 'SKIPPED':
            self.stdout.write(self.style.WARNING('  ⚠️ SKIPPED'))
        elif test_result['status'] == 'ERROR':
            self.stdout.write(self.style.WARNING(f'  ⚠️ ERROR - {test_result["details"]}'))
        else:
            self.stdout.write(self.style.ERROR(f'  ❌ FAILED - {len(test_result["vulnerabilities"])} vulnérabilités'))
    
    def test_api_endpoints(self):
        """Test 5: Vérifier la sécurité des endpoints API."""
        self.stdout.write('Test 5: Sécurité des APIs...')
        
        test_result = {
            'name': 'API Security',
            'status': 'PASSED',
            'details': [],
            'vulnerabilities': []
        }
        
        # Liste des endpoints critiques à tester
        critical_endpoints = [
            '/api/practitioners/',
            '/api/competitions/',
            '/api/organizations/',
            '/api/users/',
        ]
        
        try:
            # Créer des utilisateurs de test de différentes organisations
            test_users = self._create_test_users()
            
            for endpoint in critical_endpoints:
                for user in test_users:
                    # Tester l'accès avec chaque utilisateur
                    client = Client()
                    client.force_login(user)
                    
                    try:
                        response = client.get(endpoint)
                        if response.status_code == 200:
                            # Vérifier que les données retournées appartiennent à l'organisation de l'utilisateur
                            if hasattr(response, 'json'):
                                cross_org_data = self._check_cross_organization_data(response.json(), user)
                                
                                if cross_org_data:
                                    vulnerability = {
                                        'severity': 'CRITICAL',
                                        'endpoint': endpoint,
                                        'user': user.username,
                                        'cross_org_data': cross_org_data,
                                        'description': 'API retourne des données d\'autres organisations'
                                    }
                                    test_result['vulnerabilities'].append(vulnerability)
                                    test_result['status'] = 'FAILED'
                    
                    except Exception as e:
                        test_result['details'].append(f'Erreur lors du test de {endpoint}: {str(e)}')
        
        except Exception as e:
            test_result['status'] = 'ERROR'
            test_result['details'].append(f'Erreur générale: {str(e)}')
        
        self.report['tests'].append(test_result)
        
        if test_result['status'] == 'PASSED':
            self.stdout.write(self.style.SUCCESS('  ✅ PASSED'))
        elif test_result['status'] == 'ERROR':
            self.stdout.write(self.style.WARNING(f'  ⚠️ ERROR - {test_result["details"]}'))
        else:
            self.stdout.write(self.style.ERROR(f'  ❌ FAILED - {len(test_result["vulnerabilities"])} vulnérabilités'))
    
    def test_admin_interface(self):
        """Test 6: Vérifier que l'interface admin respecte la segmentation."""
        self.stdout.write('Test 6: Interface d\'administration...')
        
        test_result = {
            'name': 'Admin Interface Security',
            'status': 'PASSED',
            'details': [],
            'vulnerabilities': []
        }
        
        try:
            # Vérifier que les filtres par organisation sont en place
            admin_models_to_check = [
                'competitions.Practitioner',
                'competitions.Competition',
                'membership.MembershipPackage',
            ]
            
            for model_path in admin_models_to_check:
                try:
                    app_label, model_name = model_path.split('.')
                    model = apps.get_model(app_label, model_name)
                    
                    # Vérifier si le modèle a un admin personnalisé avec filtrage
                    has_organization_filter = self._check_admin_organization_filter(model)
                    
                    if not has_organization_filter:
                        vulnerability = {
                            'severity': 'MEDIUM',
                            'model': model_path,
                            'description': 'Modèle admin sans filtrage par organisation'
                        }
                        test_result['vulnerabilities'].append(vulnerability)
                        test_result['status'] = 'FAILED'
                except Exception as e:
                    test_result['details'].append(f'Erreur pour {model_path}: {str(e)}')
        
        except Exception as e:
            test_result['status'] = 'ERROR'
            test_result['details'].append(f'Erreur générale: {str(e)}')
        
        self.report['tests'].append(test_result)
        
        if test_result['status'] == 'PASSED':
            self.stdout.write(self.style.SUCCESS('  ✅ PASSED'))
        elif test_result['status'] == 'ERROR':
            self.stdout.write(self.style.WARNING(f'  ⚠️ ERROR - {test_result["details"]}'))
        else:
            self.stdout.write(self.style.ERROR(f'  ❌ FAILED - {len(test_result["vulnerabilities"])} vulnérabilités'))
    
    # Méthodes d'aide pour les tests
    def _get_accessible_organizations(self, user):
        """Retourne les organisations accessibles à un utilisateur."""
        try:
            from apps.membership.models import MembershipSubscription
            
            subscriptions = MembershipSubscription.objects.filter(
                practitioner__user=user,
                status='active'
            ).select_related('package__organization')
            
            return [s.package.organization for s in subscriptions if s.package.organization]
        except Exception:
            return []
    
    def _check_practitioner_visibility(self, practitioner, from_organization):
        """Vérifie si un pratiquant est visible depuis une autre organisation."""
        try:
            from apps.competitions.models import Practitioner
            from apps.core.isolation import OrganizationSecureManager
            
            # Créer un utilisateur fictif de from_organization pour simuler l'accès
            test_user = type('MockUser', (), {
                'is_authenticated': True,
                'is_superuser': False,
                'is_staff': False,
                '_cached_organization': from_organization
            })()
            
            # Utiliser le manager sécurisé pour vérifier la visibilité
            secure_manager = OrganizationSecureManager()
            secure_manager.model = Practitioner
            
            # Si le pratiquant est visible depuis from_organization alors qu'il appartient à une autre
            accessible_practitioners = secure_manager.for_user(test_user).filter(id=practitioner.id)
            
            # C'est une vulnérabilité si:
            # 1. Le pratiquant appartient à une organisation différente
            # 2. ET il est quand même accessible
            is_cross_org = (hasattr(practitioner, 'organization') and 
                          practitioner.organization != from_organization)
            is_accessible = accessible_practitioners.exists()
            
            return is_cross_org and is_accessible
        except Exception:
            return False
    
    def _get_organizations_with_competition_access(self, competition):
        """Retourne les organisations qui ont accès à une compétition."""
        # Logique pour déterminer qui peut voir une compétition
        visible_orgs = set()
        
        # L'organisation organisatrice
        if hasattr(competition, 'organization'):
            visible_orgs.add(competition.organization)
        
        # Les organisations des participants
        try:
            from apps.competitions.models import CompetitionRegistration
            registrations = CompetitionRegistration.objects.filter(
                competition=competition
            ).select_related('practitioner__organization')
            
            for reg in registrations:
                if hasattr(reg.practitioner, 'organization') and reg.practitioner.organization:
                    visible_orgs.add(reg.practitioner.organization)
        except Exception:
            pass
        
        return list(visible_orgs)
    
    def _get_expected_competition_visibility(self, competition):
        """Retourne les organisations qui devraient avoir accès à une compétition."""
        return self._get_organizations_with_competition_access(competition)
    
    def _check_document_unauthorized_access(self, document):
        """Vérifie l'accès non autorisé à un document."""
        # Retourne la liste des utilisateurs qui ont accès mais ne devraient pas
        unauthorized = []
        
        # Logique de vérification des permissions de document
        # À implémenter selon votre modèle de documents
        
        return unauthorized
    
    def _create_test_users(self):
        """Crée des utilisateurs de test pour différentes organisations."""
        try:
            from apps.competitions.models import Organization
            from apps.membership.models import MembershipSubscription
            
            test_users = []
            organizations = Organization.objects.all()[:3]
            
            for i, org in enumerate(organizations):
                # Chercher un utilisateur existant dans cette organisation
                subscription = MembershipSubscription.objects.filter(
                    package__organization=org,
                    status='active',
                    practitioner__user__isnull=False
                ).select_related('practitioner__user').first()
                
                if subscription and subscription.practitioner.user:
                    test_users.append(subscription.practitioner.user)
            
            return test_users
        except Exception:
            return []
    
    def _check_cross_organization_data(self, api_response, user):
        """Vérifie si une réponse API contient des données d'autres organisations."""
        # Analyser la réponse JSON pour détecter des données cross-org
        cross_org_items = []
        
        try:
            user_org = self._get_user_organization_for_test(user)
            if not user_org:
                return []
            
            # Logique d'analyse selon le format de votre API
            # Exemple pour une liste de pratiquants
            if isinstance(api_response, dict) and 'results' in api_response:
                for item in api_response['results']:
                    if 'organization' in item and item['organization'] != user_org.id:
                        cross_org_items.append(item['id'])
        except Exception:
            pass
        
        return cross_org_items
    
    def _get_user_organization_for_test(self, user):
        """Récupère l'organisation d'un utilisateur pour les tests."""
        try:
            from apps.membership.models import MembershipSubscription
            
            subscription = MembershipSubscription.objects.filter(
                practitioner__user=user,
                status='active'
            ).select_related('package__organization').first()
            
            return subscription.package.organization if subscription else None
        except Exception:
            return None
    
    def _check_admin_organization_filter(self, model):
        """Vérifie si un modèle admin a un filtrage par organisation."""
        try:
            from django.contrib import admin
            from apps.core.isolation import OrganizationSecureAdminMixin
            
            admin_class = admin.site._registry.get(model)
            if admin_class:
                # Vérifier si l'admin utilise le mixin de sécurité
                # Chercher dans les bases de la classe admin
                base_classes = [base.__name__ for base in admin_class.__class__.__bases__]
                is_secure = 'OrganizationSecureAdminMixin' in base_classes
                
                return is_secure
            return False
        except Exception as e:
            return False
    
    def generate_report(self, output_file):
        """Génère le rapport final."""
        total_tests = len(self.report['tests'])
        passed_tests = len([t for t in self.report['tests'] if t['status'] == 'PASSED'])
        failed_tests = len([t for t in self.report['tests'] if t['status'] == 'FAILED'])
        skipped_tests = len([t for t in self.report['tests'] if t['status'] == 'SKIPPED'])
        error_tests = len([t for t in self.report['tests'] if t['status'] == 'ERROR'])
        
        total_vulnerabilities = sum(len(t.get('vulnerabilities', [])) for t in self.report['tests'])
        critical_vulnerabilities = sum(
            len([v for v in t.get('vulnerabilities', []) if v.get('severity') == 'CRITICAL'])
            for t in self.report['tests']
        )
        
        self.report['summary'] = {
            'total_tests': total_tests,
            'passed_tests': passed_tests,
            'failed_tests': failed_tests,
            'skipped_tests': skipped_tests,
            'error_tests': error_tests,
            'total_vulnerabilities': total_vulnerabilities,
            'critical_vulnerabilities': critical_vulnerabilities,
            'security_score': (passed_tests / total_tests * 100) if total_tests > 0 else 0
        }
        
        # Afficher le résumé
        self.stdout.write('\n' + '='*60)
        self.stdout.write(self.style.SUCCESS('RAPPORT DE SÉCURITÉ'))
        self.stdout.write('='*60)
        self.stdout.write(f'Tests exécutés: {total_tests}')
        self.stdout.write(f'Tests réussis: {passed_tests}')
        self.stdout.write(f'Tests échoués: {failed_tests}')
        self.stdout.write(f'Tests ignorés: {skipped_tests}')
        self.stdout.write(f'Tests en erreur: {error_tests}')
        self.stdout.write(f'Vulnérabilités totales: {total_vulnerabilities}')
        self.stdout.write(f'Vulnérabilités critiques: {critical_vulnerabilities}')
        self.stdout.write(f'Score de sécurité: {self.report["summary"]["security_score"]:.1f}%')
        
        if critical_vulnerabilities > 0:
            self.stdout.write(self.style.ERROR(f'\n🚨 ALERTE: {critical_vulnerabilities} vulnérabilités CRITIQUES détectées!'))
        
        # Sauvegarder le rapport
        if output_file:
            with open(output_file, 'w', encoding='utf-8') as f:
                json.dump(self.report, f, indent=2, ensure_ascii=False)
            self.stdout.write(f'\nRapport sauvegardé: {output_file}')
    
    def fix_vulnerabilities(self):
        """Corrige automatiquement les vulnérabilités détectées."""
        self.stdout.write(self.style.WARNING('\nCorrection automatique des vulnérabilités...'))
        
        # Logique de correction automatique
        fixed_count = 0
        
        for test in self.report['tests']:
            for vulnerability in test.get('vulnerabilities', []):
                try:
                    if self._fix_single_vulnerability(vulnerability):
                        fixed_count += 1
                except Exception as e:
                    self.stdout.write(self.style.ERROR(f'Erreur lors de la correction: {e}'))
        
        self.stdout.write(self.style.SUCCESS(f'Corrections appliquées: {fixed_count}'))
    
    def _fix_single_vulnerability(self, vulnerability):
        """Tente de corriger une vulnérabilité spécifique."""
        # Implémentation des corrections automatiques selon le type de vulnérabilité
        return False