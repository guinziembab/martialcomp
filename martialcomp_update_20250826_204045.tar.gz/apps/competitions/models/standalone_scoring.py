﻿"""
Stand-alone scoring system that doesn't depend on conflicting model names.
This module provides a complete technical scoring system that can be used
independently of the rest of the application.
"""

from django.db import models
from django.utils import timezone
from django.utils.translation import gettext_lazy as _
from django.core.validators import MinValueValidator, MaxValueValidator
from decimal import Decimal

# Use direct database IDs for foreign key relations to avoid model conflicts
class StandaloneScoringSystem(models.Model):
    """
    Defines a scoring system for competitions (standard, point, direct elimination, custom).
    """
    STANDARD = 'standard'
    POINT = 'point'
    DIRECT_ELIMINATION = 'direct'
    CUSTOM = 'custom'
    
    SYSTEM_TYPES = [
        (STANDARD, _('Standard (Weighted Average)')),
        (POINT, _('Point System')),
        (DIRECT_ELIMINATION, _('Direct Elimination')),
        (CUSTOM, _('Custom')),
    ]
    
    name = models.CharField(max_length=100)
    description = models.TextField(blank=True)
    system_type = models.CharField(max_length=20, choices=SYSTEM_TYPES, default=STANDARD)
    min_score = models.DecimalField(max_digits=5, decimal_places=2, default=0.0)
    max_score = models.DecimalField(max_digits=5, decimal_places=2, default=10.0)
    score_step = models.DecimalField(max_digits=5, decimal_places=2, default=0.1)
    exclude_extreme_scores = models.BooleanField(default=False)
    allow_ties = models.BooleanField(default=True)
    real_time_results = models.BooleanField(default=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    
    class Meta:
        app_label = 'competitions'
        db_table = 'competitions_standalonescoringystem'  # Match the SQL table name
        verbose_name = _("Scoring System")
        verbose_name_plural = _("Scoring Systems")
    
    def __str__(self):
        return f"{self.name} ({self.get_system_type_display()})"


class StandaloneScoringCriterion(models.Model):
    """
    Defines criteria for evaluating performances (e.g., Technique, Power, Balance).
    """
    scoring_system = models.ForeignKey(
        StandaloneScoringSystem, 
        on_delete=models.CASCADE, 
        related_name='standalone_criteria'
    )
    # Use direct ID reference to category instead of model relation
    category_id = models.IntegerField(null=True, blank=True)
    
    name = models.CharField(max_length=100)
    description = models.TextField(blank=True)
    weight = models.DecimalField(
        max_digits=5, 
        decimal_places=2, 
        default=1.0,
        validators=[MinValueValidator(0.01)]
    )
    min_score = models.DecimalField(max_digits=5, decimal_places=2, null=True, blank=True)
    max_score = models.DecimalField(max_digits=5, decimal_places=2, null=True, blank=True)
    step = models.DecimalField(max_digits=5, decimal_places=2, null=True, blank=True)
    order_num = models.PositiveIntegerField(default=0)  # Renamed to match SQL table
    is_active = models.BooleanField(default=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    
    class Meta:
        app_label = 'competitions'
        ordering = ['order_num', 'name']
        verbose_name = _("Scoring Criterion")
        verbose_name_plural = _("Scoring Criteria")
    
    def __str__(self):
        return f"{self.name} (weight: {self.weight})"
    
    def save(self, *args, **kwargs):
        # Use system defaults if specific values aren't provided
        if self.min_score is None and self.scoring_system:
            self.min_score = self.scoring_system.min_score
        if self.max_score is None and self.scoring_system:
            self.max_score = self.scoring_system.max_score
        if self.step is None and self.scoring_system:
            self.step = self.scoring_system.score_step
        
        super().save(*args, **kwargs)


class StandaloneCategoryScoringConfig(models.Model):
    """
    Links a scoring system to a competition category with optional overrides.
    """
    # Use direct ID reference instead of model relation
    category_id = models.IntegerField(unique=True)
    
    scoring_system = models.ForeignKey(
        StandaloneScoringSystem, 
        on_delete=models.CASCADE, 
        related_name='standalone_category_configs'
    )
    override_min_score = models.DecimalField(
        max_digits=5, 
        decimal_places=2, 
        null=True, 
        blank=True
    )
    override_max_score = models.DecimalField(
        max_digits=5, 
        decimal_places=2, 
        null=True, 
        blank=True
    )
    override_score_step = models.DecimalField(
        max_digits=5, 
        decimal_places=2, 
        null=True, 
        blank=True
    )
    exclude_extreme_scores = models.BooleanField(null=True, blank=True)
    allow_ties = models.BooleanField(null=True, blank=True)
    real_time_results = models.BooleanField(null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    
    class Meta:
        app_label = 'competitions'
        verbose_name = _("Category Scoring Configuration")
        verbose_name_plural = _("Category Scoring Configurations")
    
    def __str__(self):
        return f"Scoring Config for Category #{self.category_id}"
    
    def get_effective_min_score(self):
        return self.override_min_score if self.override_min_score is not None else self.scoring_system.min_score
    
    def get_effective_max_score(self):
        return self.override_max_score if self.override_max_score is not None else self.scoring_system.max_score
    
    def get_effective_score_step(self):
        return self.override_score_step if self.override_score_step is not None else self.scoring_system.score_step
    
    def get_effective_exclude_extreme_scores(self):
        return self.exclude_extreme_scores if self.exclude_extreme_scores is not None else self.scoring_system.exclude_extreme_scores
    
    def get_effective_allow_ties(self):
        return self.allow_ties if self.allow_ties is not None else self.scoring_system.allow_ties
    
    def get_effective_real_time_results(self):
        return self.real_time_results if self.real_time_results is not None else self.scoring_system.real_time_results


class StandalonePerformance(models.Model):
    """
    Represents a participant's performance to be scored.
    """
    PENDING = 'pending'
    IN_PROGRESS = 'in_progress'
    COMPLETED = 'completed'
    DISQUALIFIED = 'disqualified'
    CANCELLED = 'cancelled'
    
    STATUS_CHOICES = [
        (PENDING, _('Pending')),
        (IN_PROGRESS, _('In Progress')),
        (COMPLETED, _('Completed')),
        (DISQUALIFIED, _('Disqualified')),
        (CANCELLED, _('Cancelled')),
    ]
    
    PRELIMINARY = 'preliminary'
    SEMIFINAL = 'semifinal'
    FINAL = 'final'
    EXHIBITION = 'exhibition'
    
    ROUND_TYPES = [
        (PRELIMINARY, _('Preliminary')),
        (SEMIFINAL, _('Semifinal')),
        (FINAL, _('Final')),
        (EXHIBITION, _('Exhibition')),
    ]
    
    # Use direct ID references instead of model relations
    competition_id = models.IntegerField()
    category_id = models.IntegerField()
    practitioner_id = models.IntegerField()
    
    round_type = models.CharField(
        max_length=20, 
        choices=ROUND_TYPES, 
        default=PRELIMINARY
    )
    round_number = models.PositiveIntegerField(default=1)
    performance_order = models.PositiveIntegerField(default=0)
    status = models.CharField(
        max_length=20, 
        choices=STATUS_CHOICES, 
        default=PENDING
    )
    start_time = models.DateTimeField(null=True, blank=True)
    end_time = models.DateTimeField(null=True, blank=True)
    duration = models.DurationField(null=True, blank=True)
    notes = models.TextField(blank=True)
    disqualification_reason = models.TextField(blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    
    class Meta:
        app_label = 'competitions'
        ordering = ['round_type', 'round_number', 'performance_order']
        verbose_name = _("Performance")
        verbose_name_plural = _("Performances")
    
    def __str__(self):
        return f"Performance #{self.id} - {self.get_round_type_display()} Round {self.round_number}"
    
    def start_performance(self):
        if self.status == self.PENDING:
            self.status = self.IN_PROGRESS
            self.start_time = timezone.now()
            self.save()
            return True
        return False
    
    def end_performance(self):
        if self.status == self.IN_PROGRESS:
            now = timezone.now()
            self.end_time = now
            self.duration = now - self.start_time if self.start_time else None
            self.status = self.COMPLETED
            self.save()
            return True
        return False
    
    def disqualify(self, reason=''):
        if self.status not in [self.COMPLETED, self.DISQUALIFIED, self.CANCELLED]:
            self.status = self.DISQUALIFIED
            self.disqualification_reason = reason
            if self.start_time and not self.end_time:
                self.end_time = timezone.now()
                self.duration = self.end_time - self.start_time if self.start_time else None
            self.save()
            return True
        return False
    
    def cancel(self, reason=''):
        if self.status != self.COMPLETED:
            self.status = self.CANCELLED
            self.notes = (self.notes + '\n' + reason).strip()
            self.save()
            return True
        return False


class StandaloneScore(models.Model):
    """
    Individual scores from judges for a performance.
    """
    performance = models.ForeignKey(
        StandalonePerformance, 
        on_delete=models.CASCADE, 
        related_name='standalone_scores'
    )
    # Use direct ID reference instead of model relation
    judge_id = models.IntegerField()
    criterion = models.ForeignKey(
        StandaloneScoringCriterion, 
        on_delete=models.CASCADE, 
        related_name='standalone_scores'
    )
    value = models.DecimalField(max_digits=5, decimal_places=2)
    original_value = models.DecimalField(
        max_digits=5, 
        decimal_places=2, 
        null=True, 
        blank=True
    )
    is_locked = models.BooleanField(default=False)
    is_training_score = models.BooleanField(default=False)
    modified_by_id = models.IntegerField(null=True, blank=True)
    notes = models.TextField(blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    
    class Meta:
        app_label = 'competitions'
        unique_together = [
            ('performance', 'judge_id', 'criterion'),
        ]
        verbose_name = _("Score")
        verbose_name_plural = _("Scores")
    
    def __str__(self):
        return f"Score #{self.id} - Judge #{self.judge_id} - {self.value}"
    
    def save(self, *args, **kwargs):
        # Store original value if this is the first save
        if not self.id and not self.original_value:
            self.original_value = self.value
        
        # Validate score range
        min_score = self.criterion.min_score
        max_score = self.criterion.max_score
        if min_score is not None and self.value < min_score:
            self.value = min_score
        if max_score is not None and self.value > max_score:
            self.value = max_score
        
        super().save(*args, **kwargs)
    
    def lock(self):
        self.is_locked = True
        self.save()
        return True


class StandaloneJudgeSubmission(models.Model):
    """
    Tracks whether a judge has submitted all scores for a performance.
    """
    performance = models.ForeignKey(
        StandalonePerformance, 
        on_delete=models.CASCADE, 
        related_name='standalone_judge_submissions'
    )
    # Use direct ID reference instead of model relation
    judge_id = models.IntegerField()
    is_submitted = models.BooleanField(default=False)
    submitted_at = models.DateTimeField(null=True, blank=True)
    notes = models.TextField(blank=True)
    
    class Meta:
        app_label = 'competitions'
        unique_together = [
            ('performance', 'judge_id'),
        ]
        verbose_name = _("Judge Submission")
        verbose_name_plural = _("Judge Submissions")
    
    def __str__(self):
        status = "Submitted" if self.is_submitted else "Not Submitted"
        return f"Judge #{self.judge_id} - Performance #{self.performance_id} - {status}"
    
    def submit(self):
        if not self.is_submitted:
            self.is_submitted = True
            self.submitted_at = timezone.now()
            self.save()
            
            # Lock all scores
            for score in StandaloneScore.objects.filter(performance=self.performance, judge_id=self.judge_id):
                score.lock()
            
            return True
        return False


class StandaloneJudgeSettings(models.Model):
    """
    Stores judge UI preferences.
    """
    COMPACT = 'compact'
    DETAILED = 'detailed'
    
    DISPLAY_MODES = [
        (COMPACT, _('Compact')),
        (DETAILED, _('Detailed')),
    ]
    
    LIGHT = 'light'
    DARK = 'dark'
    
    THEME_CHOICES = [
        (LIGHT, _('Light')),
        (DARK, _('Dark')),
    ]
    
    # Use direct ID reference instead of model relation
    user_id = models.IntegerField(unique=True)
    display_mode = models.CharField(
        max_length=20, 
        choices=DISPLAY_MODES, 
        default=DETAILED
    )
    notification_sounds = models.BooleanField(default=True)
    auto_submit = models.BooleanField(default=False)
    theme = models.CharField(
        max_length=20, 
        choices=THEME_CHOICES, 
        default=LIGHT
    )
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    
    class Meta:
        app_label = 'competitions'
        verbose_name = _("Judge Settings")
        verbose_name_plural = _("Judge Settings")
    
    def __str__(self):
        return f"Settings for User #{self.user_id}"


class StandaloneCompetitionRanking(models.Model):
    """
    Final ranking of competitors in a category.
    """
    GOLD = 'gold'
    SILVER = 'silver'
    BRONZE = 'bronze'
    NONE = 'none'
    
    MEDAL_CHOICES = [
        (GOLD, _('Gold')),
        (SILVER, _('Silver')),
        (BRONZE, _('Bronze')),
        (NONE, _('None')),
    ]
    
    # Use direct ID references instead of model relations
    competition_id = models.IntegerField()
    category_id = models.IntegerField()
    practitioner_id = models.IntegerField()
    
    performance = models.ForeignKey(
        StandalonePerformance, 
        on_delete=models.CASCADE, 
        related_name='standalone_rankings',
        null=True,
        blank=True
    )
    rank = models.PositiveIntegerField()
    final_score = models.DecimalField(max_digits=7, decimal_places=3)
    is_tie = models.BooleanField(default=False)
    medal = models.CharField(
        max_length=10, 
        choices=MEDAL_CHOICES, 
        default=NONE
    )
    is_published = models.BooleanField(default=False)
    notes = models.TextField(blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    
    class Meta:
        app_label = 'competitions'
        ordering = ['category_id', 'rank']
        unique_together = [
            ('category_id', 'practitioner_id'),
        ]
        verbose_name = _("Competition Ranking")
        verbose_name_plural = _("Competition Rankings")
    
    def __str__(self):
        return f"Practitioner #{self.practitioner_id} - Rank {self.rank} ({self.final_score})"
    
    def save(self, *args, **kwargs):
        # Auto-assign medals based on rank if not explicitly set
        if not self.pk and self.medal == self.NONE:
            if self.rank == 1:
                self.medal = self.GOLD
            elif self.rank == 2:
                self.medal = self.SILVER
            elif self.rank == 3:
                self.medal = self.BRONZE
        
        super().save(*args, **kwargs)


class StandaloneCategoryRankingSnapshot(models.Model):
    """
    Represents a complete snapshot of rankings for a category at a point in time.
    """
    # Use direct ID references instead of model relations
    category_id = models.IntegerField()
    competition_id = models.IntegerField()
    created_by_id = models.IntegerField(null=True, blank=True)
    
    is_published = models.BooleanField(default=False)
    is_final = models.BooleanField(default=False)
    name = models.CharField(max_length=100, blank=True)
    notes = models.TextField(blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    
    class Meta:
        app_label = 'competitions'
        verbose_name = _("Category Ranking Snapshot")
        verbose_name_plural = _("Category Ranking Snapshots")
    
    def __str__(self):
        status = "Final" if self.is_final else "Draft"
        return f"Category #{self.category_id} Rankings - {status} ({self.created_at.strftime('%Y-%m-%d %H:%M')})"
    
    def publish(self):
        if not self.is_published:
            self.is_published = True
            self.save()
            return True
        return False
    
    def finalize(self):
        if self.is_published and not self.is_final:
            self.is_final = True
            self.save()
            return True
        return False


class StandaloneRankingSnapshotEntry(models.Model):
    """
    Individual entries in a ranking snapshot.
    """
    GOLD = 'gold'
    SILVER = 'silver'
    BRONZE = 'bronze'
    NONE = 'none'
    
    MEDAL_CHOICES = [
        (GOLD, _('Gold')),
        (SILVER, _('Silver')),
        (BRONZE, _('Bronze')),
        (NONE, _('None')),
    ]
    
    snapshot = models.ForeignKey(
        StandaloneCategoryRankingSnapshot, 
        on_delete=models.CASCADE, 
        related_name='entries'
    )
    # Use direct ID reference instead of model relation
    practitioner_id = models.IntegerField()
    rank = models.PositiveIntegerField()
    final_score = models.DecimalField(max_digits=7, decimal_places=3)
    is_tie = models.BooleanField(default=False)
    medal = models.CharField(
        max_length=10, 
        choices=MEDAL_CHOICES, 
        default=NONE
    )
    
    class Meta:
        app_label = 'competitions'
        ordering = ['snapshot', 'rank']
        verbose_name = _("Ranking Snapshot Entry")
        verbose_name_plural = _("Ranking Snapshot Entries")
        db_table = 'competitions_standalonerankingsnapshotentry'  # Corrigé pour correspondre Ã  la table SQL
    
    def __str__(self):
        return f"Practitioner #{self.practitioner_id} - Rank {self.rank} ({self.final_score})"

