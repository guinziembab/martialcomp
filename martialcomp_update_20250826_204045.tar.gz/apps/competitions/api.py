from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework.permissions import AllowAny
from django.utils import timezone
from apps.competitions.models.competitions import Competition


class CompetitionListView(APIView):
    permission_classes = [AllowAny]

    def get(self, request):
        qs = Competition.objects.all()
        if hasattr(Competition, 'is_public'):
            qs = qs.filter(is_public=True)
        if hasattr(Competition, 'start_date'):
            qs = qs.filter(start_date__gte=timezone.now()).order_by('start_date')
        competitions = [
            {
                'id': c.id,
                'name': getattr(c, 'name', ''),
                'start_date': getattr(c, 'start_date', None),
                'location': getattr(c, 'location', ''),
            }
            for c in qs[:10]
        ]
        user_regs = []
        # TODO: map registrations if model available
        return Response({'upcoming_competitions': competitions, 'user_registrations': user_regs})

from django.urls import path

urlpatterns = [
    path('upcoming/', CompetitionListView.as_view(), name='competitions_upcoming'),
]
