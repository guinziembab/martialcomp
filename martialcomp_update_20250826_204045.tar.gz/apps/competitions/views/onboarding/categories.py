﻿import logging
from django.shortcuts import render, redirect, get_object_or_404
from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.utils.translation import gettext_lazy as _
from django.db import transaction

from ...models import Club, Discipline, Competition, CompetitionCategory

logger = logging.getLogger(__name__)

@login_required
def handle_categories_setup(request):
    """
    Configuration des disciplines et des paramètres associés au club.
    Cette étape permet de définir les préférences du club pour les compétitions.
    """
    # Vérifier si l'utilisateur a un profil et le rÃ´le approprié
    if not hasattr(request.user, 'profile') or request.user.profile.role != 'club_manager':
        messages.error(request, _("Accès non autorisé. Vous devez Ãªtre responsable de club."))
        return redirect('competitions:onboarding:role_selection')
    
    # Récupération du club de l'utilisateur
    club = get_object_or_404(Club, owner=request.user)
    
    if request.method == 'POST':
        try:
            with transaction.atomic():
                # Configuration des disciplines associées au club
                if hasattr(club, 'disciplines'):
                    selected_disciplines = request.POST.getlist('disciplines')
                    club.disciplines.clear()
                    
                    for discipline_id in selected_disciplines:
                        try:
                            discipline = Discipline.objects.get(id=discipline_id)
                            club.disciplines.add(discipline)
                        except Discipline.DoesNotExist:
                            continue
                
                # Configuration des tranches d'Ã¢ge si les attributs existent
                if hasattr(club, 'accepts_children'):
                    club.accepts_children = 'accepts_children' in request.POST
                if hasattr(club, 'accepts_teenagers'):
                    club.accepts_teenagers = 'accepts_teenagers' in request.POST
                if hasattr(club, 'accepts_adults'):
                    club.accepts_adults = 'accepts_adults' in request.POST
                if hasattr(club, 'accepts_seniors'):
                    club.accepts_seniors = 'accepts_seniors' in request.POST
                
                # Configuration des préférences de catégories
                # On peut stocker ces préférences dans un champ JSON si nécessaire
                category_preferences = {
                    'age_categories': request.POST.getlist('age_categories', []),
                    'grade_categories': request.POST.getlist('grade_categories', []),
                    'weight_categories': request.POST.getlist('weight_categories', [])
                }
                
                if hasattr(club, 'category_preferences'):
                    club.category_preferences = category_preferences
                
                club.save()
                
                messages.success(request, _("Configuration des préférences terminée avec succès!"))
                
                # Passage Ã  l'étape finale
                request.user.profile.onboarding_step = 'final_setup'
                request.user.profile.save()
                request.session['onboarding_step'] = 'final_setup'
                return redirect('competitions:onboarding:final_setup')
        except Exception as e:
            logger.error(f"Erreur lors de la configuration des préférences: {str(e)}")
            messages.error(request, _("Une erreur est survenue lors de la configuration des préférences."))
    
    # Récupérer les disciplines disponibles
    try:
        disciplines = Discipline.objects.filter(is_active=True)
    except Exception as e:
        logger.warning(f"Erreur lors de la récupération des disciplines: {str(e)}")
        disciplines = []
    
    # Préparer les options de catégories par défaut
    age_categories = [
        {'id': 'children', 'name': _('Enfants (6-11 ans)')},
        {'id': 'teenagers', 'name': _('Adolescents (12-17 ans)')},
        {'id': 'adults', 'name': _('Adultes (18-39 ans)')},
        {'id': 'seniors', 'name': _('Vétérans (40+ ans)')},
    ]
    
    grade_categories = [
        {'id': 'beginners', 'name': _('Débutants (Blanche - Orange)')},
        {'id': 'intermediate', 'name': _('Intermédiaires (Verte - Bleue)')},
        {'id': 'advanced', 'name': _('Avancés (Marron - Rouge)')},
        {'id': 'experts', 'name': _('Experts (Noire)')},
    ]
    
    weight_categories = [
        {'id': 'light', 'name': _('Poids léger')},
        {'id': 'medium', 'name': _('Poids moyen')},
        {'id': 'heavy', 'name': _('Poids lourd')},
        {'id': 'super_heavy', 'name': _('Poids super-lourd')},
    ]
    
    context = {
        'club': club,
        'step': 'categories_setup',
        'current_step': 'categories_setup',
        'disciplines': disciplines,
        'age_categories': age_categories,
        'grade_categories': grade_categories,
        'weight_categories': weight_categories,
    }
    
    return render(request, 'competitions/onboarding/categories_setup.html', context)
