﻿"""
Vue de débogage pour analyser le processus d'onboarding
"""
import logging
from django.shortcuts import render, redirect
from django.contrib.auth.decorators import user_passes_test
from django.contrib.auth.models import User
from django.contrib import messages
from django.http import JsonResponse
from django.utils.translation import gettext_lazy as _
from django.contrib.sessions.models import Session
from django.utils import timezone
from datetime import timedelta
from ..models import UserProfile

logger = logging.getLogger(__name__)

@user_passes_test(lambda u: u.is_superuser)
def debug_onboarding_view(request):
    """
    Vue de débogage pour analyser les problèmes d'onboarding.
    Accessible uniquement aux superutilisateurs.
    """
    # Récupérer les utilisateurs récents (dernières 24h)
    recent_users = User.objects.filter(
        date_joined__gte=timezone.now() - timedelta(days=1)
    ).order_by('-date_joined')
    
    # Sessions actives
    active_sessions = Session.objects.filter(
        expire_date__gte=timezone.now()
    ).count()
    
    # Utilisateurs avec problèmes d'onboarding
    problematic_users = []
    for user in recent_users:
        try:
            profile = user.profile
            if not profile.onboarding_completed:
                problematic_users.append({
                    'user': user,
                    'profile': profile,
                    'issue': 'Onboarding incomplet'
                })
        except:
            problematic_users.append({
                'user': user,
                'profile': None,
                'issue': 'Profil manquant'
            })
    
    context = {
        'recent_users': recent_users[:10],
        'active_sessions': active_sessions,
        'problematic_users': problematic_users,
        'total_users': User.objects.count(),
        'users_with_profiles': UserProfile.objects.count(),
        'completed_onboarding': UserProfile.objects.filter(onboarding_completed=True).count(),
    }
    
    return render(request, 'competitions/debug_onboarding.html', context)

def debug_user_state(request, username):
    """
    API pour obtenir l'état détaillé d'un utilisateur spécifique.
    """
    try:
        user = User.objects.get(username=username)
        
        # Ã‰tat du profil
        try:
            profile = user.profile
            profile_data = {
                'exists': True,
                'role': profile.role,
                'onboarding_completed': profile.onboarding_completed,
                'onboarding_step': profile.onboarding_step,
            }
        except:
            profile_data = {'exists': False}
        
        # Sessions actives pour cet utilisateur
        user_sessions = []
        for session in Session.objects.filter(expire_date__gte=timezone.now()):
            session_data = session.get_decoded()
            if session_data.get('_auth_user_id') == str(user.id):
                user_sessions.append({
                    'session_key': session.session_key[:10] + '...',
                    'expire_date': session.expire_date.isoformat(),
                    'data': session_data
                })
        
        return JsonResponse({
            'user': {
                'id': user.id,
                'username': user.username,
                'email': user.email,
                'is_active': user.is_active,
                'date_joined': user.date_joined.isoformat(),
                'last_login': user.last_login.isoformat() if user.last_login else None,
            },
            'profile': profile_data,
            'sessions': user_sessions,
            'is_authenticated_in_request': request.user == user,
        })
        
    except User.DoesNotExist:
        return JsonResponse({'error': 'Utilisateur non trouvé'}, status=404)
    except Exception as e:
        return JsonResponse({'error': str(e)}, status=500)

def force_fix_user_onboarding(request, username):
    """
    Force la correction de l'onboarding pour un utilisateur.
    """
    if not request.user.is_superuser:
        return JsonResponse({'error': 'Non autorisé'}, status=403)
    
    try:
        user = User.objects.get(username=username)
        
        # Créer ou réparer le profil
        profile, created = UserProfile.objects.get_or_create(
            user=user,
            defaults={
                'role': 'spectator',
                'onboarding_step': 'role_selection',
                'onboarding_completed': False
            }
        )
        
        if not created:
            profile.onboarding_step = 'role_selection'
            profile.onboarding_completed = False
            profile.save()
        
        logger.info(f"Profil réparé pour {username} par {request.user.username}")
        
        return JsonResponse({
            'success': True,
            'message': f'Profil réparé pour {username}',
            'profile': {
                'role': profile.role,
                'onboarding_step': profile.onboarding_step,
                'onboarding_completed': profile.onboarding_completed
            }
        })
        
    except User.DoesNotExist:
        return JsonResponse({'error': 'Utilisateur non trouvé'}, status=404)
    except Exception as e:
        logger.error(f"Erreur lors de la réparation du profil pour {username}: {str(e)}")
        return JsonResponse({'error': str(e)}, status=500)
