﻿from django.core.management.base import BaseCommand
from django.contrib.auth import get_user_model
from apps.competitions.models import UserProfile, Judge
from apps.competitions.models.users import UserProfile as CompetitionsUserProfile

User = get_user_model()

class Command(BaseCommand):
    help = 'Fix judge999 profile to have correct judge role'

    def add_arguments(self, parser):
        parser.add_argument(
            '--username',
            default='juge999',
            help='Username to fix (default: juge999)'
        )

    def handle(self, *args, **options):
        username = options['username']
        
        try:
            # Chercher l'utilisateur
            user = User.objects.get(username=username)
            self.stdout.write(f"Found user: {user.username} (ID: {user.id})")
            
            # Vérifier/créer le profil UserProfile
            try:
                profile = UserProfile.objects.get(user=user)
                self.stdout.write(f"Current profile role: {profile.role}")
                self.stdout.write(f"Onboarding completed: {profile.onboarding_completed}")
            except UserProfile.DoesNotExist:
                # Créer le profil s'il n'existe pas
                profile = UserProfile.objects.create(
                    user=user,
                    role='judge',
                    onboarding_completed=True
                )
                self.stdout.write(self.style.SUCCESS(f"Created new UserProfile for {username}"))
            
            # Mettre Ã  jour le rÃ´le vers judge
            if profile.role != 'judge':
                profile.role = 'judge'
                profile.onboarding_completed = True
                profile.save()
                self.stdout.write(self.style.SUCCESS(f"Updated {username} role to 'judge'"))
            
            # Vérifier s'il existe un enregistrement Judge
            try:
                judge = Judge.objects.get(user=user)
                self.stdout.write(f"Found Judge record: {judge}")
            except Judge.DoesNotExist:
                self.stdout.write(self.style.WARNING(f"No Judge record found for {username}"))
                self.stdout.write("You may need to create a Judge record manually if needed")
            
            # Vérifier les autres profils (CompetitionsUserProfile si existant)
            try:
                competitions_profile = CompetitionsUserProfile.objects.get(user=user)
                if competitions_profile.role != 'judge':
                    competitions_profile.role = 'judge'
                    competitions_profile.save()
                    self.stdout.write(self.style.SUCCESS(f"Updated CompetitionsUserProfile role to 'judge'"))
            except:
                self.stdout.write("No CompetitionsUserProfile found (this is normal)")
            
            self.stdout.write(self.style.SUCCESS(f"Profile fix completed for {username}"))
            
            # Afficher le résumé final
            profile.refresh_from_db()
            self.stdout.write("\n" + "="*50)
            self.stdout.write("FINAL STATUS:")
            self.stdout.write(f"Username: {user.username}")
            self.stdout.write(f"Role: {profile.role}")
            self.stdout.write(f"Onboarding completed: {profile.onboarding_completed}")
            self.stdout.write(f"Is active: {user.is_active}")
            self.stdout.write("="*50)
            
        except User.DoesNotExist:
            self.stdout.write(self.style.ERROR(f"User '{username}' not found"))
            
            # Lister les utilisateurs existants pour aide
            self.stdout.write("\nExisting users:")
            for user in User.objects.all()[:10]:
                try:
                    profile = UserProfile.objects.get(user=user)
                    role = profile.role
                except:
                    role = "No profile"
                self.stdout.write(f"  - {user.username} ({role})")

