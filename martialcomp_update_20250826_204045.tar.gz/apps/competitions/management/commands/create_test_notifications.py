﻿from django.core.management.base import BaseCommand
from django.contrib.auth.models import User
from apps.competitions.models.notifications import Notification
from django.utils import timezone

class Command(BaseCommand):
    help = 'Crée des notifications de test pour tous les utilisateurs'

    def handle(self, *args, **options):
        """Crée des notifications de test pour tous les utilisateurs"""
        
        self.stdout.write(self.style.SUCCESS("ðŸ”” CRÃ‰ATION DE NOTIFICATIONS DE TEST"))
        self.stdout.write("=" * 50)
        
        # Récupérer tous les utilisateurs
        users = User.objects.filter(is_active=True)
        self.stdout.write(f"ðŸ“Š Utilisateurs trouvés: {users.count()}")
        
        # Notifications de test
        test_notifications = [
            {
                'title': 'Bienvenue sur MartialComp',
                'message': 'Votre compte a été configuré avec succès. Le nouveau système de notifications est maintenant actif.',
                'notification_type': 'success',
                'priority': 'standard'
            },
            {
                'title': 'Nouvelle compétition disponible',
                'message': 'Une nouvelle compétition de karaté est ouverte aux inscriptions. Cliquez pour voir les détails.',
                'notification_type': 'info',
                'priority': 'important',
                'action_url': '/competitions/competitions/'
            },
            {
                'title': 'Action requise - Profil incomplet',
                'message': 'Veuillez compléter votre profil club pour accéder Ã  toutes les fonctionnalités.',
                'notification_type': 'warning',
                'priority': 'important'
            },
            {
                'title': 'Système de notifications amélioré',
                'message': 'Le nouveau système de notifications avec cloche et badge dynamique est maintenant actif. Testez-le !',
                'notification_type': 'info',
                'priority': 'standard'
            },
            {
                'title': 'Test de notification critique',
                'message': 'Ceci est un test de notification avec priorité critique pour vérifier le système.',
                'notification_type': 'error',
                'priority': 'critical'
            }
        ]
        
        total_created = 0
        
        for user in users:
            self.stdout.write(f"\nðŸ‘¤ Création de notifications pour: {user.username}")
            
            for i, notif_data in enumerate(test_notifications):
                # Créer la notification
                notification = Notification.objects.create(
                    user=user,
                    title=notif_data['title'],
                    message=notif_data['message'],
                    notification_type=notif_data['notification_type'],
                    priority=notif_data['priority'],
                    action_url=notif_data.get('action_url'),
                    action_text=notif_data.get('action_text')
                )
                
                self.stdout.write(f"   âœ… Notification {i+1}: {notification.title}")
                total_created += 1
        
        self.stdout.write(f"\nðŸŽ‰ RÃ‰SUMÃ‰")
        self.stdout.write("=" * 50)
        self.stdout.write(f"ðŸ“Š Notifications créées: {total_created}")
        self.stdout.write(f"ðŸ‘¥ Utilisateurs concernés: {users.count()}")
        self.stdout.write(f"ðŸ“ Notifications par utilisateur: {len(test_notifications)}")
        
        # Statistiques
        total_notifications = Notification.objects.count()
        unread_notifications = Notification.objects.filter(is_read=False).count()
        
        self.stdout.write(f"\nðŸ“ˆ STATISTIQUES GLOBALES")
        self.stdout.write(f"   Total notifications en base: {total_notifications}")
        self.stdout.write(f"   Notifications non lues: {unread_notifications}")
        self.stdout.write(f"   Notifications lues: {total_notifications - unread_notifications}")
        
        self.stdout.write(self.style.SUCCESS(f"\nâœ… Test terminé avec succès!"))
        self.stdout.write("ðŸ”” Le nouveau système de notifications est maintenant testable dans tous les dashboards.") 

