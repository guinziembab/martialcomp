/**
 * DeepL Integration for Django Rosetta
 * Adds translation suggestions to the Rosetta interface
 */

(function($) {
    'use strict';

    // Configuration
    const DEEPL_API_URL = '/fr/admin/deepl/translate/';  // Updated with language prefix
    const DEEPL_STATUS_URL = '/fr/admin/deepl/status/';  // Updated with language prefix
    
    // Initialize DeepL integration
    function initializeDeepLIntegration() {
        // Check if we're on a Rosetta page
        if (!window.location.pathname.includes('/rosetta/')) {
            return;
        }
        
        // Add DeepL buttons to translation textareas
        addDeepLButtons();
        
        // Add global status indicator
        addStatusIndicator();
    }
    
    // Add DeepL suggestion buttons to translation textareas
    function addDeepLButtons() {
        $('textarea[name*="msgstr"]').each(function() {
            const textarea = $(this);
            const msgidText = getMsgidText(textarea);
            
            if (msgidText) {
                const button = createDeepLButton(textarea, msgidText);
                textarea.after(button);
            }
        });
    }
    
    // Get the corresponding msgid text for a msgstr textarea
    function getMsgidText(textarea) {
        const row = textarea.closest('tr');
        const msgidCell = row.find('td').first();
        return msgidCell.text().trim();
    }
    
    // Create DeepL suggestion button
    function createDeepLButton(textarea, msgidText) {
        const button = $('<button type="button" class="deepl-suggest-btn">🌍 DeepL</button>');
        
        button.css({
            'margin-left': '5px',
            'padding': '2px 8px',
            'font-size': '11px',
            'background': '#007cba',
            'color': 'white',
            'border': 'none',
            'border-radius': '3px',
            'cursor': 'pointer'
        });
        
        button.on('click', function() {
            suggestTranslation(textarea, msgidText, button);
        });
        
        return button;
    }
    
    // Add status indicator
    function addStatusIndicator() {
        const indicator = $('<div id="deepl-status" style="position: fixed; top: 10px; right: 10px; background: #fff; padding: 5px 10px; border: 1px solid #ddd; border-radius: 3px; font-size: 12px; z-index: 9999;">DeepL: <span id="deepl-status-text">Checking...</span></div>');
        
        $('body').append(indicator);
        
        // Check status
        checkDeepLStatus();
    }
    
    // Check DeepL service status
    function checkDeepLStatus() {
        $.get(DEEPL_STATUS_URL)
            .done(function(data) {
                const statusText = data.is_available ? 'Available' : 'Not Available';
                const statusColor = data.is_available ? 'green' : 'red';
                
                $('#deepl-status-text').text(statusText).css('color', statusColor);
                
                if (data.usage_info) {
                    const usagePercent = data.usage_info.usage_percentage.toFixed(1);
                    $('#deepl-status-text').text(`Available (${usagePercent}% used)`);
                }
            })
            .fail(function() {
                $('#deepl-status-text').text('Error').css('color', 'red');
            });
    }
    
    // Suggest translation using DeepL
    function suggestTranslation(textarea, msgidText, button) {
        if (!msgidText) {
            alert('No source text found for translation');
            return;
        }
        
        // Show loading state
        button.prop('disabled', true).text('...');
        
        // Get target language from URL or page
        const targetLanguage = getTargetLanguage();
        
        if (!targetLanguage) {
            alert('Could not determine target language');
            button.prop('disabled', false).text('🌍 DeepL');
            return;
        }
        
        // Make translation request
        $.ajax({
            url: DEEPL_API_URL,
            method: 'POST',
            contentType: 'application/json',
            data: JSON.stringify({
                text: msgidText,
                target_language: targetLanguage,
                source_language: 'auto'
            }),
            headers: {
                'X-CSRFToken': getCookie('csrftoken')
            }
        })
        .done(function(data) {
            if (data.suggestion) {
                // Show suggestion to user
                const currentText = textarea.val();
                const suggestion = data.suggestion;
                
                if (currentText && currentText !== suggestion) {
                    const replace = confirm(`Current: ${currentText}\n\nDeepL suggestion: ${suggestion}\n\nReplace with DeepL suggestion?`);
                    if (replace) {
                        textarea.val(suggestion);
                    }
                } else {
                    textarea.val(suggestion);
                }
                
                // Update button to show success
                button.css('background', '#46b450').text('✓ Applied');
                setTimeout(() => {
                    button.css('background', '#007cba').text('🌍 DeepL');
                }, 2000);
            } else {
                alert('No translation suggestion received');
            }
        })
        .fail(function(xhr) {
            const error = xhr.responseJSON ? xhr.responseJSON.error : 'Translation failed';
            alert(`DeepL translation failed: ${error}`);
        })
        .always(function() {
            button.prop('disabled', false);
            if (button.text() === '...') {
                button.text('🌍 DeepL');
            }
        });
    }
    
    // Get target language from URL or page
    function getTargetLanguage() {
        // Try to extract from URL
        const urlMatch = window.location.pathname.match(/\/rosetta\/([^\/]+)\//);
        if (urlMatch) {
            return urlMatch[1];
        }
        
        // Try to extract from page elements
        const langElement = $('.language-info, .current-language');
        if (langElement.length) {
            return langElement.text().trim().toLowerCase();
        }
        
        // Default fallback
        return 'fr';
    }
    
    // Get CSRF token from cookies
    function getCookie(name) {
        let cookieValue = null;
        if (document.cookie && document.cookie !== '') {
            const cookies = document.cookie.split(';');
            for (let i = 0; i < cookies.length; i++) {
                const cookie = cookies[i].trim();
                if (cookie.substring(0, name.length + 1) === (name + '=')) {
                    cookieValue = decodeURIComponent(cookie.substring(name.length + 1));
                    break;
                }
            }
        }
        return cookieValue;
    }
    
    // Initialize when DOM is ready
    $(document).ready(function() {
        initializeDeepLIntegration();
    });
    
})(jQuery || django.jQuery);