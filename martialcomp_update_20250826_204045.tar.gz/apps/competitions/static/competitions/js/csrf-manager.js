/**
 * Gestionnaire automatique des jetons CSRF pour MartialComp
 * Rafraîchit automatiquement les jetons CSRF et gère les erreurs
 */

class CSRFManager {
    constructor() {
        this.refreshInterval = null;
        this.refreshURL = null;
        this.warningThreshold = 5 * 60 * 1000; // 5 minutes avant expiration
        this.refreshRate = 30 * 60 * 1000; // Rafraîchir toutes les 30 minutes
        this.init();
    }

    init() {
        // Trouver l'URL de rafraîchissement depuis la page
        const refreshLink = document.querySelector('[data-csrf-refresh-url]');
        if (refreshLink) {
            this.refreshURL = refreshLink.getAttribute('data-csrf-refresh-url');
        }

        // Démarrer le rafraîchissement automatique
        this.startAutoRefresh();

        // Écouter les erreurs CSRF des formulaires
        this.setupFormErrorHandling();

        // Écouter les erreurs AJAX
        this.setupAjaxErrorHandling();
    }

    /**
     * Obtient le jeton CSRF actuel depuis le DOM
     */
    getCurrentToken() {
        const tokenInput = document.querySelector('input[name="csrfmiddlewaretoken"]');
        if (tokenInput) {
            return tokenInput.value;
        }

        const tokenMeta = document.querySelector('meta[name="csrf-token"]');
        if (tokenMeta) {
            return tokenMeta.getAttribute('content');
        }

        return null;
    }

    /**
     * Rafraîchit le jeton CSRF
     */
    async refreshToken() {
        if (!this.refreshURL) {
            console.warn('URL de rafraîchissement CSRF non définie');
            return false;
        }

        try {
            const response = await fetch(this.refreshURL, {
                method: 'GET',
                credentials: 'same-origin',
                headers: {
                    'Accept': 'application/json',
                }
            });

            if (!response.ok) {
                throw new Error(`Erreur HTTP: ${response.status}`);
            }

            const data = await response.json();
            
            if (data.success && data.csrfToken) {
                this.updateAllTokens(data.csrfToken);
                console.log('Jeton CSRF rafraîchi avec succès');
                return true;
            } else {
                throw new Error('Réponse invalide du serveur');
            }
        } catch (error) {
            console.error('Erreur lors du rafraîchissement du jeton CSRF:', error);
            this.handleRefreshError(error);
            return false;
        }
    }

    /**
     * Met à jour tous les jetons CSRF dans la page
     */
    updateAllTokens(newToken) {
        // Mettre à jour les champs de formulaire
        const csrfInputs = document.querySelectorAll('input[name="csrfmiddlewaretoken"]');
        csrfInputs.forEach(input => {
            input.value = newToken;
        });

        // Mettre à jour les meta tags
        const csrfMeta = document.querySelector('meta[name="csrf-token"]');
        if (csrfMeta) {
            csrfMeta.setAttribute('content', newToken);
        }

        // Mettre à jour jQuery si disponible
        if (window.jQuery) {
            $.ajaxSetup({
                beforeSend: function(xhr, settings) {
                    if (!this.crossDomain) {
                        xhr.setRequestHeader("X-CSRFToken", newToken);
                    }
                }
            });
        }

        // Déclencher un événement personnalisé
        document.dispatchEvent(new CustomEvent('csrfTokenRefreshed', {
            detail: { token: newToken }
        }));
    }

    /**
     * Démarre le rafraîchissement automatique
     */
    startAutoRefresh() {
        if (this.refreshInterval) {
            clearInterval(this.refreshInterval);
        }

        this.refreshInterval = setInterval(() => {
            this.refreshToken();
        }, this.refreshRate);
    }

    /**
     * Arrête le rafraîchissement automatique
     */
    stopAutoRefresh() {
        if (this.refreshInterval) {
            clearInterval(this.refreshInterval);
            this.refreshInterval = null;
        }
    }

    /**
     * Gère les erreurs de rafraîchissement
     */
    handleRefreshError(error) {
        // Afficher une notification à l'utilisateur
        this.showCSRFWarning();

        // Essayer de rafraîchir après un délai
        setTimeout(() => {
            this.refreshToken();
        }, 10000); // Réessayer après 10 secondes
    }

    /**
     * Affiche un avertissement CSRF à l'utilisateur
     */
    showCSRFWarning() {
        // Créer une notification
        const notification = document.createElement('div');
        notification.className = 'csrf-warning alert alert-warning position-fixed';
        notification.style.cssText = `
            top: 20px;
            right: 20px;
            z-index: 9999;
            max-width: 400px;
            box-shadow: 0 4px 20px rgba(0,0,0,0.15);
        `;
        
        notification.innerHTML = `
            <div class="d-flex align-items-center">
                <i class="fas fa-exclamation-triangle me-2"></i>
                <div class="flex-grow-1">
                    <strong>Session expirée</strong><br>
                    <small>Veuillez rafraîchir la page pour continuer</small>
                </div>
                <button type="button" class="btn-close ms-2" aria-label="Fermer"></button>
            </div>
        `;

        // Ajouter l'événement de fermeture
        notification.querySelector('.btn-close').addEventListener('click', () => {
            notification.remove();
        });

        // Ajouter à la page
        document.body.appendChild(notification);

        // Supprimer automatiquement après 10 secondes
        setTimeout(() => {
            if (notification.parentNode) {
                notification.remove();
            }
        }, 10000);
    }

    /**
     * Gère les erreurs de formulaire liées au CSRF
     */
    setupFormErrorHandling() {
        document.addEventListener('submit', (event) => {
            const form = event.target;
            if (form.tagName === 'FORM' && form.method.toLowerCase() === 'post') {
                const tokenInput = form.querySelector('input[name="csrfmiddlewaretoken"]');
                if (!tokenInput || !tokenInput.value) {
                    event.preventDefault();
                    this.handleMissingToken(form);
                }
            }
        });
    }

    /**
     * Gère les erreurs AJAX liées au CSRF
     */
    setupAjaxErrorHandling() {
        // Pour jQuery
        if (window.jQuery) {
            $(document).ajaxError((event, xhr, settings) => {
                if (xhr.status === 403 && xhr.responseText.includes('CSRF')) {
                    this.handleAjaxCSRFError(xhr, settings);
                }
            });
        }

        // Pour fetch (intercepter les réponses 403)
        const originalFetch = window.fetch;
        window.fetch = async (...args) => {
            const response = await originalFetch(...args);
            if (response.status === 403) {
                const text = await response.clone().text();
                if (text.includes('CSRF')) {
                    this.handleFetchCSRFError(response, args);
                }
            }
            return response;
        };
    }

    /**
     * Gère un jeton manquant dans un formulaire
     */
    handleMissingToken(form) {
        this.refreshToken().then(success => {
            if (success) {
                // Réessayer de soumettre le formulaire
                setTimeout(() => {
                    form.submit();
                }, 500);
            } else {
                this.showCSRFWarning();
            }
        });
    }

    /**
     * Gère les erreurs CSRF dans les requêtes AJAX jQuery
     */
    handleAjaxCSRFError(xhr, settings) {
        this.refreshToken().then(success => {
            if (success && settings.retry !== true) {
                // Réessayer la requête
                settings.retry = true;
                $.ajax(settings);
            } else {
                this.showCSRFWarning();
            }
        });
    }

    /**
     * Gère les erreurs CSRF dans les requêtes fetch
     */
    handleFetchCSRFError(response, originalArgs) {
        this.refreshToken().then(success => {
            if (success) {
                // La requête a échoué, mais le jeton est maintenant rafraîchi
                console.log('Jeton CSRF rafraîchi après erreur fetch');
            } else {
                this.showCSRFWarning();
            }
        });
    }
}

// Initialiser le gestionnaire CSRF quand le DOM est prêt
document.addEventListener('DOMContentLoaded', () => {
    window.csrfManager = new CSRFManager();
});

// Exporter pour utilisation manuelle
window.CSRFManager = CSRFManager;