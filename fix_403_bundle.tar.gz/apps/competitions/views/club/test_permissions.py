"""Vue de test pour comprendre le problème de permissions"""
from django.http import HttpResponse
from django.contrib.auth.decorators import login_required
from django.utils.html import escape
import logging

logger = logging.getLogger(__name__)

@login_required
def test_permissions_view(request):
    """Vue simple pour tester les permissions"""
    try:
        output = []
        output.append("<h1>Test de Permissions</h1>")
        output.append(f"<p><strong>Utilisateur:</strong> {escape(request.user.username)}</p>")
        output.append(f"<p><strong>Email:</strong> {escape(request.user.email)}</p>")
        output.append(f"<p><strong>Is Superuser:</strong> {request.user.is_superuser}</p>")
        output.append(f"<p><strong>Is Staff:</strong> {request.user.is_staff}</p>")
        
        # Vérifier l'organisation du middleware
        if hasattr(request, 'user_organization'):
            output.append(f"<p><strong>Organization (middleware):</strong> {escape(str(request.user_organization))}</p>")
        else:
            output.append("<p><strong>Organization (middleware):</strong> NON TROUVÉE</p>")
        
        # Vérifier le UserProfile
        try:
            from apps.competitions.models.users import UserProfile
            profile = UserProfile.objects.get(user=request.user)
            output.append(f"<p><strong>UserProfile trouvé:</strong> OUI</p>")
            output.append(f"<p><strong>UserProfile Organization:</strong> {escape(str(profile.organization)) if profile.organization else 'AUCUNE'}</p>")
        except UserProfile.DoesNotExist:
            output.append("<p><strong>UserProfile trouvé:</strong> NON</p>")
        except Exception as e:
            output.append(f"<p><strong>Erreur UserProfile:</strong> {escape(str(e))}</p>")
        
        # Vérifier les clubs possédés
        try:
            from apps.competitions.models import Club
            owned_clubs = Club.objects.filter(owner=request.user)
            output.append(f"<p><strong>Nombre de clubs possédés:</strong> {owned_clubs.count()}</p>")
            for club in owned_clubs[:5]:
                output.append(f"<p>&nbsp;&nbsp;- {escape(str(club))} (Org: {escape(str(club.organization)) if hasattr(club, 'organization') else 'N/A'})</p>")
        except Exception as e:
            output.append(f"<p><strong>Erreur clubs:</strong> {escape(str(e))}</p>")
        
        # Vérifier en tant que pratiquant
        try:
            from apps.competitions.models import Practitioner
            from django.db.models import Q
            practitioner = Practitioner.objects.filter(
                Q(user=request.user) | Q(email=request.user.email)
            ).first()
            if practitioner:
                output.append(f"<p><strong>Practitioner trouvé:</strong> OUI ({escape(str(practitioner))})</p>")
                output.append(f"<p><strong>Practitioner Organization:</strong> {escape(str(practitioner.organization)) if practitioner.organization else 'AUCUNE'}</p>")
            else:
                output.append("<p><strong>Practitioner trouvé:</strong> NON</p>")
        except Exception as e:
            output.append(f"<p><strong>Erreur practitioner:</strong> {escape(str(e))}</p>")
        
        # Test de get_user_club
        try:
            from apps.competitions.views.club.practitioners import get_user_club
            user_club = get_user_club(request)
            output.append(f"<p><strong>get_user_club result:</strong> {escape(str(user_club)) if user_club else 'AUCUN'}</p>")
            if user_club:
                output.append(f"<p><strong>Type:</strong> {escape(type(user_club).__name__)}</p>")
        except Exception as e:
            output.append(f"<p><strong>Erreur get_user_club:</strong> {escape(str(e))}</p>")
        
        # Lien vers la page d'ajout
        output.append("<hr>")
        output.append('<p><a href="/fr/competitions/club/practitioners/add/">Tester la page d\'ajout de pratiquant</a></p>')
        
        return HttpResponse("\n".join(output))
        
    except Exception as e:
        logger.error(f"Erreur test_permissions_view: {str(e)}", exc_info=True)
        return HttpResponse(f"<h1>Erreur</h1><p>{escape(str(e))}</p>", status=500)