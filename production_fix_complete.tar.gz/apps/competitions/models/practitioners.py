from django.db import models
from django.utils.translation import gettext_lazy as _
from django.utils import timezone
from django.contrib.auth.models import User
from django.core.mail import send_mail
from django.template.loader import render_to_string
from django.urls import reverse
from django.conf import settings
import uuid

from apps.organizations.models import Organization, OrganizationMember, OrganizationRole
from apps.core.isolation import OrganizationSecureManager


class Practitioner(models.Model):
    """
    Modèle principal pour la gestion des pratiquants.
    """
    GENDER_CHOICES = [
        ('male', _('Homme')),
        ('female', _('Femme')),
        ('other', _('Autre'))
    ]
    
    STATUS_CHOICES = [
        ('active', _('Actif')),
        ('inactive', _('Inactif')),
        ('suspended', _('Suspendu')),
        ('archived', _('Archivé'))
    ]
    
    # Relations
    user = models.ForeignKey(
        User, 
        on_delete=models.CASCADE, 
        related_name='practitioners',
        null=True, 
        blank=True
    )
    organization = models.ForeignKey('organizations.Organization', on_delete=models.SET_NULL, null=True, blank=True, related_name='practitioners')
    
    # Informations personnelles de base - Requis pour les compétitions
    first_name = models.CharField(_("Prénom"), max_length=100)
    last_name = models.CharField(_("Nom"), max_length=100)
    birth_date = models.DateField(_("Date de naissance"))
    
    # Référence au grade dans la nouvelle application "grades"
    # Le champ grade_text est conservé temporairement pour la migration
    grade_text = models.CharField(
        _("Grade (texte)"), 
        max_length=50, 
        blank=True,
        help_text=_("Champ déprécié. Utilisé uniquement pour la migration vers le nouveau système de grades.")
    )
    
    # Nouveau champ faisant référence Ã  l'application grades
    grade = models.ForeignKey(
        'grades.Grade',
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name='practitioner_current_grades',  # Modification ici
        verbose_name=_("Grade actuel")
    )
    
    # Multi-disciplines support
    primary_discipline = models.ForeignKey(
        'Discipline',
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name='primary_practitioners',
        verbose_name=_("Discipline principale")
    )
    
    secondary_disciplines = models.ManyToManyField(
        'Discipline',
        blank=True,
        related_name='secondary_practitioners',
        verbose_name=_("Disciplines secondaires")
    )
    
    # Coach specific fields
    is_coach = models.BooleanField(
        _("Est coach"),
        default=False,
        help_text=_("Indique si le pratiquant est également coach")
    )
    
    coaching_start_date = models.DateField(
        _("Date de début d'enseignement"),
        null=True,
        blank=True
    )
    
    gender = models.CharField(
        _("Genre"), 
        max_length=10, 
        choices=GENDER_CHOICES,
        default='male'
    )
    
    # Identifiants et documents officiels
    license_number = models.CharField(_("Numéro de licence"), max_length=50, blank=True)
    medical_certificate_date = models.DateField(_("Date du certificat médical"), null=True, blank=True)
    medical_certificate = models.FileField(
        _("Certificat médical"),
        upload_to='practitioners/certificates/',
        null=True,
        blank=True
    )
    parental_authorization = models.FileField(
        _("Autorisation parentale"),
        upload_to='practitioners/authorizations/',
        null=True,
        blank=True
    )
    
    # Coordonnées
    email = models.EmailField(_("Email"), blank=True, null=True)
    phone = models.CharField(_("Téléphone"), max_length=20, blank=True, null=True)
    address = models.CharField(_("Adresse"), max_length=255, blank=True, null=True)
    city = models.CharField(_("Ville"), max_length=100, blank=True, null=True)
    postal_code = models.CharField(_("Code postal"), max_length=20, blank=True, null=True)
    
    # Contact d'urgence
    emergency_contact_name = models.CharField(_("Nom du contact d'urgence"), max_length=100, blank=True, null=True)
    emergency_contact_relation = models.CharField(_("Relation avec le contact"), max_length=50, blank=True, null=True)
    emergency_contact_phone = models.CharField(_("Téléphone du contact d'urgence"), max_length=20, blank=True, null=True)
    emergency_contact_email = models.EmailField(_("Email du contact d'urgence"), blank=True, null=True)
    
    # Informations médicales
    blood_group = models.CharField(_("Groupe sanguin"), max_length=3, blank=True, null=True)
    allergies = models.TextField(_("Allergies"), blank=True, null=True)
    medical_conditions = models.TextField(_("Conditions médicales"), blank=True, null=True)
    
    # Informations complémentaires
    birth_place = models.CharField(_("Lieu de naissance"), max_length=100, blank=True, null=True)
    nationality = models.CharField(_("Nationalité"), max_length=50, blank=True, null=True)
    
    # Caractéristiques physiques pour les compétitions
    weight = models.DecimalField(_("Poids (kg)"), max_digits=5, decimal_places=2, null=True, blank=True)
    height = models.DecimalField(_("Taille (cm)"), max_digits=5, decimal_places=1, null=True, blank=True)
    
    # Médias
    photo = models.ImageField(_("Photo"), upload_to='practitioners/photos/', null=True, blank=True)
    
    # Disciplines pratiquées
    disciplines = models.ManyToManyField(
        'competitions.Discipline', 
        verbose_name=_("Disciplines pratiquées"),
        related_name="practitioners",
        blank=True
    )
    
    # Statut et métadonnées
    status = models.CharField(
        _("Statut"),
        max_length=20,
        choices=STATUS_CHOICES,
        default='active'
    )
    is_active = models.BooleanField(_("Actif"), default=True)
    notes = models.TextField(_("Notes"), blank=True)
    registration_date = models.DateField(_("Date d'inscription"), auto_now_add=True)
    membership_end_date = models.DateField(_("Date de fin d'adhésion"), null=True, blank=True)
    created_at = models.DateTimeField(_("Créé le"), auto_now_add=True)
    updated_at = models.DateTimeField(_("Mis Ã  jour le"), auto_now=True)
    
    # Champs pour la gestion familiale
    family = models.ForeignKey(
        'family_management.Family',
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name='family_practitioners',
        verbose_name=_("Famille"),
        help_text=_("Famille Ã  laquelle appartient ce pratiquant")
    )
    
    family_role = models.CharField(
        _("RÃ´le familial"),
        max_length=20,
        choices=[
            ('parent', _('Parent')),
            ('guardian', _('Tuteur légal')),
            ('child', _('Enfant')),
            ('spouse', _('Conjoint(e)')),
            ('sibling', _('Frère/SÅ“ur')),
            ('other', _('Autre'))
        ],
        blank=True,
        null=True,
        help_text=_("RÃ´le de ce pratiquant dans sa famille")
    )
    
    family_emergency_contact = models.CharField(
        _("Contact d'urgence familial"),
        max_length=200,
        blank=True,
        null=True,
        help_text=_("Contact d'urgence si différent du responsable familial")
    )
    
    @property
    def age(self):
        """Calcule l'Ã¢ge du pratiquant en années."""
        today = timezone.now().date()
        return today.year - self.birth_date.year - (
            (today.month, today.day) < (self.birth_date.month, self.birth_date.day)
        )
    
    @property
    def full_name(self):
        return f"{self.first_name} {self.last_name}"
    
    def __str__(self):
        return f"{self.full_name} ({self.organization.name if self.organization else 'Sans organisation'})"
    
    @property
    def current_grade(self):
        """Retourne le grade actuel du pratiquant"""
        # Déléguer Ã  l'application grades
        if self.grade:
            return self.grade
        
        # Utiliser l'application grades pour obtenir le grade actuel
        try:
            from apps.grades.models import PractitionerGrade
            current_grade = PractitionerGrade.objects.filter(
                practitioner=self,
                is_current=True
            ).select_related('grade').first()
            
            if current_grade:
                return current_grade.grade
        except ImportError:
            pass
            
        return None
    
    @property
    def grade_display(self):
        """Retourne le grade sous forme de texte"""
        grade = self.current_grade
        if grade:
            return str(grade)
        return self.grade_text or _("Non spécifié")
    
    def create_user_account(self, send_email=True):
        """
        Crée un compte utilisateur pour ce pratiquant s'il n'en a pas déjÃ  un.
        Retourne un tuple (user, password, created) oÃ¹ created est un booléen indiquant si un nouvel utilisateur a été créé.
        """
        if self.user:
            return self.user, None, False
        
        # Générer un nom d'utilisateur unique basé sur le nom et prénom
        base_username = f"{self.first_name.lower()}.{self.last_name.lower()}"
        username = base_username
        counter = 1
        
        # Vérifier l'unicité du nom d'utilisateur
        while User.objects.filter(username=username).exists():
            username = f"{base_username}{counter}"
            counter += 1
        
        # Générer un mot de passe aléatoire
        temp_password = str(uuid.uuid4())[:8]
        
        # Déterminer l'email Ã  utiliser
        email = self.email or f"{username}@example.com"
        
        # Créer l'utilisateur
        user = User.objects.create_user(
            username=username,
            email=email,
            password=temp_password,
            first_name=self.first_name,
            last_name=self.last_name
        )
        
        # Définir le rÃ´le de l'utilisateur comme participant et marquer l'onboarding comme terminé
        if hasattr(user, 'profile'):
            user.profile.role = 'participant'
            # Marquer l'onboarding comme terminé pour les pratiquants convertis
            user.profile.onboarding_completed = True
            user.profile.onboarding_step = 'completed'
            user.profile.save()
        else:
            # Créer le profil si il n'existe pas
            try:
                from .users import UserProfile
                profile = UserProfile.objects.create(
                    user=user,
                    role='participant',
                    onboarding_completed=True,
                    onboarding_step='completed'
                )
            except ImportError:
                pass
        
        # Associer l'utilisateur au pratiquant
        self.user = user
        self.save()
        
        # Créer et vérifier automatiquement l'adresse email pour django-allauth
        try:
            from allauth.account.models import EmailAddress
            if self.email and '@' in self.email and not self.email.endswith('@example.com'):
                email_address, created = EmailAddress.objects.get_or_create(
                    user=user,
                    email=self.email,
                    defaults={
                        'verified': True,
                        'primary': True
                    }
                )
                if not email_address.verified:
                    email_address.verified = True
                    email_address.primary = True
                    email_address.save()
        except ImportError:
            # django-allauth n'est pas installé
            pass
        
        # Envoyer l'email de notification si demandé et si l'email est valide
        if send_email and self.email and '@' in self.email and not self.email.endswith('@example.com'):
            self.send_account_creation_email(username, temp_password)
        
        return user, temp_password, True
    
    def send_account_creation_email(self, username, password):
        """
        Envoie un email de notification avec les identifiants du compte créé.
        """
        try:
            # Récupérer le club associé
            club = None
            if self.organization:
                # Essayer de récupérer le club depuis l'organisation
                try:
                    from apps.competitions.models import Club
                    club = Club.objects.filter(organization=self.organization).first()
                except ImportError:
                    pass
            
            # Générer l'URL de connexion
            login_url = f"{getattr(settings, 'BASE_URL', 'http://localhost:8000')}{reverse('account_login')}"
            
            # Contexte pour le template
            context = {
                'practitioner': self,
                'username': username,
                'password': password,
                'club': club,
                'login_url': login_url,
            }
            
            # Rendu des templates
            subject = f"Votre compte MartialComp a été créé - {self.full_name}"
            html_message = render_to_string('competitions/emails/user_account_created.html', context)
            text_message = render_to_string('competitions/emails/user_account_created.txt', context)
            
            # Envoi de l'email
            send_mail(
                subject=subject,
                message=text_message,
                from_email=getattr(settings, 'DEFAULT_FROM_EMAIL', 'noreply@martialcomp.com'),
                recipient_list=[self.email],
                html_message=html_message,
                fail_silently=False,
            )
            
            # Log de succès
            import logging
            logger = logging.getLogger(__name__)
            logger.info(f"Email de création de compte envoyé avec succès à {self.email} pour {self.full_name}")
            
        except Exception as e:
            # Log de l'erreur mais ne pas faire échouer la création du compte
            import logging
            logger = logging.getLogger(__name__)
            logger.error(f"Erreur lors de l'envoi de l'email de création de compte pour {self.full_name} ({self.email}): {str(e)}")
    
    def get_active_qualifications(self):
        """Récupère les qualifications actives du pratiquant."""
        return self.practitioner_qualifications.filter(is_active=True)
    
    def get_grade_history(self):
        """Récupère l'historique des grades du pratiquant."""
        try:
            from apps.grades.models import PractitionerGrade
            return PractitionerGrade.objects.filter(practitioner=self).order_by('-date_obtained')
        except ImportError:
            return []
    
    def is_eligible_for_competition(self, competition):
        """Vérifie si le pratiquant est éligible pour une compétition donnée."""
        # Vérifier la nouvelle méthode check_eligibility en priorité
        if hasattr(competition, 'check_eligibility'):
            try:
                is_eligible, reasons = competition.check_eligibility(self)
                return is_eligible
            except Exception as e:
                import logging
                logger = logging.getLogger(__name__)
                logger.warning(f"Erreur lors de la vérification d'éligibilité: {str(e)}")
        
        # Sinon, vérifier manuellement en sécurisant l'accès aux attributs
        # Vérifier l'Ã¢ge
        min_age = getattr(competition, 'min_age', None)
        if min_age is not None and self.age < min_age:
            return False
        
        max_age = getattr(competition, 'max_age', None)
        if max_age is not None and self.age > max_age:
            return False
        
        # Vérifier le certificat médical
        requires_medical = getattr(competition, 'requires_medical_certificate', False)
        if requires_medical and not self.medical_certificate_date:
            return False
        
        # Vérifier la licence
        requires_license = getattr(competition, 'requires_license', False)
        if requires_license and not self.license_number:
            return False
        
        return True
    
    @property
    def club(self):
        """
        Retourne le club legacy associé à l'organisation du pratiquant.
        Solution temporaire pour compatibilité avec TrainingSlot.
        
        TODO: À supprimer quand TrainingSlot.club pointera vers Organization
        """
        if self.organization:
            # Chercher le club legacy associé à cette organisation
            from .club import Club
            return Club.objects.filter(organization=self.organization).first()
        return None
    
    def get_available_categories(self, competition):
        """
        Détermine les catégories disponibles pour ce pratiquant dans une compétition.
        
        Args:
            competition: L'objet Competition pour lequel vérifier les catégories
        
        Returns:
            Un QuerySet de CompetitionCategory pour lesquelles le pratiquant est éligible
        """
        from . import CompetitionCategory
        
        if not self.is_eligible_for_competition(competition):
            return CompetitionCategory.objects.none()
        
        # Récupérer toutes les catégories pour cette compétition
        categories = CompetitionCategory.objects.filter(competition=competition)
        
        # Filtrer selon l'Ã¢ge
        if self.age is not None:
            categories = categories.filter(
                models.Q(min_age__isnull=True) | models.Q(min_age__lte=self.age),
                models.Q(max_age__isnull=True) | models.Q(max_age__gte=self.age)
            )
        
        # Filtrer selon le genre
        if self.gender != 'other':
            categories = categories.filter(
                models.Q(gender='mixed') | models.Q(gender=self.gender)
            )
        
        # Filtrer selon le poids (si applicable)
        if self.weight is not None:
            categories = categories.filter(
                models.Q(min_weight__isnull=True) | models.Q(min_weight__lte=self.weight),
                models.Q(max_weight__isnull=True) | models.Q(max_weight__gte=self.weight)
            )
        
        # Filtrer selon le grade (si applicable) - utilisant l'application grades
        current_grade = self.current_grade
        if current_grade:
            try:
                # Déléguer la vérification du grade Ã  l'application grades
                from apps.grades.utils import check_grade_eligibility
                eligible_category_ids = []
                
                for category in categories:
                    if check_grade_eligibility(current_grade, category.min_grade, category.max_grade):
                        eligible_category_ids.append(category.id)
                
                if eligible_category_ids:
                    categories = categories.filter(id__in=eligible_category_ids)
            except ImportError:
                # Fallback en cas d'absence de l'application grades
                pass
        
        return categories
    
    # ===== MÃ‰THODES POUR LA GESTION FAMILIALE =====
    
    def get_family_members(self):
        """Récupère tous les membres de la famille de ce pratiquant."""
        if not self.family:
            return []
        
        return self.family.get_all_members().exclude(practitioner=self)
    
    def get_family_practitioners(self):
        """Récupère tous les autres pratiquants de la mÃªme famille."""
        if not self.family:
            return []
        
        return self.family.get_practitioners().exclude(id=self.id) if self.family else []
    
    def is_family_responsible(self):
        """Vérifie si ce pratiquant est le responsable principal de sa famille."""
        if not self.family or not self.user:
            return False
        
        return self.family.primary_responsible == self.user
    
    def can_manage_family(self):
        """Vérifie si ce pratiquant peut gérer sa famille."""
        if not self.family or not self.user:
            return False
        
        # Responsable principal
        if self.is_family_responsible():
            return True
        
        # Vérifier les permissions du membre
        try:
            from apps.family_management.models import FamilyMember
            member = FamilyMember.objects.filter(
                family=self.family,
                user=self.user,
                is_active=True
            ).first()
            
            return member and member.has_permission('manage_family')
        except ImportError:
            return False
    
    def get_family_upcoming_events(self, days=30):
        """Récupère les événements Ã  venir pour la famille."""
        if not self.family:
            return []
        
        try:
            from apps.family_management.models import FamilyEvent
            from django.utils import timezone
            from datetime import timedelta
            
            end_date = timezone.now() + timedelta(days=days)
            
            return FamilyEvent.objects.filter(
                family=self.family,
                start_date__gte=timezone.now(),
                start_date__lte=end_date
            ).order_by('start_date')
        except ImportError:
            return []
    
    def get_family_pending_payments(self):
        """Récupère les paiements en attente pour la famille."""
        if not self.family:
            return []
        
        try:
            from apps.family_management.models import FamilyPaymentGroup
            
            return FamilyPaymentGroup.objects.filter(
                family=self.family,
                is_paid=False
            ).order_by('-created_at')
        except ImportError:
            return []
    
    def create_or_join_family(self, family_name=None, role='child'):
        """
        Crée une nouvelle famille ou rejoint une famille existante.
        
        Args:
            family_name: Nom de la famille (obligatoire pour création)
            role: RÃ´le dans la famille
            
        Returns:
            La famille créée ou rejointe
        """
        if self.family:
            return self.family
        
        if not self.user:
            raise ValueError("Le pratiquant doit avoir un compte utilisateur pour rejoindre une famille")
        
        try:
            from apps.family_management.models import Family, FamilyMember
            
            # Si pas de nom de famille fourni, essayer de créer Ã  partir du nom du pratiquant
            if not family_name:
                family_name = f"Famille {self.last_name}"
            
            # Créer la famille avec ce pratiquant comme responsable si c'est un parent
            if role in ['parent', 'guardian']:
                family = Family.objects.create(
                    family_name=family_name,
                    primary_responsible=self.user,
                    organization=self.organization
                )
            else:
                # Chercher une famille existante ou demander Ã  Ãªtre ajouté
                raise ValueError("Seuls les parents/tuteurs peuvent créer une famille")
            
            # Ajouter le pratiquant Ã  la famille
            self.family = family
            self.family_role = role
            self.save()
            
            return family
            
        except ImportError:
            raise ValueError("Module family_management non disponible")
    
    # Manager sécurisé pour l'isolation par organisation
    objects = OrganizationSecureManager()
    
    class Meta:
        app_label = 'competitions'
        verbose_name = _("Pratiquant")
        verbose_name_plural = _("Pratiquants")
        ordering = ['last_name', 'first_name']
        indexes = [
            models.Index(fields=['last_name', 'first_name']),
            models.Index(fields=['organization']),
            models.Index(fields=['user']),
        ]


# Fonctions utilitaires

def create_user_for_practitioner(first_name, last_name, email=None, organization=None):
    """
    Fonction utilitaire pour créer un utilisateur pour un pratiquant.
    Retourne un tuple (user, password).
    """
    # Générer un nom d'utilisateur unique basé sur le nom et prénom
    base_username = f"{first_name.lower()}.{last_name.lower()}"
    username = base_username
    counter = 1
    
    # Vérifier l'unicité du nom d'utilisateur
    while User.objects.filter(username=username).exists():
        username = f"{base_username}{counter}"
        counter += 1
    
    # Générer un mot de passe aléatoire
    temp_password = str(uuid.uuid4())[:8]
    
    # Créer l'utilisateur
    user = User.objects.create_user(
        username=username,
        email=email or f"{username}@example.com",  # Email par défaut si non fourni
        password=temp_password,
        first_name=first_name,
        last_name=last_name
    )
    
    # Définir le rÃ´le de l'utilisateur comme participant
    if hasattr(user, 'profile'):
        user.profile.role = 'participant'
        user.profile.organization = organization
        user.profile.save()
    
    return user, temp_password

def get_current_grade_for_discipline(self, discipline):
    """
    Récupère le grade actuel du pratiquant pour une discipline donnée.
    
    Args:
        discipline: Un objet Discipline ou l'ID d'une discipline
        
    Returns:
        Un objet PractitionerGrade représentant le grade actuel pour cette discipline,
        ou None si aucun grade n'est défini
    """
    try:
        # Importer dynamiquement pour éviter les imports circulaires
        from apps.grades.models import PractitionerGrade
        
        # Gérer le cas oÃ¹ discipline est un ID ou un objet
        discipline_id = discipline.id if hasattr(discipline, 'id') else discipline
        
        return PractitionerGrade.objects.filter(
            practitioner=self,
            discipline_id=discipline_id,
            is_current=True
        ).first()
    except ImportError:
        # Si l'application grades n'est pas disponible
        return None
    
def get_all_current_grades(self):
    """
    Récupère tous les grades actuels du pratiquant, regroupés par discipline.
    
    Returns:
        Un dictionnaire oÃ¹ les clés sont les IDs des disciplines et 
        les valeurs sont les objets PractitionerGrade correspondants
    """
    try:
        # Importer dynamiquement pour éviter les imports circulaires
        from apps.grades.models import PractitionerGrade
        
        # Récupérer tous les grades actuels en une seule requÃªte
        current_grades = PractitionerGrade.objects.filter(
            practitioner=self,
            is_current=True
        ).select_related('grade', 'discipline')
        
        # Organiser les grades par discipline
        grades_by_discipline = {}
        for grade in current_grades:
            grades_by_discipline[grade.discipline.id] = grade
            
        return grades_by_discipline
    except ImportError:
        # Si l'application grades n'est pas disponible
        return {}






