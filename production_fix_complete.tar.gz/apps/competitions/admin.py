# Administration minimale pour Practitioner
# Sans aucune référence aux disciplines pour éviter l'erreur Discipline.objects.get()

from django.contrib import admin
from django.utils.translation import gettext_lazy as _
from .models import Practitioner

class MinimalPractitionerAdmin(admin.ModelAdmin):
    """Administration minimale sans disciplines"""
    
    list_display = (
        'full_name', 
        'get_organization',
        'birth_date', 
        'age', 
        'license_number'
    )
    list_filter = (
        'organization',
        'gender',
        'status'
    )
    search_fields = (
        'first_name', 
        'last_name', 
        'license_number',
        'email',
        'organization__name'
    )
    
    readonly_fields = ('age',)
    
    # Exclure explicitement tous les champs de disciplines
    exclude = (
        'primary_discipline',
        'secondary_disciplines', 
        'disciplines'
    )
    
    def get_organization(self, obj):
        """Affiche l'organisation associée au pratiquant."""
        try:
            if hasattr(obj, 'organization') and obj.organization:
                return obj.organization.name
            return '-'
        except Exception as e:
            return f'Erreur: {e}'
    get_organization.short_description = 'Organisation'
    get_organization.admin_order_field = 'organization'
    
    def full_name(self, obj):
        try:
            return obj.full_name
        except Exception as e:
            return f'Erreur: {e}'
    full_name.short_description = 'Nom complet'
    full_name.admin_order_field = 'last_name'
    
    def get_queryset(self, request):
        queryset = super().get_queryset(request)
        try:
            queryset = queryset.select_related('organization', 'user')
        except Exception as e:
            pass
        return queryset

# Enregistrer l'administration minimale
admin.site.register(Practitioner, MinimalPractitionerAdmin)