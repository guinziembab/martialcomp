#!/bin/bash
# Script de correction pour l'onboarding fédération en production

echo "================================================"
echo "🔧 CORRECTION ONBOARDING FÉDÉRATION - PRODUCTION"
echo "================================================"
echo ""

PROJECT_DIR="/home/martialc/martialcomp"
BACKUP_DIR="/home/martialc/backups/federation_fix_$(date +%Y%m%d_%H%M%S)"

# Créer le répertoire de backup
echo "📁 Création du backup..."
mkdir -p $BACKUP_DIR

# Se positionner dans le projet
cd $PROJECT_DIR

# 1. Corriger le formulaire FederationCreationForm
echo ""
echo "1️⃣ Correction du formulaire..."

# Backup du fichier forms
if [ -f "apps/competitions/forms/competitions.py" ]; then
    cp apps/competitions/forms/competitions.py $BACKUP_DIR/
fi

# Créer un patch Python pour corriger le formulaire
cat > fix_federation_form.py << 'EOF'
import os
import re

# Lire le fichier forms
forms_file = "apps/competitions/forms/competitions.py"

with open(forms_file, 'r') as f:
    content = f.read()

# Vérifier si FederationCreationForm existe
if 'class FederationCreationForm' in content:
    print("✓ FederationCreationForm trouvé")
    
    # Extraire la classe
    import ast
    import inspect
    
    # Solution 1: Ajouter le widget CheckboxSelectMultiple pour disciplines
    new_form_code = '''class FederationCreationForm(forms.ModelForm):
    disciplines = forms.ModelMultipleChoiceField(
        queryset=Discipline.objects.filter(is_active=True),
        widget=forms.CheckboxSelectMultiple(attrs={
            'class': 'form-check-input'
        }),
        required=False,
        label=_("Disciplines")
    )
    
    class Meta:
        model = Federation
        fields = ['name', 'country', 'description', 'logo', 'disciplines']
        widgets = {
            'description': forms.Textarea(attrs={
                'rows': 3,
                'class': 'form-control'
            }),
            'name': forms.TextInput(attrs={
                'class': 'form-control'
            }),
            'country': forms.TextInput(attrs={
                'class': 'form-control'
            })
        }'''
    
    # Remplacer la classe existante
    class_start = content.find('class FederationCreationForm')
    if class_start != -1:
        # Trouver la fin de la classe
        class_end = content.find('\nclass ', class_start + 1)
        if class_end == -1:
            class_end = len(content)
        
        # Remplacer
        content = content[:class_start] + new_form_code + content[class_end:]
        
        # Écrire le fichier
        with open(forms_file, 'w') as f:
            f.write(content)
        
        print("✅ Formulaire corrigé avec CheckboxSelectMultiple")
    else:
        print("❌ Impossible de trouver la classe FederationCreationForm")
else:
    print("❌ FederationCreationForm introuvable - Ajout nécessaire")
    
    # Ajouter la classe si elle n'existe pas
    with open(forms_file, 'a') as f:
        f.write('\n\n' + new_form_code)
    print("✅ FederationCreationForm ajouté")
EOF

python fix_federation_form.py
rm fix_federation_form.py

# 2. Corriger le template
echo ""
echo "2️⃣ Correction du template..."

TEMPLATE_DIR="apps/competitions/templates/competitions/onboarding"
TEMPLATE_FILE="$TEMPLATE_DIR/federation_creation.html"

# Backup du template
if [ -f "$TEMPLATE_FILE" ]; then
    cp "$TEMPLATE_FILE" "$BACKUP_DIR/"
fi

# Créer un template corrigé qui utilise correctement le widget Django
cat > "$TEMPLATE_FILE.new" << 'EOF'
{% extends "competitions/onboarding/base_onboarding.html" %}
{% load i18n crispy_forms_tags %}

{% block title %}{% trans "Créer votre fédération" %}{% endblock %}

{% block content %}
<div class="container mt-5">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card shadow">
                <div class="card-header bg-primary text-white">
                    <h3 class="mb-0">{% trans "Configuration de votre fédération" %}</h3>
                </div>
                <div class="card-body">
                    <form method="post" enctype="multipart/form-data" id="federation-form">
                        {% csrf_token %}
                        
                        {% if form.non_field_errors %}
                            <div class="alert alert-danger">
                                {{ form.non_field_errors }}
                            </div>
                        {% endif %}
                        
                        <div class="mb-3">
                            <label for="{{ form.name.id_for_label }}" class="form-label">{{ form.name.label }}</label>
                            {{ form.name }}
                            {% if form.name.errors %}
                                <div class="text-danger">{{ form.name.errors }}</div>
                            {% endif %}
                        </div>
                        
                        <div class="mb-3">
                            <label for="{{ form.country.id_for_label }}" class="form-label">{{ form.country.label }}</label>
                            {{ form.country }}
                            {% if form.country.errors %}
                                <div class="text-danger">{{ form.country.errors }}</div>
                            {% endif %}
                        </div>
                        
                        <div class="mb-3">
                            <label for="{{ form.description.id_for_label }}" class="form-label">{{ form.description.label }}</label>
                            {{ form.description }}
                            {% if form.description.errors %}
                                <div class="text-danger">{{ form.description.errors }}</div>
                            {% endif %}
                        </div>
                        
                        <div class="mb-3">
                            <label class="form-label">{{ form.disciplines.label }}</label>
                            <div class="disciplines-container border rounded p-3" style="max-height: 300px; overflow-y: auto;">
                                {{ form.disciplines }}
                            </div>
                            {% if form.disciplines.errors %}
                                <div class="text-danger">{{ form.disciplines.errors }}</div>
                            {% endif %}
                            <small class="text-muted">{% trans "Sélectionnez les disciplines gérées par votre fédération" %}</small>
                        </div>
                        
                        <div class="d-grid gap-2">
                            <button type="submit" class="btn btn-primary btn-lg" id="submit-btn">
                                {% trans "Créer la fédération" %}
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    // Prévenir la double soumission
    const form = document.getElementById('federation-form');
    const submitBtn = document.getElementById('submit-btn');
    
    form.addEventListener('submit', function(e) {
        submitBtn.disabled = true;
        submitBtn.innerHTML = '<span class="spinner-border spinner-border-sm me-2"></span>{% trans "Création en cours..." %}';
    });
    
    // Améliorer l'affichage des checkboxes
    const checkboxes = document.querySelectorAll('.disciplines-container input[type="checkbox"]');
    checkboxes.forEach(function(checkbox) {
        // Ajouter les classes Bootstrap si nécessaire
        if (!checkbox.classList.contains('form-check-input')) {
            checkbox.classList.add('form-check-input');
        }
        
        // Wrap dans un div form-check si nécessaire
        const label = checkbox.nextElementSibling;
        if (label && label.tagName === 'LABEL' && !checkbox.parentElement.classList.contains('form-check')) {
            const wrapper = document.createElement('div');
            wrapper.className = 'form-check';
            checkbox.parentElement.insertBefore(wrapper, checkbox);
            wrapper.appendChild(checkbox);
            wrapper.appendChild(label);
            label.classList.add('form-check-label');
        }
    });
});
</script>
{% endblock %}
EOF

# Remplacer le template
mv "$TEMPLATE_FILE.new" "$TEMPLATE_FILE"
echo "✅ Template corrigé"

# 3. Désactiver temporairement le middleware problématique
echo ""
echo "3️⃣ Désactivation du middleware de redirection..."

SETTINGS_FILE="config/settings/production.py"

# Backup settings
cp $SETTINGS_FILE $BACKUP_DIR/

# Commenter le middleware OnboardingRedirectMiddleware
python << 'EOF'
settings_file = "config/settings/production.py"

with open(settings_file, 'r') as f:
    content = f.read()

# Commenter le middleware s'il existe
lines = content.split('\n')
new_lines = []
in_middleware = False

for line in lines:
    if 'MIDDLEWARE' in line and '=' in line:
        in_middleware = True
    elif in_middleware and ']' in line:
        in_middleware = False
    
    if in_middleware and 'OnboardingRedirectMiddleware' in line and not line.strip().startswith('#'):
        new_lines.append('    # ' + line.strip() + '  # TEMPORAIREMENT DÉSACTIVÉ')
        print("✓ OnboardingRedirectMiddleware désactivé")
    else:
        new_lines.append(line)

with open(settings_file, 'w') as f:
    f.write('\n'.join(new_lines))
EOF

# 4. S'assurer que les disciplines sont bien initialisées
echo ""
echo "4️⃣ Vérification des disciplines..."
python manage.py init_disciplines 2>/dev/null || echo "  ⚠️  Commande init_disciplines non trouvée"

# Vérifier manuellement
python manage.py shell << 'EOF'
from apps.competitions.models import Discipline

active_count = Discipline.objects.filter(is_active=True).count()
if active_count == 0:
    print("  ⚠️  Aucune discipline active - Création des disciplines par défaut...")
    disciplines = [
        ('Karaté', 'Art martial japonais'),
        ('Judo', 'Art martial japonais, sport olympique'),
        ('Taekwondo', 'Art martial coréen, sport olympique'),
        ('Kung Fu', 'Arts martiaux chinois'),
        ('Aikido', 'Art martial japonais défensif'),
        ('MMA', 'Arts martiaux mixtes'),
        ('Boxe', 'Sport de combat'),
        ('Muay Thai', 'Boxe thaïlandaise'),
    ]
    for name, desc in disciplines:
        Discipline.objects.get_or_create(
            name=name,
            defaults={'description': desc, 'is_active': True}
        )
    print(f"  ✅ {len(disciplines)} disciplines créées")
else:
    print(f"  ✅ {active_count} disciplines actives")
EOF

# 5. Collecter les fichiers statiques
echo ""
echo "5️⃣ Collection des fichiers statiques..."
python manage.py collectstatic --noinput

# 6. Redémarrer les services
echo ""
echo "6️⃣ Redémarrage des services..."
touch tmp/restart.txt
echo "✅ Passenger redémarré"

# Si systemctl est disponible
if command -v systemctl &> /dev/null; then
    sudo systemctl restart gunicorn 2>/dev/null && echo "✅ Gunicorn redémarré" || true
fi

echo ""
echo "================================================"
echo "✅ CORRECTIONS APPLIQUÉES!"
echo "================================================"
echo ""
echo "📋 Changements effectués:"
echo "1. Formulaire FederationCreationForm corrigé avec CheckboxSelectMultiple"
echo "2. Template federation_creation.html utilise maintenant {{ form.disciplines }}"
echo "3. Middleware OnboardingRedirectMiddleware désactivé temporairement"
echo "4. Disciplines vérifiées et créées si nécessaire"
echo ""
echo "🧪 Tests à effectuer:"
echo "1. Accéder à https://app.martialcomp.com/competitions/onboarding/federation/"
echo "2. Vérifier que les cases à cocher s'affichent"
echo "3. Sélectionner des disciplines et soumettre le formulaire"
echo "4. Vérifier la redirection vers le dashboard"
echo ""
echo "📁 Backup créé dans: $BACKUP_DIR"
echo ""
echo "🔄 Pour restaurer en cas de problème:"
echo "cp $BACKUP_DIR/* ."
echo "touch tmp/restart.txt"
echo ""