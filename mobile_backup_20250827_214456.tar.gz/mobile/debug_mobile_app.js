// Script de débogage rapide pour l'app mobile
const fs = require('fs');
const path = require('path');

console.log('🔍 DIAGNOSTIC APPLICATION MOBILE MARTIALCOMP');
console.log('==========================================\n');

// 1. Vérifier la configuration
console.log('1. Configuration actuelle :');
const envPath = path.join(__dirname, '.env');
if (fs.existsSync(envPath)) {
  const envContent = fs.readFileSync(envPath, 'utf8');
  const apiUrl = envContent.match(/EXPO_PUBLIC_API_URL=(.*)/);
  console.log('   ✓ Fichier .env trouvé');
  console.log(`   ✓ API URL: ${apiUrl ? apiUrl[1] : 'Non définie'}`);
} else {
  console.log('   ✗ Fichier .env manquant !');
}

// 2. Vérifier App.tsx
console.log('\n2. Point d\'entrée App.tsx :');
const appPath = path.join(__dirname, 'App.tsx');
if (fs.existsSync(appPath)) {
  console.log('   ✓ App.tsx trouvé');
  const appContent = fs.readFileSync(appPath, 'utf8');
  if (appContent.includes('RootNavigator')) {
    console.log('   ✓ RootNavigator importé');
  } else {
    console.log('   ⚠️ RootNavigator non trouvé dans App.tsx');
  }
} else {
  console.log('   ✗ App.tsx manquant !');
}

// 3. Vérifier les dépendances critiques
console.log('\n3. Dépendances critiques :');
const packageJsonPath = path.join(__dirname, 'package.json');
if (fs.existsSync(packageJsonPath)) {
  const packageJson = JSON.parse(fs.readFileSync(packageJsonPath, 'utf8'));
  const criticalDeps = [
    'react-native',
    'expo',
    'react-navigation',
    '@react-navigation/native',
    '@reduxjs/toolkit',
    'axios'
  ];
  
  criticalDeps.forEach(dep => {
    const version = packageJson.dependencies[dep] || packageJson.devDependencies[dep];
    if (version) {
      console.log(`   ✓ ${dep}: ${version}`);
    } else {
      console.log(`   ✗ ${dep}: MANQUANT`);
    }
  });
}

// 4. Vérifier la structure des dossiers
console.log('\n4. Structure des dossiers :');
const requiredDirs = ['src', 'src/screens', 'src/navigation', 'src/config'];
requiredDirs.forEach(dir => {
  const dirPath = path.join(__dirname, dir);
  if (fs.existsSync(dirPath)) {
    console.log(`   ✓ ${dir}/ existe`);
  } else {
    console.log(`   ✗ ${dir}/ MANQUANT`);
  }
});

// 5. Afficher la config API actuelle
console.log('\n5. Configuration API (src/config/api.ts) :');
const apiConfigPath = path.join(__dirname, 'src/config/api.ts');
if (fs.existsSync(apiConfigPath)) {
  const apiContent = fs.readFileSync(apiConfigPath, 'utf8');
  const apiUrlMatch = apiContent.match(/export const API_URL = (.*);/);
  console.log(`   Config: ${apiUrlMatch ? apiUrlMatch[1] : 'Non trouvée'}`);
}

console.log('\n==========================================');
console.log('SOLUTIONS POSSIBLES :');
console.log('1. Vérifier les logs dans Metro pour les erreurs');
console.log('2. Appuyer sur "r" dans Metro pour recharger');
console.log('3. Appuyer sur "w" pour tester dans le navigateur');
console.log('4. Vérifier que l\'iPhone et l\'ordinateur sont sur le même réseau');
console.log('5. Si erreur réseau, essayer avec ngrok ou tunnel');