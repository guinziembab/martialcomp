#!/usr/bin/env node

/**
 * Script pour générer un PDF à partir du document Markdown
 * Nécessite: npm install -g markdown-pdf
 */

const fs = require('fs');
const path = require('path');
const { exec } = require('child_process');

// Configuration
const INPUT_FILE = 'DOCUMENTATION_COMPLETE.md';
const OUTPUT_FILE = 'DOCUMENTATION_COMPLETE.pdf';
const CSS_FILE = 'pdf-style.css';

// Créer le fichier CSS pour le style PDF
const cssContent = `
body {
  font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
  line-height: 1.6;
  color: #333;
  max-width: 800px;
  margin: 0 auto;
  padding: 20px;
}

h1, h2, h3, h4, h5, h6 {
  color: #2c3e50;
  margin-top: 30px;
  margin-bottom: 15px;
}

h1 {
  font-size: 2.5em;
  border-bottom: 3px solid #3498db;
  padding-bottom: 10px;
}

h2 {
  font-size: 2em;
  border-bottom: 2px solid #3498db;
  padding-bottom: 8px;
}

h3 {
  font-size: 1.5em;
  color: #2980b9;
}

h4 {
  font-size: 1.3em;
  color: #34495e;
}

p {
  margin-bottom: 15px;
  text-align: justify;
}

ul, ol {
  margin-bottom: 15px;
  padding-left: 30px;
}

li {
  margin-bottom: 5px;
}

code {
  background-color: #f8f9fa;
  padding: 2px 6px;
  border-radius: 3px;
  font-family: 'Courier New', monospace;
  font-size: 0.9em;
}

pre {
  background-color: #f8f9fa;
  padding: 15px;
  border-radius: 5px;
  overflow-x: auto;
  border-left: 4px solid #3498db;
}

pre code {
  background-color: transparent;
  padding: 0;
}

blockquote {
  border-left: 4px solid #3498db;
  padding-left: 15px;
  margin-left: 0;
  color: #7f8c8d;
}

table {
  border-collapse: collapse;
  width: 100%;
  margin: 20px 0;
}

th, td {
  border: 1px solid #ddd;
  padding: 12px;
  text-align: left;
}

th {
  background-color: #3498db;
  color: white;
  font-weight: bold;
}

tr:nth-child(even) {
  background-color: #f2f2f2;
}

/* Styles spécifiques pour les sections */
.architecture-diagram {
  text-align: center;
  margin: 20px 0;
  padding: 15px;
  background-color: #ecf0f1;
  border-radius: 5px;
}

.feature-list {
  background-color: #e8f5e8;
  padding: 15px;
  border-radius: 5px;
  margin: 15px 0;
}

.onboarding-step {
  background-color: #fff3cd;
  padding: 15px;
  border-radius: 5px;
  margin: 15px 0;
  border-left: 4px solid #ffc107;
}

.code-example {
  background-color: #f8f9fa;
  padding: 15px;
  border-radius: 5px;
  margin: 15px 0;
  border: 1px solid #dee2e6;
}

/* Emojis et icônes */
.emoji {
  font-size: 1.2em;
  margin-right: 5px;
}

/* Page break */
.page-break {
  page-break-before: always;
}

/* Header et footer */
.header {
  text-align: center;
  margin-bottom: 30px;
  padding-bottom: 20px;
  border-bottom: 2px solid #3498db;
}

.footer {
  text-align: center;
  margin-top: 30px;
  padding-top: 20px;
  border-top: 1px solid #bdc3c7;
  font-size: 0.9em;
  color: #7f8c8d;
}

/* Table des matières */
.toc {
  background-color: #f8f9fa;
  padding: 20px;
  border-radius: 5px;
  margin: 20px 0;
}

.toc ul {
  list-style-type: none;
  padding-left: 0;
}

.toc li {
  margin-bottom: 8px;
}

.toc a {
  color: #3498db;
  text-decoration: none;
}

.toc a:hover {
  text-decoration: underline;
}

/* Responsive design pour PDF */
@media print {
  body {
    font-size: 12pt;
  }
  
  h1 { font-size: 18pt; }
  h2 { font-size: 16pt; }
  h3 { font-size: 14pt; }
  h4 { font-size: 12pt; }
  
  .page-break {
    page-break-before: always;
  }
}
`;

// Fonction pour créer le fichier CSS
function createCSSFile() {
  fs.writeFileSync(CSS_FILE, cssContent);
  console.log('✅ Fichier CSS créé:', CSS_FILE);
}

// Fonction pour vérifier si markdown-pdf est installé
function checkMarkdownPdf() {
  return new Promise((resolve, reject) => {
    exec('markdown-pdf --version', (error, stdout, stderr) => {
      if (error) {
        console.log('❌ markdown-pdf n\'est pas installé');
        console.log('📦 Installation...');
        exec('npm install -g markdown-pdf', (installError) => {
          if (installError) {
            reject(new Error('Impossible d\'installer markdown-pdf'));
          } else {
            console.log('✅ markdown-pdf installé avec succès');
            resolve();
          }
        });
      } else {
        console.log('✅ markdown-pdf est déjà installé');
        resolve();
      }
    });
  });
}

// Fonction pour générer le PDF
function generatePDF() {
  return new Promise((resolve, reject) => {
    const command = `markdown-pdf ${INPUT_FILE} -o ${OUTPUT_FILE} -c ${CSS_FILE}`;
    
    console.log('🔄 Génération du PDF...');
    console.log(`📝 Commande: ${command}`);
    
    exec(command, (error, stdout, stderr) => {
      if (error) {
        console.error('❌ Erreur lors de la génération du PDF:', error);
        reject(error);
      } else {
        console.log('✅ PDF généré avec succès:', OUTPUT_FILE);
        resolve();
      }
    });
  });
}

// Fonction principale
async function main() {
  try {
    console.log('🚀 Début de la génération du PDF...');
    
    // Vérifier que le fichier Markdown existe
    if (!fs.existsSync(INPUT_FILE)) {
      throw new Error(`Le fichier ${INPUT_FILE} n'existe pas`);
    }
    
    // Créer le fichier CSS
    createCSSFile();
    
    // Vérifier et installer markdown-pdf si nécessaire
    await checkMarkdownPdf();
    
    // Générer le PDF
    await generatePDF();
    
    console.log('🎉 Génération terminée avec succès !');
    console.log(`📄 Fichier PDF créé: ${OUTPUT_FILE}`);
    
    // Nettoyer le fichier CSS temporaire
    if (fs.existsSync(CSS_FILE)) {
      fs.unlinkSync(CSS_FILE);
      console.log('🧹 Fichier CSS temporaire supprimé');
    }
    
  } catch (error) {
    console.error('❌ Erreur:', error.message);
    process.exit(1);
  }
}

// Exécuter le script
if (require.main === module) {
  main();
}

module.exports = { main, createCSSFile, checkMarkdownPdf, generatePDF }; 

/**
 * Script pour générer un PDF à partir du document Markdown
 * Nécessite: npm install -g markdown-pdf
 */

const fs = require('fs');
const path = require('path');
const { exec } = require('child_process');

// Configuration
const INPUT_FILE = 'DOCUMENTATION_COMPLETE.md';
const OUTPUT_FILE = 'DOCUMENTATION_COMPLETE.pdf';
const CSS_FILE = 'pdf-style.css';

// Créer le fichier CSS pour le style PDF
const cssContent = `
body {
  font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
  line-height: 1.6;
  color: #333;
  max-width: 800px;
  margin: 0 auto;
  padding: 20px;
}

h1, h2, h3, h4, h5, h6 {
  color: #2c3e50;
  margin-top: 30px;
  margin-bottom: 15px;
}

h1 {
  font-size: 2.5em;
  border-bottom: 3px solid #3498db;
  padding-bottom: 10px;
}

h2 {
  font-size: 2em;
  border-bottom: 2px solid #3498db;
  padding-bottom: 8px;
}

h3 {
  font-size: 1.5em;
  color: #2980b9;
}

h4 {
  font-size: 1.3em;
  color: #34495e;
}

p {
  margin-bottom: 15px;
  text-align: justify;
}

ul, ol {
  margin-bottom: 15px;
  padding-left: 30px;
}

li {
  margin-bottom: 5px;
}

code {
  background-color: #f8f9fa;
  padding: 2px 6px;
  border-radius: 3px;
  font-family: 'Courier New', monospace;
  font-size: 0.9em;
}

pre {
  background-color: #f8f9fa;
  padding: 15px;
  border-radius: 5px;
  overflow-x: auto;
  border-left: 4px solid #3498db;
}

pre code {
  background-color: transparent;
  padding: 0;
}

blockquote {
  border-left: 4px solid #3498db;
  padding-left: 15px;
  margin-left: 0;
  color: #7f8c8d;
}

table {
  border-collapse: collapse;
  width: 100%;
  margin: 20px 0;
}

th, td {
  border: 1px solid #ddd;
  padding: 12px;
  text-align: left;
}

th {
  background-color: #3498db;
  color: white;
  font-weight: bold;
}

tr:nth-child(even) {
  background-color: #f2f2f2;
}

/* Styles spécifiques pour les sections */
.architecture-diagram {
  text-align: center;
  margin: 20px 0;
  padding: 15px;
  background-color: #ecf0f1;
  border-radius: 5px;
}

.feature-list {
  background-color: #e8f5e8;
  padding: 15px;
  border-radius: 5px;
  margin: 15px 0;
}

.onboarding-step {
  background-color: #fff3cd;
  padding: 15px;
  border-radius: 5px;
  margin: 15px 0;
  border-left: 4px solid #ffc107;
}

.code-example {
  background-color: #f8f9fa;
  padding: 15px;
  border-radius: 5px;
  margin: 15px 0;
  border: 1px solid #dee2e6;
}

/* Emojis et icônes */
.emoji {
  font-size: 1.2em;
  margin-right: 5px;
}

/* Page break */
.page-break {
  page-break-before: always;
}

/* Header et footer */
.header {
  text-align: center;
  margin-bottom: 30px;
  padding-bottom: 20px;
  border-bottom: 2px solid #3498db;
}

.footer {
  text-align: center;
  margin-top: 30px;
  padding-top: 20px;
  border-top: 1px solid #bdc3c7;
  font-size: 0.9em;
  color: #7f8c8d;
}

/* Table des matières */
.toc {
  background-color: #f8f9fa;
  padding: 20px;
  border-radius: 5px;
  margin: 20px 0;
}

.toc ul {
  list-style-type: none;
  padding-left: 0;
}

.toc li {
  margin-bottom: 8px;
}

.toc a {
  color: #3498db;
  text-decoration: none;
}

.toc a:hover {
  text-decoration: underline;
}

/* Responsive design pour PDF */
@media print {
  body {
    font-size: 12pt;
  }
  
  h1 { font-size: 18pt; }
  h2 { font-size: 16pt; }
  h3 { font-size: 14pt; }
  h4 { font-size: 12pt; }
  
  .page-break {
    page-break-before: always;
  }
}
`;

// Fonction pour créer le fichier CSS
function createCSSFile() {
  fs.writeFileSync(CSS_FILE, cssContent);
  console.log('✅ Fichier CSS créé:', CSS_FILE);
}

// Fonction pour vérifier si markdown-pdf est installé
function checkMarkdownPdf() {
  return new Promise((resolve, reject) => {
    exec('markdown-pdf --version', (error, stdout, stderr) => {
      if (error) {
        console.log('❌ markdown-pdf n\'est pas installé');
        console.log('📦 Installation...');
        exec('npm install -g markdown-pdf', (installError) => {
          if (installError) {
            reject(new Error('Impossible d\'installer markdown-pdf'));
          } else {
            console.log('✅ markdown-pdf installé avec succès');
            resolve();
          }
        });
      } else {
        console.log('✅ markdown-pdf est déjà installé');
        resolve();
      }
    });
  });
}

// Fonction pour générer le PDF
function generatePDF() {
  return new Promise((resolve, reject) => {
    const command = `markdown-pdf ${INPUT_FILE} -o ${OUTPUT_FILE} -c ${CSS_FILE}`;
    
    console.log('🔄 Génération du PDF...');
    console.log(`📝 Commande: ${command}`);
    
    exec(command, (error, stdout, stderr) => {
      if (error) {
        console.error('❌ Erreur lors de la génération du PDF:', error);
        reject(error);
      } else {
        console.log('✅ PDF généré avec succès:', OUTPUT_FILE);
        resolve();
      }
    });
  });
}

// Fonction principale
async function main() {
  try {
    console.log('🚀 Début de la génération du PDF...');
    
    // Vérifier que le fichier Markdown existe
    if (!fs.existsSync(INPUT_FILE)) {
      throw new Error(`Le fichier ${INPUT_FILE} n'existe pas`);
    }
    
    // Créer le fichier CSS
    createCSSFile();
    
    // Vérifier et installer markdown-pdf si nécessaire
    await checkMarkdownPdf();
    
    // Générer le PDF
    await generatePDF();
    
    console.log('🎉 Génération terminée avec succès !');
    console.log(`📄 Fichier PDF créé: ${OUTPUT_FILE}`);
    
    // Nettoyer le fichier CSS temporaire
    if (fs.existsSync(CSS_FILE)) {
      fs.unlinkSync(CSS_FILE);
      console.log('🧹 Fichier CSS temporaire supprimé');
    }
    
  } catch (error) {
    console.error('❌ Erreur:', error.message);
    process.exit(1);
  }
}

// Exécuter le script
if (require.main === module) {
  main();
}

module.exports = { main, createCSSFile, checkMarkdownPdf, generatePDF }; 