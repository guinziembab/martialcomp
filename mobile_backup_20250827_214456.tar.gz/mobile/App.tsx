import React, { useEffect, useState } from 'react';
import { SafeAreaProvider } from 'react-native-safe-area-context';
import { Provider as ReduxProvider } from 'react-redux';
import { NavigationContainer } from '@react-navigation/native';
import * as SplashScreen from 'expo-splash-screen';
import { Platform } from 'react-native';
import * as Font from 'expo-font';
import { StatusBar } from 'expo-status-bar';
import { View, Text, StyleSheet, ActivityIndicator } from 'react-native';

import { store } from './src/store';
import RootNavigator from './src/navigation/RootNavigator';
import { ThemeProvider } from './src/theme/ThemeProvider';

// Keep the splash screen visible while we fetch resources (native only)
if (Platform.OS !== 'web') {
  try {
    SplashScreen.preventAutoHideAsync();
  } catch (e) {
    console.warn('SplashScreen not available on this platform');
  }
}

// Loading component for better UX
const LoadingScreen = ({ error }: { error?: string }) => (
  <View style={styles.loadingContainer}>
    <Text style={styles.title}>MartialComp</Text>
    <Text style={styles.subtitle}>Martial Arts Competition Management</Text>

    {error ? (
      <View style={styles.errorContainer}>
        <Text style={styles.errorText}>Erreur de chargement:</Text>
        <Text style={styles.errorDetails}>{error}</Text>
      </View>
    ) : (
      <View style={styles.loadingIndicator}>
        <ActivityIndicator size="large" color="#007AFF" />
        <Text style={styles.loadingText}>Chargement...</Text>
      </View>
    )}
  </View>
);

export default function App() {
  const [appIsReady, setAppIsReady] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    async function prepare() {
      try {
        console.log('🚀 Démarrage de l\'application MartialComp...');

        // Load fonts (remove artificial delay!)
        await Font.loadAsync({
          // Add any custom fonts here if needed
          // 'custom-font': require('./assets/fonts/custom-font.ttf'),
        });

        console.log('✅ Fonts chargées avec succès');

        // Initialize i18n
        console.log('🌍 Initialisation de l\'internationalisation...');

        // Initialize API client (optional pre-check)
        console.log('🔌 Vérification de la connectivité API...');

        console.log('✅ Application prête à démarrer');

      } catch (e) {
        console.error('❌ Erreur lors de l\'initialisation:', e);
        setError(e instanceof Error ? e.message : 'Erreur inconnue');
      } finally {
        // Always set the app as ready
        setAppIsReady(true);
      }
    }

    prepare();
  }, []);

  useEffect(() => {
    if (appIsReady && Platform.OS !== 'web') {
      // Hide splash screen once ready (native only)
      console.log('🎉 Masquage du splash screen');
      SplashScreen.hideAsync().catch(console.error);
    }
  }, [appIsReady]);

  // Show loading screen while not ready
  if (!appIsReady) {
    return null; // Let expo splash screen handle this
  }

  // Show error screen if there was an error
  if (error) {
    return <LoadingScreen error={error} />;
  }

  // Main app component
  try {
    return (
      <ReduxProvider store={store}>
        <SafeAreaProvider>
          <ThemeProvider>
            <NavigationContainer
              onStateChange={(state) => {
                console.log('📱 Navigation state changed:', state);
              }}
              onError={(error) => {
                console.error('❌ Navigation error:', error);
              }}
            >
              <StatusBar style="auto" />
              <RootNavigator />
            </NavigationContainer>
          </ThemeProvider>
        </SafeAreaProvider>
      </ReduxProvider>
    );
  } catch (renderError) {
    console.error('❌ Erreur de rendu:', renderError);
    return (
      <LoadingScreen
        error={renderError instanceof Error ? renderError.message : 'Erreur de rendu'}
      />
    );
  }
}

const styles = StyleSheet.create({
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#4A90E2',
    padding: 20,
  },
  title: {
    fontSize: 32,
    fontWeight: 'bold',
    color: '#FFFFFF',
    marginBottom: 8,
    textAlign: 'center',
  },
  subtitle: {
    fontSize: 16,
    color: '#E6F3FF',
    marginBottom: 40,
    textAlign: 'center',
  },
  loadingIndicator: {
    alignItems: 'center',
  },
  loadingText: {
    fontSize: 16,
    color: '#FFFFFF',
    marginTop: 16,
  },
  errorContainer: {
    backgroundColor: 'rgba(255, 255, 255, 0.1)',
    padding: 20,
    borderRadius: 8,
    marginTop: 20,
  },
  errorText: {
    fontSize: 18,
    color: '#FFD700',
    fontWeight: 'bold',
    marginBottom: 8,
    textAlign: 'center',
  },
  errorDetails: {
    fontSize: 14,
    color: '#FFFFFF',
    textAlign: 'center',
  },
});