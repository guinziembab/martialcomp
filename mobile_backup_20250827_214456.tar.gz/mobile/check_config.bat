@echo off
echo ================================================
echo ANALYSE CONFIGURATION MOBILE MARTIALCOMP
echo ================================================
echo.

echo 1. VERIFICATION DES FICHIERS:
echo.

if exist ".env" (
    echo [OK] .env existe
    type .env | findstr "EXPO_PUBLIC_API_URL"
) else (
    echo [ERREUR] .env MANQUANT!
    echo Copier .env.production vers .env
)

echo.
echo 2. VERIFICATION API CONFIG:
echo.

if exist "src\config\api.ts" (
    echo [OK] src\config\api.ts existe
    type "src\config\api.ts" | findstr "API_URL"
) else (
    echo [ERREUR] src\config\api.ts MANQUANT!
)

echo.
echo 3. MODULES INSTALLES:
echo.

if exist "node_modules" (
    echo [OK] node_modules present
) else (
    echo [ERREUR] node_modules MANQUANT!
    echo Executer: npm install
)

echo.
echo ================================================
echo COMMANDES POUR CORRIGER:
echo.

if not exist ".env" (
    echo copy .env.production .env
)

if not exist "node_modules" (
    echo npm install
)

echo.
echo Pour demarrer: npm start
echo ================================================