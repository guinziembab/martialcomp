# Script PowerShell corrigé pour analyser la configuration mobile
Write-Host "================================================" -ForegroundColor Cyan
Write-Host "ANALYSE CONFIGURATION MOBILE MARTIALCOMP" -ForegroundColor Cyan
Write-Host "================================================" -ForegroundColor Cyan
Write-Host ""

# 1. Vérifier le répertoire actuel
Write-Host "1. REPERTOIRE DE TRAVAIL:" -ForegroundColor Yellow
$currentDir = Get-Location
Write-Host "   $currentDir" -ForegroundColor Green

# 2. Vérifier les fichiers de configuration
Write-Host "`n2. FICHIERS DE CONFIGURATION:" -ForegroundColor Yellow
$configFiles = @(".env", ".env.production", "app.json", "package.json")
foreach ($file in $configFiles) {
    if (Test-Path $file) {
        Write-Host "   OK: $file existe" -ForegroundColor Green
    } else {
        Write-Host "   ERREUR: $file MANQUANT" -ForegroundColor Red
    }
}

# 3. Vérifier le contenu de .env
Write-Host "`n3. CONFIGURATION .ENV:" -ForegroundColor Yellow
if (Test-Path ".env") {
    $envContent = Get-Content ".env"
    foreach ($line in $envContent) {
        if ($line -match "EXPO_PUBLIC_API_URL") {
            Write-Host "   $line" -ForegroundColor Cyan
            if ($line -match "martialcomp.com") {
                Write-Host "   OK: Configure pour PRODUCTION" -ForegroundColor Green
            } else {
                Write-Host "   ATTENTION: Configure pour DEVELOPPEMENT" -ForegroundColor Yellow
            }
        }
    }
} else {
    Write-Host "   ERREUR: Fichier .env manquant!" -ForegroundColor Red
    Write-Host "   Action: copy .env.production .env" -ForegroundColor Yellow
}

# 4. Vérifier node_modules
Write-Host "`n4. MODULES INSTALLES:" -ForegroundColor Yellow
if (Test-Path "node_modules") {
    Write-Host "   OK: node_modules present" -ForegroundColor Green
} else {
    Write-Host "   ERREUR: node_modules MANQUANT" -ForegroundColor Red
    Write-Host "   Action: npm install" -ForegroundColor Yellow
}

# 5. Afficher les actions
Write-Host "`n================================================" -ForegroundColor Cyan
Write-Host "ACTIONS NECESSAIRES:" -ForegroundColor Yellow

if (-not (Test-Path ".env")) {
    Write-Host " - copy .env.production .env" -ForegroundColor Yellow
}

if (-not (Test-Path "node_modules")) {
    Write-Host " - npm install" -ForegroundColor Yellow
}

$ready = $true
if (-not (Test-Path ".env") -or -not (Test-Path "node_modules")) {
    $ready = $false
}

if ($ready) {
    Write-Host "`nOK: Configuration prete!" -ForegroundColor Green
    Write-Host "Executer: npm start" -ForegroundColor Cyan
} else {
    Write-Host "`nCorriger les erreurs ci-dessus avant de continuer" -ForegroundColor Red
}

Write-Host ""