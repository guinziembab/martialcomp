// Metro configuration for Expo (Windows-friendly)
// - Blocks node_modules/.bin to avoid EACCES watcher errors on Windows
// - Uses Expo default config

const { getDefaultConfig } = require('expo/metro-config');
const exclusionList = require('metro-config/src/defaults/exclusionList');

/** @type {import('metro-config').MetroConfig} */
const config = getDefaultConfig(__dirname);

config.resolver = config.resolver || {};
config.resolver.blockList = exclusionList([
  /node_modules[\\\/]\.bin[\\\/] .*/, // any file under node_modules/.bin
  /node_modules[\\\/]\.cache[\\\/].*/, // optional: cache dir
]);

module.exports = config;
