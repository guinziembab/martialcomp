# Script PowerShell pour analyser la configuration mobile
Write-Host "================================================" -ForegroundColor Cyan
Write-Host "ANALYSE CONFIGURATION MOBILE MARTIALCOMP" -ForegroundColor Cyan
Write-Host "================================================" -ForegroundColor Cyan
Write-Host ""

# 1. Vérifier le répertoire actuel
Write-Host "1. RÉPERTOIRE DE TRAVAIL:" -ForegroundColor Yellow
$currentDir = Get-Location
Write-Host "   $currentDir" -ForegroundColor Green
if ($currentDir.Path -like "*\martialcomp\mobile*") {
    Write-Host "   ✓ Bon répertoire" -ForegroundColor Green
} else {
    Write-Host "   ✗ Mauvais répertoire!" -ForegroundColor Red
}

# 2. Vérifier les fichiers de configuration
Write-Host "`n2. FICHIERS DE CONFIGURATION:" -ForegroundColor Yellow
$configFiles = @(".env", ".env.production", "app.json", "package.json", "tsconfig.json")
foreach ($file in $configFiles) {
    if (Test-Path $file) {
        Write-Host "   ✓ $file existe" -ForegroundColor Green
    } else {
        Write-Host "   ✗ $file MANQUANT" -ForegroundColor Red
    }
}

# 3. Vérifier le contenu de .env
Write-Host "`n3. CONFIGURATION .ENV:" -ForegroundColor Yellow
if (Test-Path ".env") {
    $envContent = Get-Content ".env"
    $apiUrl = $envContent | Where-Object { $_ -match "EXPO_PUBLIC_API_URL" }
    if ($apiUrl) {
        Write-Host "   $apiUrl" -ForegroundColor Cyan
        if ($apiUrl -match "martialcomp.com") {
            Write-Host "   ✓ Configuré pour PRODUCTION" -ForegroundColor Green
        } else {
            Write-Host "   ⚠ Configuré pour DÉVELOPPEMENT" -ForegroundColor Yellow
        }
    }
} else {
    Write-Host "   ✗ Fichier .env manquant!" -ForegroundColor Red
    Write-Host "   → Copier .env.production vers .env" -ForegroundColor Yellow
}

# 4. Vérifier src/config/api.ts
Write-Host "`n4. CONFIGURATION API (src/config/api.ts):" -ForegroundColor Yellow
if (Test-Path "src\config\api.ts") {
    $apiConfig = Get-Content "src\config\api.ts" | Select-String "API_URL"
    $apiConfig | ForEach-Object { Write-Host "   $_" -ForegroundColor Cyan }
} else {
    Write-Host "   ✗ src/config/api.ts MANQUANT" -ForegroundColor Red
}

# 5. Vérifier les dépendances
Write-Host "`n5. DÉPENDANCES NPM:" -ForegroundColor Yellow
if (Test-Path "package.json") {
    $packageJson = Get-Content "package.json" | ConvertFrom-Json
    Write-Host "   Version app: $($packageJson.version)" -ForegroundColor Cyan
    
    $criticalDeps = @("expo", "react-native", "axios", "@react-navigation/native", "@reduxjs/toolkit")
    foreach ($dep in $criticalDeps) {
        if ($packageJson.dependencies.$dep) {
            Write-Host "   ✓ $dep : $($packageJson.dependencies.$dep)" -ForegroundColor Green
        } else {
            Write-Host "   ✗ $dep : MANQUANT" -ForegroundColor Red
        }
    }
}

# 6. Vérifier node_modules
Write-Host "`n6. MODULES INSTALLÉS:" -ForegroundColor Yellow
if (Test-Path "node_modules") {
    $moduleCount = (Get-ChildItem "node_modules" | Measure-Object).Count
    Write-Host "   ✓ $moduleCount modules installés" -ForegroundColor Green
} else {
    Write-Host "   ✗ node_modules MANQUANT - Exécuter: npm install" -ForegroundColor Red
}

# 7. Vérifier la structure des dossiers
Write-Host "`n7. STRUCTURE DES DOSSIERS:" -ForegroundColor Yellow
$requiredDirs = @("src", "src\screens", "src\navigation", "src\config", "src\services")
foreach ($dir in $requiredDirs) {
    if (Test-Path $dir) {
        Write-Host "   ✓ $dir\" -ForegroundColor Green
    } else {
        Write-Host "   ✗ $dir\ MANQUANT" -ForegroundColor Red
    }
}

# 8. Recommandations
Write-Host "`n================================================" -ForegroundColor Cyan
Write-Host "ACTIONS RECOMMANDÉES:" -ForegroundColor Yellow
Write-Host ""

$issues = @()

if (-not (Test-Path ".env")) {
    $issues += "copy .env.production .env"
}

if (-not (Test-Path "node_modules")) {
    $issues += "npm install"
}

$envContent = Get-Content ".env" -ErrorAction SilentlyContinue
if ($envContent -and -not ($envContent -match "martialcomp.com")) {
    $issues += "Mettre à jour .env avec l'URL de production"
}

if ($issues.Count -eq 0) {
    Write-Host "✅ CONFIGURATION OK - Prêt pour les tests!" -ForegroundColor Green
    Write-Host ""
    Write-Host "Exécuter: npm start" -ForegroundColor Cyan
} else {
    Write-Host "⚠ CORRECTIONS NÉCESSAIRES:" -ForegroundColor Yellow
    foreach ($issue in $issues) {
        Write-Host "   - $issue" -ForegroundColor Yellow
    }
}

Write-Host ""