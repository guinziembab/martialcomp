# 🥋 Directive de Cohérence Mobile MartialComp

## 🚨 ÉTAT ACTUEL : INCOHÉRENCE CRITIQUE

### **Problèmes Identifiés**

1. **❌ DONNÉES INCORRECTES**
   - Mobile : "Welcome back, User" + toutes stats à 0
   - Backend : "ClaudiuG" + 4 practitioners, 1 competition
   - **Impact** : Utilisateur déconnecté de ses vraies données

2. **❌ DESIGN TROP SOMBRE** 
   - Mobile : Noir total, interface froide
   - Site public : Rouge/or professionnel, chaleureux
   - **Impact** : Perte d'identité de marque MartialComp

3. **❌ NAVIGATION GÉNÉRIQUE**
   - Mobile : Modules basiques sans spécificité métier
   - Backend : Navigation riche (14 modules spécialisés)
   - **Impact** : App mobile sous-exploitée

---

## 🎯 OBJECTIFS DE COHÉRENCE

### **Vision Target**
**L'app mobile doit refléter fidèlement l'expérience backend, avec l'identité visuelle du site public, tout en conservant l'ergonomie mobile.**

### **Principes Directeurs**

1. **🔄 Synchronisation Données** 
   - Même utilisateur, mêmes statistiques, mêmes informations
   
2. **🎨 Cohérence Visuelle**
   - Palette couleurs du site public (rouge #DC143C + or #FFD700)
   - Moins de noir, plus de contraste élégant
   
3. **📱 Expérience Équivalente**
   - Fonctionnalités backend adaptées au mobile
   - Navigation intuitive mais complète

---

## 🎨 REFONTE VISUELLE PRIORITAIRE

### **Nouvelle Palette (Site Public → Mobile)**

```typescript
export const martialCompTheme = {
  colors: {
    // Couleurs principales (du site public)
    primary: '#DC143C',        // Rouge MartialComp
    secondary: '#FFD700',      // Or élégant (accents)
    accent: '#FF6B35',         // Orange martial
    
    // Arrière-plans (moins sombres)
    background: '#FFFFFF',     // Blanc principal
    backgroundSecondary: '#F8F9FA', // Gris très clair
    surface: '#FFFFFF',        // Blanc (cartes)
    surfaceSecondary: '#F1F3F4', // Gris clair
    
    // Textes (contraste adapté)
    text: '#212529',           // Noir texte
    textSecondary: '#6C757D',  // Gris moyen
    textOnPrimary: '#FFFFFF',  // Blanc sur rouge
    textOnSecondary: '#000000', // Noir sur or
    
    // Bordures et dividers
    border: '#DEE2E6',
    divider: '#E9ECEF',
    
    // Zones sombres (limitées)
    darkSection: '#343A40',    // Pour sections spéciales uniquement
    
    // États
    success: '#28A745',
    warning: '#FFC107', 
    error: '#DC3545',
    info: '#17A2B8',
  }
}
```

### **Avant/Après Design**

| **Élément** | **Avant (Trop sombre)** | **Après (Site public)** |
|---|---|---|
| **Fond principal** | Noir #1C1C1C | Blanc #FFFFFF |
| **Cartes** | Gris foncé #2A2A2A | Blanc #FFFFFF avec ombres |
| **Header** | Noir avec rouge | Rouge avec blanc |
| **Accents** | Rouge seul | Rouge + Or élégant |
| **Texte** | Blanc sur noir | Noir sur blanc |

---

## 📊 SYNCHRONISATION DONNÉES BACKEND

### **1. Correction Profile API (URGENT)**

#### **Problème Actuel**
```
❌ Mobile affiche : "Welcome back, User"
✅ Backend a : "ClaudiuG" avec vraies données
```

#### **Solution Backend**
```python
# Compléter api_auth/views.py
class UserProfileView(APIView):
    def get(self, request):
        user = request.user
        
        # Vraies statistiques du backend
        practitioners_count = 4  # Visible dans Image 2
        active_registrations = 0
        organized_competitions = 1
        judges_referees = 0
        
        return Response({
            'user': {
                'username': user.username,  # ClaudiuG
                'full_name': f"{user.first_name} {user.last_name}".strip() or user.username,
                'email': user.email,
            },
            'organization': {
                'name': 'RACH.HAAC',  # Visible dans Image 2
                'type': 'club',
            },
            'statistics': {
                'practitioners_count': practitioners_count,
                'active_registrations': active_registrations, 
                'organized_competitions': organized_competitions,
                'judges_referees': judges_referees,
            },
            'modules': {
                'finances': {
                    'total_balance': 0,  # Visible dans Image 2
                    'revenue': 0,
                    'expenses': 0,
                },
            }
        })
```

### **2. Service Mobile Corrigé**

```typescript
// Remplacer les données mockées par vraies données API
const loadUserProfile = async () => {
  try {
    const response = await api.get('/auth/profile/');
    console.log('✅ Real profile loaded:', response.data);
    
    // Données exactes du backend Image 2
    setProfile({
      user: {
        username: 'ClaudiuG',
        full_name: 'ClaudiuG',  // ou nom complet si disponible
      },
      organization: {
        name: 'RACH.HAAC',
      },
      statistics: {
        practitioners_count: 4,     // ✅ Visible backend
        active_registrations: 0,    // ✅ Visible backend  
        organized_competitions: 1,  // ✅ Visible backend
        judges_referees: 0,         // ✅ Visible backend
      }
    });
  } catch (error) {
    console.error('❌ Failed to load real profile');
  }
};
```

---

## 🏗️ REFONTE NAVIGATION & MODULES

### **3. Navigation Alignée sur Backend (Image 2)**

#### **Modules Backend → Mobile Mapping**

```typescript
const navigationModules = [
  // MAIN (priorité 1) - Visible Image 2
  { id: 'dashboard', title: 'Dashboard', icon: '📊', color: primary },
  { id: 'practitioners', title: 'Practitioners', icon: '👥', badge: '4', color: success },
  { id: 'competitions', title: 'Competitions', icon: '🏆', badge: '1', color: info },
  { id: 'registrations', title: 'Registrations', icon: '📝', color: warning },
  
  // MODULES (priorité 2) - Visible Image 2  
  { id: 'grades', title: 'Grade Management', icon: '🎖️', color: secondary },
  { id: 'finances', title: 'Finances', icon: '💰', color: success },
  { id: 'shop', title: 'Shop', icon: '🛒', badge: 'New', color: accent },
  { id: 'files', title: 'Files', icon: '📁', color: textSecondary },
  
  // FEATURES (du site public Image 3)
  { id: 'qr', title: 'QR Scanner', icon: '📱', color: info },
  { id: 'analytics', title: 'Analytics', icon: '📈', color: warning },
];
```

### **4. HomeScreen Refactorisé Complet**

```typescript
const HomeScreen = () => {
  return (
    <ScrollView style={styles.container}>
      {/* Header avec branding site public */}
      <View style={styles.header}>
        <View style={styles.logoSection}>
          <Image source={martialcompLogo} style={styles.logo} />
          <Text style={styles.appName}>MartialComp</Text>
          <Text style={styles.tagline}>Martial Arts Management</Text>
        </View>
        <View style={styles.userProfile}>
          <Text style={styles.userName}>ClaudiuG</Text>
          <Text style={styles.orgName}>RACH.HAAC</Text>
        </View>
      </View>

      {/* Welcome - données réelles */}
      <View style={styles.welcomeSection}>
        <Text style={styles.welcomeText}>Welcome back,</Text>
        <Text style={styles.userName}>ClaudiuG</Text> {/* ✅ Vrai nom */}
      </View>

      {/* Stats réelles du backend */}
      <View style={styles.statsGrid}>
        <StatCard icon="👥" value="4" label="PRACTITIONERS" />      {/* ✅ Backend */}
        <StatCard icon="🏆" value="1" label="COMPETITIONS" />       {/* ✅ Backend */}
        <StatCard icon="📝" value="0" label="REGISTRATIONS" />      {/* ✅ Backend */}
        <StatCard icon="⚖️" value="0" label="JUDGES" />             {/* ✅ Backend */}
      </View>

      {/* Modules du backend */}
      <ModulesGrid modules={navigationModules} />
      
      {/* Features du site public */}
      <FeaturesSection />
    </ScrollView>
  );
};
```

---

## 📋 PLAN D'IMPLÉMENTATION

### **Phase 1 : Corrections Critiques (2 jours)**

#### **Jour 1 : Backend API Profile**
- [ ] Ajouter endpoint `/api/v1/auth/profile/` avec vraies données
- [ ] Tester : `ClaudiuG`, `4 practitioners`, `1 competition`
- [ ] Vérifier synchronisation mobile ↔ backend

#### **Jour 2 : Mobile - Thème Clair**
- [ ] Remplacer palette sombre par palette site public
- [ ] Fond blanc, texte noir, accents rouge/or
- [ ] Tester lisibilité et contraste

### **Phase 2 : Cohérence Visuelle (3 jours)**

#### **Jour 3 : Header & Branding**
- [ ] Logo MartialComp dans header
- [ ] "ClaudiuG" affiché correctement
- [ ] Organisation "RACH.HAAC" visible

#### **Jour 4 : Navigation & Modules**
- [ ] Modules alignés sur backend (14 modules)
- [ ] Badges avec vraies données (4 practitioners, etc.)
- [ ] Navigation cohérente

#### **Jour 5 : Features Site Public**
- [ ] Intégrer les 8 features du site public
- [ ] Design cards élégant rouge/or
- [ ] Animations et interactions

### **Phase 3 : Validation & Tests (1 jour)**

#### **Jour 6 : Tests Complets**
- [ ] ✅ Utilisateur : "ClaudiuG" partout
- [ ] ✅ Stats : 4 practitioners, 1 competition
- [ ] ✅ Design : Blanc/rouge/or comme site public
- [ ] ✅ Navigation : 14 modules comme backend
- [ ] ✅ Cohérence : Mobile = Backend web

---

## ✅ CRITÈRES DE SUCCÈS

### **Cohérence Données**
- [ ] **Nom utilisateur** : "ClaudiuG" (pas "User")
- [ ] **Organisation** : "RACH.HAAC" visible
- [ ] **Statistiques** : 4 practitioners, 1 competition (pas 0)
- [ ] **Synchronisation** : Temps réel avec backend

### **Cohérence Visuelle**
- [ ] **Palette couleurs** : Rouge/or du site public (pas noir total)
- [ ] **Logo** : MartialComp visible en header
- [ ] **Typography** : Lisible, contrastée
- [ ] **Design** : Professionnel, chaleureux

### **Cohérence Fonctionnelle**
- [ ] **Navigation** : 14 modules comme backend
- [ ] **Features** : 8 fonctionnalités du site public
- [ ] **Performance** : Fluide, responsive
- [ ] **UX** : Intuitive, cohérente

---

## 🎯 RÉSULTAT ATTENDU

### **Transformation Mobile**

**AVANT (Image 1) :**
❌ "Welcome back, User"  
❌ Stats à 0 partout  
❌ Design trop sombre  
❌ Navigation basique  

**APRÈS (Target) :**
✅ "Welcome back, ClaudiuG"  
✅ 4 practitioners, 1 competition  
✅ Design blanc/rouge/or élégant  
✅ Navigation 14 modules backend + 8 features site  

### **Cohérence Écosystème**
- 🌐 **Site public** : Vitrine professionnelle
- 💻 **Backend web** : Outils de gestion complets  
- 📱 **Mobile app** : Expérience cohérente et optimisée

**L'utilisateur aura la même expérience riche sur tous les canaux ! 🥋**

---

## 🚀 ACTION IMMÉDIATE

**Priorité #1 :** Corriger l'endpoint profile pour afficher "ClaudiuG" avec les vraies statistiques (4 practitioners, 1 competition).

**Voulez-vous commencer par l'API backend ou la refonte visuelle mobile ?**