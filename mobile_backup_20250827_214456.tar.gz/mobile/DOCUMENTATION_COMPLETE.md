# 📱 MartialComp Mobile - Documentation Complète

## 📋 Table des Matières

1. [Vue d'ensemble](#vue-densemble)
2. [Architecture Technique](#architecture-technique)
3. [Fonctionnalités](#fonctionnalités)
4. [Onboarding](#onboarding)
5. [API et Services](#api-et-services)
6. [Interface Utilisateur](#interface-utilisateur)
7. [Sécurité et Authentification](#sécurité-et-authentification)
8. [Déploiement](#déploiement)
9. [Maintenance](#maintenance)

---

## 🎯 Vue d'ensemble

### Description

MartialComp Mobile est l'application mobile officielle de la plateforme MartialComp, conçue pour offrir une expérience complète de gestion d'arts martiaux sur mobile. L'application permet aux utilisateurs d'accéder à toutes les fonctionnalités de la plateforme web de manière optimisée pour les appareils mobiles.

### Objectifs

- **Accessibilité** : Accès mobile aux fonctionnalités MartialComp
- **Synchronisation** : Données cohérentes entre mobile et web
- **Performance** : Optimisation pour les appareils mobiles
- **Expérience utilisateur** : Interface intuitive et responsive

### Public Cible

- **Clubs d'arts martiaux** : Gestion des membres et compétitions
- **Fédérations** : Administration et coordination
- **Pratiquants** : Accès aux profils et inscriptions
- **Organisateurs** : Gestion d'événements et compétitions

---

## 🏗️ Architecture Technique

### Stack Technologique

#### **Frontend**

- **React Native** : Framework principal
- **Expo** : Outils de développement et déploiement
- **TypeScript** : Typage statique
- **React Navigation v6** : Navigation entre écrans

#### **State Management**

- **Redux Toolkit** : Gestion d'état globale
- **React Redux** : Intégration React-Redux
- **Redux Persist** : Persistance des données

#### **API et Communication**

- **Axios** : Client HTTP
- **JWT** : Authentification
- **WebSocket** : Communication temps réel (optionnel)

#### **UI/UX**

- **React Native Vector Icons** : Icônes
- **React Native Reanimated** : Animations
- **React Native Gesture Handler** : Gestes
- **Expo Camera** : Accès caméra
- **Expo Barcode Scanner** : Scanner QR codes

#### **Stockage**

- **AsyncStorage** : Stockage local
- **Expo SecureStore** : Données sensibles
- **SQLite** : Base de données locale (optionnel)

### Architecture des Dossiers

```
mobile/
├── src/
│   ├── components/           # Composants réutilisables
│   │   ├── common/          # Composants génériques
│   │   ├── forms/           # Composants de formulaires
│   │   └── ui/              # Composants UI
│   ├── screens/             # Écrans de l'application
│   │   ├── auth/            # Écrans d'authentification
│   │   ├── main/            # Écrans principaux
│   │   └── onboarding/      # Écrans d'onboarding
│   ├── services/            # Services API
│   │   ├── organizationService.ts
│   │   ├── financeService.ts
│   │   ├── competitionService.ts
│   │   └── qrScannerService.ts
│   ├── store/               # Redux store
│   │   ├── slices/          # Redux slices
│   │   ├── middleware/      # Middleware personnalisé
│   │   └── index.ts         # Configuration store
│   ├── types/               # Types TypeScript
│   │   ├── organization.ts
│   │   ├── competition.ts
│   │   └── finance.ts
│   ├── utils/               # Utilitaires
│   │   ├── validation.ts
│   │   ├── formatting.ts
│   │   └── constants.ts
│   ├── theme/               # Thèmes et styles
│   │   ├── colors.ts
│   │   ├── typography.ts
│   │   └── spacing.ts
│   ├── navigation/          # Configuration navigation
│   │   ├── RootNavigator.tsx
│   │   ├── MainNavigator.tsx
│   │   └── AuthNavigator.tsx
│   ├── i18n/               # Internationalisation
│   │   ├── locales/
│   │   ├── config.ts
│   │   └── index.ts
│   └── config/             # Configuration
│       ├── api.ts
│       ├── constants.ts
│       └── environment.ts
├── assets/                 # Ressources statiques
│   ├── images/
│   ├── icons/
│   └── fonts/
├── docs/                   # Documentation
└── tests/                  # Tests
    ├── unit/
    ├── integration/
    └── e2e/
```

### Flux de Données

```
┌─────────────────┐    ┌─────────────────┐    ┌─────────────────┐
│   UI Components │    │   Redux Store   │    │   API Services  │
│                 │◄──►│                 │◄──►│                 │
│  - Screens      │    │  - State        │    │  - Axios        │
│  - Components   │    │  - Actions      │    │  - JWT          │
│  - Navigation   │    │  - Reducers     │    │  - WebSocket    │
└─────────────────┘    └─────────────────┘    └─────────────────┘
         │                       │                       │
         ▼                       ▼                       ▼
┌─────────────────┐    ┌─────────────────┐    ┌─────────────────┐
│   Local Storage │    │   Middleware    │    │   Backend API   │
│                 │    │                 │    │                 │
│  - AsyncStorage │    │  - Persist      │    │  - Django       │
│  - SecureStore  │    │  - Logger       │    │  - PostgreSQL   │
│  - SQLite       │    │  - Analytics    │    │  - Redis        │
└─────────────────┘    └─────────────────┘    └─────────────────┘
```

---

## ⚡ Fonctionnalités

### 🔐 Authentification et Sécurité

#### **Système d'Authentification**

- **JWT Tokens** : Authentification sécurisée
- **Refresh Tokens** : Renouvellement automatique
- **Biométrie** : Authentification par empreinte/face
- **Multi-appareils** : Gestion des sessions multiples

#### **Sécurité**

- **Chiffrement** : Données sensibles chiffrées
- **Validation** : Vérification côté client et serveur
- **Permissions** : Gestion fine des accès
- **Audit** : Logs de sécurité

### 📱 Scanner QR Code

#### **Types de QR Codes Supportés**

1. **Inscription** (`register`) : Inscription à une organisation
2. **Paiement** (`payment`) : Paiement direct
3. **Parrainage** (`referral`) : Système de parrainage
4. **Accueil** (`home`) : Page d'accueil organisation
5. **Check-in** (`check-in`) : Pointage des membres

#### **Fonctionnalités Avancées**

- **Détection automatique** du type de QR code
- **Validation en temps réel** des données
- **Historique des scans** avec statistiques
- **Mode hors-ligne** pour validation locale
- **Navigation contextuelle** selon le type

### 🏢 Gestion des Organisations

#### **Types d'Organisations**

- **Clubs** : Clubs d'arts martiaux
- **Fédérations** : Fédérations nationales/internationales
- **Académies** : Centres de formation
- **Organisations régionales** : Structures locales

#### **Fonctionnalités par Organisation**

- **Profil complet** : Informations détaillées
- **Disciplines** : Arts martiaux pratiqués
- **Membres** : Liste des adhérents
- **Statistiques** : Métriques d'activité
- **Sites web** : Intégration avec sites d'organisations

#### **Gestion des Membres**

- **Rôles** : Propriétaire, Admin, Membre, Coach, Pratiquant
- **Permissions** : Gestion fine des accès
- **Affiliations** : Relations entre organisations
- **Historique** : Suivi des adhésions

### 💰 Gestion Financière

#### **Portefeuilles d'Organisations**

- **Solde en temps réel** : Affichage du solde
- **Transactions** : Historique des mouvements
- **Devises** : Support multi-devises
- **Statuts** : Actif/Inactif

#### **Paiements**

- **Méthodes multiples** : Cartes, virements, etc.
- **Statuts** : En attente, complété, échoué, annulé
- **Notifications** : Alertes de paiement
- **Rapports** : Export des données

#### **Abonnements**

- **Plans** : Essentials, Masters, Champion
- **Statuts** : Essai, actif, expiré, annulé
- **Renouvellement** : Automatique ou manuel
- **Upgrade/Downgrade** : Changement de plan

### 🏆 Compétitions

#### **Gestion des Compétitions**

- **Création** : Interface de création
- **Configuration** : Catégories, règles, dates
- **Inscriptions** : Gestion des participants
- **Résultats** : Saisie et affichage

#### **Catégories de Compétition**

- **Âge** : Tranches d'âge
- **Poids** : Catégories de poids
- **Grade** : Niveaux techniques
- **Genre** : Masculin, féminin, mixte

#### **Fonctionnalités Avancées**

- **Inscriptions en ligne** : Via l'application
- **Validation automatique** : Vérification des critères
- **Résultats en temps réel** : Affichage live
- **Certificats** : Génération automatique

### 👥 Profils et Gestion des Pratiquants

#### **Profils Complets**

- **Informations personnelles** : Nom, prénom, date de naissance
- **Contact** : Email, téléphone, adresse
- **Grades** : Progression technique
- **Disciplines** : Arts martiaux pratiqués
- **Historique** : Compétitions, formations

#### **Gestion Hors-ligne**

- **Stockage local** : Profils accessibles hors-ligne
- **Synchronisation** : Mise à jour automatique
- **Validation** : Vérification des données
- **Conflits** : Résolution des conflits

### 🔔 Notifications et Communication

#### **Types de Notifications**

- **Système** : Alertes système
- **Compétitions** : Rappels d'inscription
- **Paiements** : Confirmations de paiement
- **Organisations** : Nouvelles de l'organisation

#### **Préférences**

- **Personnalisation** : Types de notifications
- **Fréquence** : Immédiat, quotidien, hebdomadaire
- **Canaux** : Push, email, SMS

---

## 🚀 Onboarding

### Objectifs de l'Onboarding

#### **Objectifs Principaux**

1. **Familiarisation** : Présentation des fonctionnalités
2. **Configuration** : Paramétrage initial
3. **Adoption** : Encouragement à l'utilisation
4. **Rétention** : Engagement à long terme

#### **Métriques de Succès**

- **Taux de completion** : % d'utilisateurs terminant l'onboarding
- **Temps d'onboarding** : Durée moyenne
- **Taux d'activation** : % d'utilisateurs actifs après onboarding
- **Satisfaction** : Score de satisfaction utilisateur

### Étapes de l'Onboarding

#### **Étape 1 : Bienvenue**

```typescript
// Écran de bienvenue
interface WelcomeScreen {
  title: string;
  subtitle: string;
  features: string[];
  cta: string;
}
```

**Contenu :**

- Titre : "Bienvenue sur MartialComp Mobile"
- Sous-titre : "Votre plateforme complète de gestion d'arts martiaux"
- Fonctionnalités clés :
  - Scanner QR codes pour inscriptions rapides
  - Gestion complète des organisations
  - Suivi des compétitions en temps réel
  - Portefeuille et paiements intégrés

#### **Étape 2 : Authentification**

```typescript
// Options d'authentification
interface AuthOptions {
  email: string;
  password: string;
  biometric: boolean;
  remember: boolean;
}
```

**Options :**

- **Connexion existante** : Email/mot de passe
- **Nouveau compte** : Création de compte
- **Biométrie** : Authentification par empreinte/face
- **Récupération** : Mot de passe oublié

#### **Étape 3 : Sélection d'Organisation**

```typescript
// Types d'organisations
interface OrganizationType {
  type: "club" | "federation" | "academy" | "individual";
  name: string;
  description: string;
  icon: string;
}
```

**Options :**

- **Club** : Gestion de club d'arts martiaux
- **Fédération** : Administration de fédération
- **Académie** : Centre de formation
- **Individuel** : Utilisateur personnel

#### **Étape 4 : Configuration du Profil**

```typescript
// Informations du profil
interface ProfileSetup {
  firstName: string;
  lastName: string;
  email: string;
  phone?: string;
  dateOfBirth?: string;
  disciplines: string[];
  currentGrade?: string;
}
```

**Champs :**

- **Informations personnelles** : Nom, prénom, email
- **Contact** : Téléphone (optionnel)
- **Disciplines** : Arts martiaux pratiqués
- **Grade actuel** : Niveau technique

#### **Étape 5 : Permissions**

```typescript
// Permissions requises
interface Permissions {
  camera: boolean; // Scanner QR codes
  notifications: boolean; // Notifications push
  location: boolean; // Localisation (optionnel)
  biometrics: boolean; // Authentification biométrique
}
```

**Explications :**

- **Caméra** : "Nécessaire pour scanner les QR codes"
- **Notifications** : "Recevez les alertes importantes"
- **Localisation** : "Trouvez les clubs près de chez vous"
- **Biométrie** : "Connexion rapide et sécurisée"

#### **Étape 6 : Tutoriel Interactif**

```typescript
// Étapes du tutoriel
interface TutorialStep {
  id: string;
  title: string;
  description: string;
  action: string;
  screen: string;
}
```

**Étapes :**

1. **Scanner QR Code** : "Scannez un QR code pour vous inscrire"
2. **Navigation** : "Explorez les différentes sections"
3. **Profil** : "Personnalisez votre profil"
4. **Organisations** : "Découvrez les organisations"

#### **Étape 7 : Configuration Financière**

```typescript
// Configuration financière
interface FinancialSetup {
  currency: string;
  paymentMethods: string[];
  autoRenew: boolean;
  notifications: boolean;
}
```

**Options :**

- **Devise** : EUR, USD, etc.
- **Méthodes de paiement** : Cartes, virements
- **Renouvellement automatique** : Oui/Non
- **Notifications de paiement** : Oui/Non

#### **Étape 8 : Finalisation**

```typescript
// Écran de finalisation
interface CompletionScreen {
  message: string;
  nextSteps: string[];
  support: string;
}
```

**Contenu :**

- **Message de félicitations** : "Votre compte est prêt !"
- **Prochaines étapes** :
  - "Scannez votre premier QR code"
  - "Rejoignez une organisation"
  - "Explorez les compétitions"
- **Support** : "Besoin d'aide ? Contactez-nous"

### Interface Utilisateur de l'Onboarding

#### **Design Principles**

- **Simplicité** : Interface claire et intuitive
- **Progression** : Indicateur de progression visible
- **Flexibilité** : Possibilité de passer des étapes
- **Accessibilité** : Support des lecteurs d'écran

#### **Composants UI**

```typescript
// Composants d'onboarding
interface OnboardingComponents {
  ProgressBar: React.FC<{ current: number; total: number }>;
  StepIndicator: React.FC<{ steps: string[]; current: number }>;
  FeatureCard: React.FC<{ title: string; description: string; icon: string }>;
  PermissionRequest: React.FC<{ permission: string; description: string }>;
}
```

#### **Animations et Transitions**

- **Transitions fluides** entre les étapes
- **Animations d'entrée** pour les éléments
- **Feedback visuel** pour les interactions
- **Chargement progressif** des données

### Personnalisation de l'Onboarding

#### **Segmentation Utilisateurs**

```typescript
// Types d'utilisateurs
interface UserSegments {
  newUser: boolean;
  returningUser: boolean;
  organizationAdmin: boolean;
  individualUser: boolean;
}
```

#### **Adaptation du Contenu**

- **Nouveaux utilisateurs** : Onboarding complet
- **Utilisateurs existants** : Onboarding raccourci
- **Admins d'organisation** : Focus sur la gestion
- **Utilisateurs individuels** : Focus sur le profil

#### **A/B Testing**

- **Variantes d'onboarding** : Test de différentes approches
- **Métriques** : Suivi des performances
- **Optimisation** : Amélioration continue

### Intégration avec l'API

#### **Endpoints d'Onboarding**

```typescript
// API endpoints
const ONBOARDING_ENDPOINTS = {
  START: "/onboarding/start/",
  PROGRESS: "/onboarding/progress/",
  COMPLETE: "/onboarding/complete/",
  SKIP: "/onboarding/skip/",
  RESET: "/onboarding/reset/",
};
```

#### **Données d'Onboarding**

```typescript
// Structure des données
interface OnboardingData {
  userId: string;
  currentStep: number;
  completedSteps: number[];
  skippedSteps: number[];
  preferences: OnboardingPreferences;
  startDate: string;
  completionDate?: string;
}
```

---

## 🔌 API et Services

### Architecture API

#### **Base URL**

```typescript
const API_CONFIG = {
  PRODUCTION: "https://martialcomp.com/api/v1",
  STAGING: "https://staging.martialcomp.com/api/v1",
  DEVELOPMENT: "http://localhost:8000/api/v1",
};
```

#### **Authentification**

```typescript
// Headers d'authentification
const AUTH_HEADERS = {
  Authorization: `Bearer ${accessToken}`,
  "Content-Type": "application/json",
  Accept: "application/json",
};
```

### Services Principaux

#### **OrganizationService**

```typescript
class OrganizationService {
  // Récupération des organisations
  static async getOrganizations(): Promise<Organization[]>;

  // Détails d'une organisation
  static async getOrganization(id: string): Promise<Organization>;

  // Site web de l'organisation
  static async getOrganizationSite(id: string): Promise<OrganizationSite>;

  // QR codes de l'organisation
  static async getOrganizationQRCodes(
    id: string
  ): Promise<OrganizationQRCode[]>;

  // Inscription à une organisation
  static async registerWithOrganization(
    organizationId: string,
    data: OrganizationRegistrationData
  ): Promise<any>;

  // Membres de l'organisation
  static async getOrganizationMembers(
    id: string
  ): Promise<OrganizationMember[]>;

  // Statistiques de l'organisation
  static async getOrganizationStats(id: string): Promise<OrganizationStats>;
}
```

#### **FinanceService**

```typescript
class FinanceService {
  // Portefeuille de l'organisation
  static async getWallet(organizationId: string): Promise<Wallet>;

  // Transactions du portefeuille
  static async getTransactions(walletId: string): Promise<Transaction[]>;

  // Tentatives de paiement
  static async getPaymentAttempts(
    organizationId: string
  ): Promise<PaymentAttempt[]>;

  // Création d'une tentative de paiement
  static async createPaymentAttempt(
    organizationId: string,
    amount: number,
    currency: string,
    paymentMethod: string,
    description: string
  ): Promise<PaymentAttempt>;

  // Abonnement actuel
  static async getCurrentSubscription(organizationId: string): Promise<any>;

  // Upgrade d'abonnement
  static async upgradeSubscription(
    organizationId: string,
    planCode: string
  ): Promise<any>;
}
```

#### **CompetitionService**

```typescript
class CompetitionService {
  // Liste des compétitions
  static async getCompetitions(
    filters?: CompetitionFilters
  ): Promise<Competition[]>;

  // Détails d'une compétition
  static async getCompetition(id: string): Promise<Competition>;

  // Inscription à une compétition
  static async registerForCompetition(
    competitionId: string,
    practitionerId: string,
    categories: string[]
  ): Promise<CompetitionRegistration>;

  // Inscriptions à une compétition
  static async getCompetitionRegistrations(
    competitionId: string
  ): Promise<CompetitionRegistration[]>;

  // Résultats d'une compétition
  static async getCompetitionResults(
    competitionId: string
  ): Promise<CompetitionResult[]>;

  // Soumission d'un résultat
  static async submitCompetitionResult(
    competitionId: string,
    categoryId: string,
    practitionerId: string,
    rank?: number,
    score?: number,
    notes?: string
  ): Promise<CompetitionResult>;
}
```

### Gestion des Erreurs

#### **Types d'Erreurs**

```typescript
enum ErrorType {
  NETWORK = "network",
  AUTHENTICATION = "authentication",
  AUTHORIZATION = "authorization",
  VALIDATION = "validation",
  SERVER = "server",
  UNKNOWN = "unknown",
}
```

#### **Gestion des Erreurs**

```typescript
class ErrorHandler {
  // Traitement des erreurs API
  static handleApiError(error: any): void;

  // Affichage des messages d'erreur
  static showErrorMessage(message: string): void;

  // Retry automatique
  static retryRequest(request: () => Promise<any>): Promise<any>;

  // Log des erreurs
  static logError(error: any, context?: string): void;
}
```

---

## 🎨 Interface Utilisateur

### Design System

#### **Couleurs**

```typescript
const COLORS = {
  // Couleurs principales
  primary: "#007AFF",
  secondary: "#5856D6",
  success: "#34C759",
  warning: "#FF9500",
  error: "#FF3B30",

  // Couleurs neutres
  background: "#F2F2F7",
  surface: "#FFFFFF",
  text: "#000000",
  textSecondary: "#8E8E93",
  border: "#C6C6C8",

  // Couleurs spécifiques
  martialArts: "#D70015", // Rouge arts martiaux
  competition: "#FF6B35", // Orange compétition
  finance: "#34C759", // Vert finance
};
```

#### **Typographie**

```typescript
const TYPOGRAPHY = {
  // Tailles de police
  h1: { fontSize: 32, fontWeight: "bold" },
  h2: { fontSize: 24, fontWeight: "bold" },
  h3: { fontSize: 20, fontWeight: "600" },
  body: { fontSize: 16, fontWeight: "normal" },
  caption: { fontSize: 14, fontWeight: "normal" },
  small: { fontSize: 12, fontWeight: "normal" },

  // Espacement
  lineHeight: {
    h1: 40,
    h2: 32,
    h3: 28,
    body: 24,
    caption: 20,
    small: 16,
  },
};
```

#### **Espacement**

```typescript
const SPACING = {
  xs: 4,
  sm: 8,
  md: 16,
  lg: 24,
  xl: 32,
  xxl: 48,
};
```

### Composants Réutilisables

#### **Boutons**

```typescript
interface ButtonProps {
  title: string;
  onPress: () => void;
  variant?: "primary" | "secondary" | "outline" | "ghost";
  size?: "small" | "medium" | "large";
  disabled?: boolean;
  loading?: boolean;
  icon?: string;
}
```

#### **Cartes**

```typescript
interface CardProps {
  title?: string;
  subtitle?: string;
  children: React.ReactNode;
  onPress?: () => void;
  variant?: "default" | "elevated" | "outlined";
  padding?: keyof typeof SPACING;
}
```

#### **Formulaires**

```typescript
interface FormFieldProps {
  label: string;
  value: string;
  onChangeText: (text: string) => void;
  placeholder?: string;
  error?: string;
  required?: boolean;
  type?: "text" | "email" | "password" | "phone";
  icon?: string;
}
```

### Navigation

#### **Structure de Navigation**

```typescript
// Navigation principale
const MainNavigator = {
  Home: "HomeScreen",
  QRScanner: "QRScannerScreen",
  Organizations: "OrganizationsScreen",
  Competitions: "CompetitionsScreen",
  Profile: "ProfileScreen",
  Settings: "SettingsScreen",
};

// Navigation d'authentification
const AuthNavigator = {
  Login: "LoginScreen",
  Register: "RegisterScreen",
  ForgotPassword: "ForgotPasswordScreen",
  Onboarding: "OnboardingScreen",
};
```

#### **Types de Navigation**

```typescript
type RootStackParamList = {
  Auth: undefined;
  Main: undefined;
  Onboarding: undefined;
};

type MainTabParamList = {
  Home: undefined;
  QRScanner: { qrData?: string };
  Organizations: { organizationId?: string };
  Competitions: { competitionId?: string };
  Profile: undefined;
};
```

### Responsive Design

#### **Breakpoints**

```typescript
const BREAKPOINTS = {
  phone: 320,
  tablet: 768,
  desktop: 1024,
};
```

#### **Adaptation d'Écran**

```typescript
const useResponsive = () => {
  const { width } = useWindowDimensions();

  return {
    isPhone: width < BREAKPOINTS.tablet,
    isTablet: width >= BREAKPOINTS.tablet && width < BREAKPOINTS.desktop,
    isDesktop: width >= BREAKPOINTS.desktop,
  };
};
```

---

## 🔐 Sécurité et Authentification

### Système d'Authentification

#### **JWT Tokens**

```typescript
interface AuthTokens {
  accessToken: string;
  refreshToken: string;
  expiresIn: number;
  tokenType: "Bearer";
}
```

#### **Gestion des Tokens**

```typescript
class TokenManager {
  // Stockage sécurisé des tokens
  static async storeTokens(tokens: AuthTokens): Promise<void>;

  // Récupération des tokens
  static async getTokens(): Promise<AuthTokens | null>;

  // Suppression des tokens
  static async clearTokens(): Promise<void>;

  // Vérification de validité
  static isTokenValid(token: string): boolean;

  // Refresh automatique
  static async refreshTokens(): Promise<AuthTokens>;
}
```

### Chiffrement et Sécurité

#### **Chiffrement des Données**

```typescript
class EncryptionService {
  // Chiffrement des données sensibles
  static async encrypt(data: string): Promise<string>;

  // Déchiffrement des données
  static async decrypt(encryptedData: string): Promise<string>;

  // Génération de clés
  static generateKey(): string;
}
```

#### **Validation des Données**

```typescript
class ValidationService {
  // Validation des entrées utilisateur
  static validateEmail(email: string): boolean;
  static validatePassword(password: string): boolean;
  static validatePhone(phone: string): boolean;

  // Sanitisation des données
  static sanitizeInput(input: string): string;
}
```

### Permissions et Autorisations

#### **Gestion des Permissions**

```typescript
interface Permission {
  name: string;
  description: string;
  required: boolean;
  granted: boolean;
}

const PERMISSIONS = {
  CAMERA: {
    name: "camera",
    description: "Accès à la caméra pour scanner les QR codes",
    required: true,
  },
  NOTIFICATIONS: {
    name: "notifications",
    description: "Notifications push pour les alertes importantes",
    required: false,
  },
  BIOMETRICS: {
    name: "biometrics",
    description: "Authentification par empreinte digitale ou Face ID",
    required: false,
  },
};
```

#### **Vérification des Permissions**

```typescript
class PermissionService {
  // Demande de permission
  static async requestPermission(permission: Permission): Promise<boolean>;

  // Vérification du statut
  static async checkPermission(permission: string): Promise<boolean>;

  // Ouverture des paramètres
  static openSettings(): void;
}
```

---

## 🚀 Déploiement

### Configuration Expo

#### **app.json**

```json
{
  "expo": {
    "name": "MartialComp Mobile",
    "slug": "martialcomp-mobile",
    "version": "0.2.0",
    "orientation": "portrait",
    "icon": "./assets/icon.png",
    "splash": {
      "image": "./assets/splash.png",
      "resizeMode": "contain",
      "backgroundColor": "#ffffff"
    },
    "updates": {
      "fallbackToCacheTimeout": 0
    },
    "assetBundlePatterns": ["**/*"],
    "ios": {
      "supportsTablet": true,
      "bundleIdentifier": "com.martialcomp.mobile"
    },
    "android": {
      "adaptiveIcon": {
        "foregroundImage": "./assets/adaptive-icon.png",
        "backgroundColor": "#FFFFFF"
      },
      "package": "com.martialcomp.mobile"
    },
    "web": {
      "favicon": "./assets/favicon.png"
    },
    "plugins": ["expo-camera", "expo-barcode-scanner", "expo-secure-store"]
  }
}
```

#### **eas.json**

```json
{
  "cli": {
    "version": ">= 3.0.0"
  },
  "build": {
    "development": {
      "developmentClient": true,
      "distribution": "internal"
    },
    "preview": {
      "distribution": "internal"
    },
    "production": {
      "autoIncrement": true
    }
  },
  "submit": {
    "production": {}
  }
}
```

### Build et Distribution

#### **Build pour Android**

```bash
# Configuration EAS
eas build:configure

# Build pour Android
eas build --platform android --profile production

# Build pour développement
eas build --platform android --profile development
```

#### **Build pour iOS**

```bash
# Build pour iOS
eas build --platform ios --profile production

# Build pour développement
eas build --platform ios --profile development
```

#### **Soumission aux Stores**

```bash
# Soumission Android
eas submit --platform android

# Soumission iOS
eas submit --platform ios
```

### Configuration d'Environnement

#### **Variables d'Environnement**

```typescript
// .env
API_URL=https://martialcomp.com/api/v1
EXPO_PUBLIC_API_URL=https://martialcomp.com/api/v1
SENTRY_DSN=https://your-sentry-dsn
ANALYTICS_KEY=your-analytics-key
```

#### **Configuration par Environnement**

```typescript
const ENV_CONFIG = {
  development: {
    apiUrl: "http://localhost:8000/api/v1",
    enableLogs: true,
    enableAnalytics: false,
  },
  staging: {
    apiUrl: "https://staging.martialcomp.com/api/v1",
    enableLogs: true,
    enableAnalytics: true,
  },
  production: {
    apiUrl: "https://martialcomp.com/api/v1",
    enableLogs: false,
    enableAnalytics: true,
  },
};
```

### Monitoring et Analytics

#### **Sentry pour le Monitoring**

```typescript
import * as Sentry from "@sentry/react-native";

Sentry.init({
  dsn: process.env.SENTRY_DSN,
  environment: __DEV__ ? "development" : "production",
  enableAutoSessionTracking: true,
  debug: __DEV__,
});
```

#### **Analytics**

```typescript
import analytics from "@react-native-firebase/analytics";

// Événements personnalisés
analytics.logEvent("qr_code_scanned", {
  qr_type: "organization_register",
  organization_id: "123",
});
```

---

## 🔧 Maintenance

### Tests

#### **Tests Unitaires**

```typescript
// Exemple de test unitaire
describe("OrganizationService", () => {
  it("should fetch organizations successfully", async () => {
    const organizations = await OrganizationService.getOrganizations();
    expect(organizations).toBeDefined();
    expect(Array.isArray(organizations)).toBe(true);
  });
});
```

#### **Tests d'Intégration**

```typescript
// Test d'intégration API
describe("API Integration", () => {
  it("should authenticate user and fetch profile", async () => {
    const authResult = await AuthService.login(email, password);
    expect(authResult.success).toBe(true);

    const profile = await ProfileService.getProfile();
    expect(profile).toBeDefined();
  });
});
```

#### **Tests E2E**

```typescript
// Test de parcours utilisateur
describe("User Journey", () => {
  it("should complete onboarding flow", async () => {
    await element(by.id("welcome-button")).tap();
    await element(by.id("auth-email")).typeText("test@example.com");
    await element(by.id("auth-password")).typeText("password123");
    await element(by.id("login-button")).tap();

    await expect(element(by.id("home-screen"))).toBeVisible();
  });
});
```

### Performance

#### **Optimisations**

```typescript
// Lazy loading des composants
const LazyComponent = React.lazy(() => import('./HeavyComponent'));

// Memoization
const MemoizedComponent = React.memo(ExpensiveComponent);

// Optimisation des images
const OptimizedImage = ({ uri, ...props }) => (
  <Image
    source={{ uri }}
    resizeMode="cover"
    fadeDuration={0}
    {...props}
  />
);
```

#### **Monitoring des Performances**

```typescript
import { Performance } from "@react-native-firebase/perf";

// Mesure des performances
const trace = Performance.startTrace("api_request");
try {
  await apiCall();
} finally {
  trace.stop();
}
```

### Mises à Jour

#### **Système de Mises à Jour**

```typescript
import * as Updates from "expo-updates";

class UpdateService {
  // Vérification des mises à jour
  static async checkForUpdates(): Promise<boolean> {
    const update = await Updates.checkForUpdateAsync();
    return update.isAvailable;
  }

  // Application des mises à jour
  static async applyUpdate(): Promise<void> {
    await Updates.fetchUpdateAsync();
    await Updates.reloadAsync();
  }
}
```

#### **Gestion des Versions**

```typescript
const VERSION_CONFIG = {
  current: "0.2.0",
  minimum: "0.1.0",
  latest: "0.2.0",
  forceUpdate: false,
};
```

### Support et Documentation

#### **Documentation Technique**

- **Architecture** : Documentation de l'architecture
- **API** : Documentation des endpoints
- **Composants** : Documentation des composants
- **Déploiement** : Guide de déploiement

#### **Support Utilisateur**

- **FAQ** : Questions fréquentes
- **Guides** : Guides d'utilisation
- **Contact** : Support technique
- **Feedback** : Système de feedback

---

## 📊 Métriques et KPIs

### Métriques Techniques

#### **Performance**

- **Temps de chargement** : < 3 secondes
- **Taux de crash** : < 1%
- **Utilisation mémoire** : < 100MB
- **Taille de l'app** : < 50MB

#### **Qualité**

- **Couverture de tests** : > 80%
- **Bugs critiques** : 0
- **Temps de résolution** : < 24h

### Métriques Business

#### **Adoption**

- **Téléchargements** : Objectif 10k/mois
- **Utilisateurs actifs** : Objectif 5k/mois
- **Rétention 30 jours** : Objectif 60%

#### **Engagement**

- **Temps d'utilisation** : Objectif 15min/session
- **Sessions par jour** : Objectif 2.5
- **Fonctionnalités utilisées** : Objectif 3/session

---

## 🎯 Conclusion

L'application mobile MartialComp offre une expérience complète et cohérente avec la plateforme web, permettant aux utilisateurs d'accéder à toutes les fonctionnalités de gestion d'arts martiaux depuis leur appareil mobile.

### Points Clés

- **Architecture robuste** basée sur React Native et Expo
- **Fonctionnalités complètes** couvrant tous les aspects de la plateforme
- **Onboarding optimisé** pour une adoption rapide
- **Sécurité renforcée** avec authentification JWT et chiffrement
- **Performance optimisée** pour les appareils mobiles
- **Maintenance facilitée** avec tests automatisés et monitoring

### Évolutions Futures

- **Notifications push** en temps réel
- **Mode hors-ligne complet**
- **Intégration de paiements mobiles**
- **Support des tablettes**
- **Réalité augmentée** pour les compétitions

L'application mobile MartialComp représente une solution complète et moderne pour la gestion d'arts martiaux sur mobile, offrant une expérience utilisateur exceptionnelle tout en maintenant la cohérence avec l'écosystème MartialComp.

## 📋 Table des Matières

1. [Vue d'ensemble](#vue-densemble)
2. [Architecture Technique](#architecture-technique)
3. [Fonctionnalités](#fonctionnalités)
4. [Onboarding](#onboarding)
5. [API et Services](#api-et-services)
6. [Interface Utilisateur](#interface-utilisateur)
7. [Sécurité et Authentification](#sécurité-et-authentification)
8. [Déploiement](#déploiement)
9. [Maintenance](#maintenance)

---

## 🎯 Vue d'ensemble

### Description

MartialComp Mobile est l'application mobile officielle de la plateforme MartialComp, conçue pour offrir une expérience complète de gestion d'arts martiaux sur mobile. L'application permet aux utilisateurs d'accéder à toutes les fonctionnalités de la plateforme web de manière optimisée pour les appareils mobiles.

### Objectifs

- **Accessibilité** : Accès mobile aux fonctionnalités MartialComp
- **Synchronisation** : Données cohérentes entre mobile et web
- **Performance** : Optimisation pour les appareils mobiles
- **Expérience utilisateur** : Interface intuitive et responsive

### Public Cible

- **Clubs d'arts martiaux** : Gestion des membres et compétitions
- **Fédérations** : Administration et coordination
- **Pratiquants** : Accès aux profils et inscriptions
- **Organisateurs** : Gestion d'événements et compétitions

---

## 🏗️ Architecture Technique

### Stack Technologique

#### **Frontend**

- **React Native** : Framework principal
- **Expo** : Outils de développement et déploiement
- **TypeScript** : Typage statique
- **React Navigation v6** : Navigation entre écrans

#### **State Management**

- **Redux Toolkit** : Gestion d'état globale
- **React Redux** : Intégration React-Redux
- **Redux Persist** : Persistance des données

#### **API et Communication**

- **Axios** : Client HTTP
- **JWT** : Authentification
- **WebSocket** : Communication temps réel (optionnel)

#### **UI/UX**

- **React Native Vector Icons** : Icônes
- **React Native Reanimated** : Animations
- **React Native Gesture Handler** : Gestes
- **Expo Camera** : Accès caméra
- **Expo Barcode Scanner** : Scanner QR codes

#### **Stockage**

- **AsyncStorage** : Stockage local
- **Expo SecureStore** : Données sensibles
- **SQLite** : Base de données locale (optionnel)

### Architecture des Dossiers

```
mobile/
├── src/
│   ├── components/           # Composants réutilisables
│   │   ├── common/          # Composants génériques
│   │   ├── forms/           # Composants de formulaires
│   │   └── ui/              # Composants UI
│   ├── screens/             # Écrans de l'application
│   │   ├── auth/            # Écrans d'authentification
│   │   ├── main/            # Écrans principaux
│   │   └── onboarding/      # Écrans d'onboarding
│   ├── services/            # Services API
│   │   ├── organizationService.ts
│   │   ├── financeService.ts
│   │   ├── competitionService.ts
│   │   └── qrScannerService.ts
│   ├── store/               # Redux store
│   │   ├── slices/          # Redux slices
│   │   ├── middleware/      # Middleware personnalisé
│   │   └── index.ts         # Configuration store
│   ├── types/               # Types TypeScript
│   │   ├── organization.ts
│   │   ├── competition.ts
│   │   └── finance.ts
│   ├── utils/               # Utilitaires
│   │   ├── validation.ts
│   │   ├── formatting.ts
│   │   └── constants.ts
│   ├── theme/               # Thèmes et styles
│   │   ├── colors.ts
│   │   ├── typography.ts
│   │   └── spacing.ts
│   ├── navigation/          # Configuration navigation
│   │   ├── RootNavigator.tsx
│   │   ├── MainNavigator.tsx
│   │   └── AuthNavigator.tsx
│   ├── i18n/               # Internationalisation
│   │   ├── locales/
│   │   ├── config.ts
│   │   └── index.ts
│   └── config/             # Configuration
│       ├── api.ts
│       ├── constants.ts
│       └── environment.ts
├── assets/                 # Ressources statiques
│   ├── images/
│   ├── icons/
│   └── fonts/
├── docs/                   # Documentation
└── tests/                  # Tests
    ├── unit/
    ├── integration/
    └── e2e/
```

### Flux de Données

```
┌─────────────────┐    ┌─────────────────┐    ┌─────────────────┐
│   UI Components │    │   Redux Store   │    │   API Services  │
│                 │◄──►│                 │◄──►│                 │
│  - Screens      │    │  - State        │    │  - Axios        │
│  - Components   │    │  - Actions      │    │  - JWT          │
│  - Navigation   │    │  - Reducers     │    │  - WebSocket    │
└─────────────────┘    └─────────────────┘    └─────────────────┘
         │                       │                       │
         ▼                       ▼                       ▼
┌─────────────────┐    ┌─────────────────┐    ┌─────────────────┐
│   Local Storage │    │   Middleware    │    │   Backend API   │
│                 │    │                 │    │                 │
│  - AsyncStorage │    │  - Persist      │    │  - Django       │
│  - SecureStore  │    │  - Logger       │    │  - PostgreSQL   │
│  - SQLite       │    │  - Analytics    │    │  - Redis        │
└─────────────────┘    └─────────────────┘    └─────────────────┘
```

---

## ⚡ Fonctionnalités

### 🔐 Authentification et Sécurité

#### **Système d'Authentification**

- **JWT Tokens** : Authentification sécurisée
- **Refresh Tokens** : Renouvellement automatique
- **Biométrie** : Authentification par empreinte/face
- **Multi-appareils** : Gestion des sessions multiples

#### **Sécurité**

- **Chiffrement** : Données sensibles chiffrées
- **Validation** : Vérification côté client et serveur
- **Permissions** : Gestion fine des accès
- **Audit** : Logs de sécurité

### 📱 Scanner QR Code

#### **Types de QR Codes Supportés**

1. **Inscription** (`register`) : Inscription à une organisation
2. **Paiement** (`payment`) : Paiement direct
3. **Parrainage** (`referral`) : Système de parrainage
4. **Accueil** (`home`) : Page d'accueil organisation
5. **Check-in** (`check-in`) : Pointage des membres

#### **Fonctionnalités Avancées**

- **Détection automatique** du type de QR code
- **Validation en temps réel** des données
- **Historique des scans** avec statistiques
- **Mode hors-ligne** pour validation locale
- **Navigation contextuelle** selon le type

### 🏢 Gestion des Organisations

#### **Types d'Organisations**

- **Clubs** : Clubs d'arts martiaux
- **Fédérations** : Fédérations nationales/internationales
- **Académies** : Centres de formation
- **Organisations régionales** : Structures locales

#### **Fonctionnalités par Organisation**

- **Profil complet** : Informations détaillées
- **Disciplines** : Arts martiaux pratiqués
- **Membres** : Liste des adhérents
- **Statistiques** : Métriques d'activité
- **Sites web** : Intégration avec sites d'organisations

#### **Gestion des Membres**

- **Rôles** : Propriétaire, Admin, Membre, Coach, Pratiquant
- **Permissions** : Gestion fine des accès
- **Affiliations** : Relations entre organisations
- **Historique** : Suivi des adhésions

### 💰 Gestion Financière

#### **Portefeuilles d'Organisations**

- **Solde en temps réel** : Affichage du solde
- **Transactions** : Historique des mouvements
- **Devises** : Support multi-devises
- **Statuts** : Actif/Inactif

#### **Paiements**

- **Méthodes multiples** : Cartes, virements, etc.
- **Statuts** : En attente, complété, échoué, annulé
- **Notifications** : Alertes de paiement
- **Rapports** : Export des données

#### **Abonnements**

- **Plans** : Essentials, Masters, Champion
- **Statuts** : Essai, actif, expiré, annulé
- **Renouvellement** : Automatique ou manuel
- **Upgrade/Downgrade** : Changement de plan

### 🏆 Compétitions

#### **Gestion des Compétitions**

- **Création** : Interface de création
- **Configuration** : Catégories, règles, dates
- **Inscriptions** : Gestion des participants
- **Résultats** : Saisie et affichage

#### **Catégories de Compétition**

- **Âge** : Tranches d'âge
- **Poids** : Catégories de poids
- **Grade** : Niveaux techniques
- **Genre** : Masculin, féminin, mixte

#### **Fonctionnalités Avancées**

- **Inscriptions en ligne** : Via l'application
- **Validation automatique** : Vérification des critères
- **Résultats en temps réel** : Affichage live
- **Certificats** : Génération automatique

### 👥 Profils et Gestion des Pratiquants

#### **Profils Complets**

- **Informations personnelles** : Nom, prénom, date de naissance
- **Contact** : Email, téléphone, adresse
- **Grades** : Progression technique
- **Disciplines** : Arts martiaux pratiqués
- **Historique** : Compétitions, formations

#### **Gestion Hors-ligne**

- **Stockage local** : Profils accessibles hors-ligne
- **Synchronisation** : Mise à jour automatique
- **Validation** : Vérification des données
- **Conflits** : Résolution des conflits

### 🔔 Notifications et Communication

#### **Types de Notifications**

- **Système** : Alertes système
- **Compétitions** : Rappels d'inscription
- **Paiements** : Confirmations de paiement
- **Organisations** : Nouvelles de l'organisation

#### **Préférences**

- **Personnalisation** : Types de notifications
- **Fréquence** : Immédiat, quotidien, hebdomadaire
- **Canaux** : Push, email, SMS

---

## 🚀 Onboarding

### Objectifs de l'Onboarding

#### **Objectifs Principaux**

1. **Familiarisation** : Présentation des fonctionnalités
2. **Configuration** : Paramétrage initial
3. **Adoption** : Encouragement à l'utilisation
4. **Rétention** : Engagement à long terme

#### **Métriques de Succès**

- **Taux de completion** : % d'utilisateurs terminant l'onboarding
- **Temps d'onboarding** : Durée moyenne
- **Taux d'activation** : % d'utilisateurs actifs après onboarding
- **Satisfaction** : Score de satisfaction utilisateur

### Étapes de l'Onboarding

#### **Étape 1 : Bienvenue**

```typescript
// Écran de bienvenue
interface WelcomeScreen {
  title: string;
  subtitle: string;
  features: string[];
  cta: string;
}
```

**Contenu :**

- Titre : "Bienvenue sur MartialComp Mobile"
- Sous-titre : "Votre plateforme complète de gestion d'arts martiaux"
- Fonctionnalités clés :
  - Scanner QR codes pour inscriptions rapides
  - Gestion complète des organisations
  - Suivi des compétitions en temps réel
  - Portefeuille et paiements intégrés

#### **Étape 2 : Authentification**

```typescript
// Options d'authentification
interface AuthOptions {
  email: string;
  password: string;
  biometric: boolean;
  remember: boolean;
}
```

**Options :**

- **Connexion existante** : Email/mot de passe
- **Nouveau compte** : Création de compte
- **Biométrie** : Authentification par empreinte/face
- **Récupération** : Mot de passe oublié

#### **Étape 3 : Sélection d'Organisation**

```typescript
// Types d'organisations
interface OrganizationType {
  type: "club" | "federation" | "academy" | "individual";
  name: string;
  description: string;
  icon: string;
}
```

**Options :**

- **Club** : Gestion de club d'arts martiaux
- **Fédération** : Administration de fédération
- **Académie** : Centre de formation
- **Individuel** : Utilisateur personnel

#### **Étape 4 : Configuration du Profil**

```typescript
// Informations du profil
interface ProfileSetup {
  firstName: string;
  lastName: string;
  email: string;
  phone?: string;
  dateOfBirth?: string;
  disciplines: string[];
  currentGrade?: string;
}
```

**Champs :**

- **Informations personnelles** : Nom, prénom, email
- **Contact** : Téléphone (optionnel)
- **Disciplines** : Arts martiaux pratiqués
- **Grade actuel** : Niveau technique

#### **Étape 5 : Permissions**

```typescript
// Permissions requises
interface Permissions {
  camera: boolean; // Scanner QR codes
  notifications: boolean; // Notifications push
  location: boolean; // Localisation (optionnel)
  biometrics: boolean; // Authentification biométrique
}
```

**Explications :**

- **Caméra** : "Nécessaire pour scanner les QR codes"
- **Notifications** : "Recevez les alertes importantes"
- **Localisation** : "Trouvez les clubs près de chez vous"
- **Biométrie** : "Connexion rapide et sécurisée"

#### **Étape 6 : Tutoriel Interactif**

```typescript
// Étapes du tutoriel
interface TutorialStep {
  id: string;
  title: string;
  description: string;
  action: string;
  screen: string;
}
```

**Étapes :**

1. **Scanner QR Code** : "Scannez un QR code pour vous inscrire"
2. **Navigation** : "Explorez les différentes sections"
3. **Profil** : "Personnalisez votre profil"
4. **Organisations** : "Découvrez les organisations"

#### **Étape 7 : Configuration Financière**

```typescript
// Configuration financière
interface FinancialSetup {
  currency: string;
  paymentMethods: string[];
  autoRenew: boolean;
  notifications: boolean;
}
```

**Options :**

- **Devise** : EUR, USD, etc.
- **Méthodes de paiement** : Cartes, virements
- **Renouvellement automatique** : Oui/Non
- **Notifications de paiement** : Oui/Non

#### **Étape 8 : Finalisation**

```typescript
// Écran de finalisation
interface CompletionScreen {
  message: string;
  nextSteps: string[];
  support: string;
}
```

**Contenu :**

- **Message de félicitations** : "Votre compte est prêt !"
- **Prochaines étapes** :
  - "Scannez votre premier QR code"
  - "Rejoignez une organisation"
  - "Explorez les compétitions"
- **Support** : "Besoin d'aide ? Contactez-nous"

### Interface Utilisateur de l'Onboarding

#### **Design Principles**

- **Simplicité** : Interface claire et intuitive
- **Progression** : Indicateur de progression visible
- **Flexibilité** : Possibilité de passer des étapes
- **Accessibilité** : Support des lecteurs d'écran

#### **Composants UI**

```typescript
// Composants d'onboarding
interface OnboardingComponents {
  ProgressBar: React.FC<{ current: number; total: number }>;
  StepIndicator: React.FC<{ steps: string[]; current: number }>;
  FeatureCard: React.FC<{ title: string; description: string; icon: string }>;
  PermissionRequest: React.FC<{ permission: string; description: string }>;
}
```

#### **Animations et Transitions**

- **Transitions fluides** entre les étapes
- **Animations d'entrée** pour les éléments
- **Feedback visuel** pour les interactions
- **Chargement progressif** des données

### Personnalisation de l'Onboarding

#### **Segmentation Utilisateurs**

```typescript
// Types d'utilisateurs
interface UserSegments {
  newUser: boolean;
  returningUser: boolean;
  organizationAdmin: boolean;
  individualUser: boolean;
}
```

#### **Adaptation du Contenu**

- **Nouveaux utilisateurs** : Onboarding complet
- **Utilisateurs existants** : Onboarding raccourci
- **Admins d'organisation** : Focus sur la gestion
- **Utilisateurs individuels** : Focus sur le profil

#### **A/B Testing**

- **Variantes d'onboarding** : Test de différentes approches
- **Métriques** : Suivi des performances
- **Optimisation** : Amélioration continue

### Intégration avec l'API

#### **Endpoints d'Onboarding**

```typescript
// API endpoints
const ONBOARDING_ENDPOINTS = {
  START: "/onboarding/start/",
  PROGRESS: "/onboarding/progress/",
  COMPLETE: "/onboarding/complete/",
  SKIP: "/onboarding/skip/",
  RESET: "/onboarding/reset/",
};
```

#### **Données d'Onboarding**

```typescript
// Structure des données
interface OnboardingData {
  userId: string;
  currentStep: number;
  completedSteps: number[];
  skippedSteps: number[];
  preferences: OnboardingPreferences;
  startDate: string;
  completionDate?: string;
}
```

---

## 🔌 API et Services

### Architecture API

#### **Base URL**

```typescript
const API_CONFIG = {
  PRODUCTION: "https://martialcomp.com/api/v1",
  STAGING: "https://staging.martialcomp.com/api/v1",
  DEVELOPMENT: "http://localhost:8000/api/v1",
};
```

#### **Authentification**

```typescript
// Headers d'authentification
const AUTH_HEADERS = {
  Authorization: `Bearer ${accessToken}`,
  "Content-Type": "application/json",
  Accept: "application/json",
};
```

### Services Principaux

#### **OrganizationService**

```typescript
class OrganizationService {
  // Récupération des organisations
  static async getOrganizations(): Promise<Organization[]>;

  // Détails d'une organisation
  static async getOrganization(id: string): Promise<Organization>;

  // Site web de l'organisation
  static async getOrganizationSite(id: string): Promise<OrganizationSite>;

  // QR codes de l'organisation
  static async getOrganizationQRCodes(
    id: string
  ): Promise<OrganizationQRCode[]>;

  // Inscription à une organisation
  static async registerWithOrganization(
    organizationId: string,
    data: OrganizationRegistrationData
  ): Promise<any>;

  // Membres de l'organisation
  static async getOrganizationMembers(
    id: string
  ): Promise<OrganizationMember[]>;

  // Statistiques de l'organisation
  static async getOrganizationStats(id: string): Promise<OrganizationStats>;
}
```

#### **FinanceService**

```typescript
class FinanceService {
  // Portefeuille de l'organisation
  static async getWallet(organizationId: string): Promise<Wallet>;

  // Transactions du portefeuille
  static async getTransactions(walletId: string): Promise<Transaction[]>;

  // Tentatives de paiement
  static async getPaymentAttempts(
    organizationId: string
  ): Promise<PaymentAttempt[]>;

  // Création d'une tentative de paiement
  static async createPaymentAttempt(
    organizationId: string,
    amount: number,
    currency: string,
    paymentMethod: string,
    description: string
  ): Promise<PaymentAttempt>;

  // Abonnement actuel
  static async getCurrentSubscription(organizationId: string): Promise<any>;

  // Upgrade d'abonnement
  static async upgradeSubscription(
    organizationId: string,
    planCode: string
  ): Promise<any>;
}
```

#### **CompetitionService**

```typescript
class CompetitionService {
  // Liste des compétitions
  static async getCompetitions(
    filters?: CompetitionFilters
  ): Promise<Competition[]>;

  // Détails d'une compétition
  static async getCompetition(id: string): Promise<Competition>;

  // Inscription à une compétition
  static async registerForCompetition(
    competitionId: string,
    practitionerId: string,
    categories: string[]
  ): Promise<CompetitionRegistration>;

  // Inscriptions à une compétition
  static async getCompetitionRegistrations(
    competitionId: string
  ): Promise<CompetitionRegistration[]>;

  // Résultats d'une compétition
  static async getCompetitionResults(
    competitionId: string
  ): Promise<CompetitionResult[]>;

  // Soumission d'un résultat
  static async submitCompetitionResult(
    competitionId: string,
    categoryId: string,
    practitionerId: string,
    rank?: number,
    score?: number,
    notes?: string
  ): Promise<CompetitionResult>;
}
```

### Gestion des Erreurs

#### **Types d'Erreurs**

```typescript
enum ErrorType {
  NETWORK = "network",
  AUTHENTICATION = "authentication",
  AUTHORIZATION = "authorization",
  VALIDATION = "validation",
  SERVER = "server",
  UNKNOWN = "unknown",
}
```

#### **Gestion des Erreurs**

```typescript
class ErrorHandler {
  // Traitement des erreurs API
  static handleApiError(error: any): void;

  // Affichage des messages d'erreur
  static showErrorMessage(message: string): void;

  // Retry automatique
  static retryRequest(request: () => Promise<any>): Promise<any>;

  // Log des erreurs
  static logError(error: any, context?: string): void;
}
```

---

## 🎨 Interface Utilisateur

### Design System

#### **Couleurs**

```typescript
const COLORS = {
  // Couleurs principales
  primary: "#007AFF",
  secondary: "#5856D6",
  success: "#34C759",
  warning: "#FF9500",
  error: "#FF3B30",

  // Couleurs neutres
  background: "#F2F2F7",
  surface: "#FFFFFF",
  text: "#000000",
  textSecondary: "#8E8E93",
  border: "#C6C6C8",

  // Couleurs spécifiques
  martialArts: "#D70015", // Rouge arts martiaux
  competition: "#FF6B35", // Orange compétition
  finance: "#34C759", // Vert finance
};
```

#### **Typographie**

```typescript
const TYPOGRAPHY = {
  // Tailles de police
  h1: { fontSize: 32, fontWeight: "bold" },
  h2: { fontSize: 24, fontWeight: "bold" },
  h3: { fontSize: 20, fontWeight: "600" },
  body: { fontSize: 16, fontWeight: "normal" },
  caption: { fontSize: 14, fontWeight: "normal" },
  small: { fontSize: 12, fontWeight: "normal" },

  // Espacement
  lineHeight: {
    h1: 40,
    h2: 32,
    h3: 28,
    body: 24,
    caption: 20,
    small: 16,
  },
};
```

#### **Espacement**

```typescript
const SPACING = {
  xs: 4,
  sm: 8,
  md: 16,
  lg: 24,
  xl: 32,
  xxl: 48,
};
```

### Composants Réutilisables

#### **Boutons**

```typescript
interface ButtonProps {
  title: string;
  onPress: () => void;
  variant?: "primary" | "secondary" | "outline" | "ghost";
  size?: "small" | "medium" | "large";
  disabled?: boolean;
  loading?: boolean;
  icon?: string;
}
```

#### **Cartes**

```typescript
interface CardProps {
  title?: string;
  subtitle?: string;
  children: React.ReactNode;
  onPress?: () => void;
  variant?: "default" | "elevated" | "outlined";
  padding?: keyof typeof SPACING;
}
```

#### **Formulaires**

```typescript
interface FormFieldProps {
  label: string;
  value: string;
  onChangeText: (text: string) => void;
  placeholder?: string;
  error?: string;
  required?: boolean;
  type?: "text" | "email" | "password" | "phone";
  icon?: string;
}
```

### Navigation

#### **Structure de Navigation**

```typescript
// Navigation principale
const MainNavigator = {
  Home: "HomeScreen",
  QRScanner: "QRScannerScreen",
  Organizations: "OrganizationsScreen",
  Competitions: "CompetitionsScreen",
  Profile: "ProfileScreen",
  Settings: "SettingsScreen",
};

// Navigation d'authentification
const AuthNavigator = {
  Login: "LoginScreen",
  Register: "RegisterScreen",
  ForgotPassword: "ForgotPasswordScreen",
  Onboarding: "OnboardingScreen",
};
```

#### **Types de Navigation**

```typescript
type RootStackParamList = {
  Auth: undefined;
  Main: undefined;
  Onboarding: undefined;
};

type MainTabParamList = {
  Home: undefined;
  QRScanner: { qrData?: string };
  Organizations: { organizationId?: string };
  Competitions: { competitionId?: string };
  Profile: undefined;
};
```

### Responsive Design

#### **Breakpoints**

```typescript
const BREAKPOINTS = {
  phone: 320,
  tablet: 768,
  desktop: 1024,
};
```

#### **Adaptation d'Écran**

```typescript
const useResponsive = () => {
  const { width } = useWindowDimensions();

  return {
    isPhone: width < BREAKPOINTS.tablet,
    isTablet: width >= BREAKPOINTS.tablet && width < BREAKPOINTS.desktop,
    isDesktop: width >= BREAKPOINTS.desktop,
  };
};
```

---

## 🔐 Sécurité et Authentification

### Système d'Authentification

#### **JWT Tokens**

```typescript
interface AuthTokens {
  accessToken: string;
  refreshToken: string;
  expiresIn: number;
  tokenType: "Bearer";
}
```

#### **Gestion des Tokens**

```typescript
class TokenManager {
  // Stockage sécurisé des tokens
  static async storeTokens(tokens: AuthTokens): Promise<void>;

  // Récupération des tokens
  static async getTokens(): Promise<AuthTokens | null>;

  // Suppression des tokens
  static async clearTokens(): Promise<void>;

  // Vérification de validité
  static isTokenValid(token: string): boolean;

  // Refresh automatique
  static async refreshTokens(): Promise<AuthTokens>;
}
```

### Chiffrement et Sécurité

#### **Chiffrement des Données**

```typescript
class EncryptionService {
  // Chiffrement des données sensibles
  static async encrypt(data: string): Promise<string>;

  // Déchiffrement des données
  static async decrypt(encryptedData: string): Promise<string>;

  // Génération de clés
  static generateKey(): string;
}
```

#### **Validation des Données**

```typescript
class ValidationService {
  // Validation des entrées utilisateur
  static validateEmail(email: string): boolean;
  static validatePassword(password: string): boolean;
  static validatePhone(phone: string): boolean;

  // Sanitisation des données
  static sanitizeInput(input: string): string;
}
```

### Permissions et Autorisations

#### **Gestion des Permissions**

```typescript
interface Permission {
  name: string;
  description: string;
  required: boolean;
  granted: boolean;
}

const PERMISSIONS = {
  CAMERA: {
    name: "camera",
    description: "Accès à la caméra pour scanner les QR codes",
    required: true,
  },
  NOTIFICATIONS: {
    name: "notifications",
    description: "Notifications push pour les alertes importantes",
    required: false,
  },
  BIOMETRICS: {
    name: "biometrics",
    description: "Authentification par empreinte digitale ou Face ID",
    required: false,
  },
};
```

#### **Vérification des Permissions**

```typescript
class PermissionService {
  // Demande de permission
  static async requestPermission(permission: Permission): Promise<boolean>;

  // Vérification du statut
  static async checkPermission(permission: string): Promise<boolean>;

  // Ouverture des paramètres
  static openSettings(): void;
}
```

---

## 🚀 Déploiement

### Configuration Expo

#### **app.json**

```json
{
  "expo": {
    "name": "MartialComp Mobile",
    "slug": "martialcomp-mobile",
    "version": "0.2.0",
    "orientation": "portrait",
    "icon": "./assets/icon.png",
    "splash": {
      "image": "./assets/splash.png",
      "resizeMode": "contain",
      "backgroundColor": "#ffffff"
    },
    "updates": {
      "fallbackToCacheTimeout": 0
    },
    "assetBundlePatterns": ["**/*"],
    "ios": {
      "supportsTablet": true,
      "bundleIdentifier": "com.martialcomp.mobile"
    },
    "android": {
      "adaptiveIcon": {
        "foregroundImage": "./assets/adaptive-icon.png",
        "backgroundColor": "#FFFFFF"
      },
      "package": "com.martialcomp.mobile"
    },
    "web": {
      "favicon": "./assets/favicon.png"
    },
    "plugins": ["expo-camera", "expo-barcode-scanner", "expo-secure-store"]
  }
}
```

#### **eas.json**

```json
{
  "cli": {
    "version": ">= 3.0.0"
  },
  "build": {
    "development": {
      "developmentClient": true,
      "distribution": "internal"
    },
    "preview": {
      "distribution": "internal"
    },
    "production": {
      "autoIncrement": true
    }
  },
  "submit": {
    "production": {}
  }
}
```

### Build et Distribution

#### **Build pour Android**

```bash
# Configuration EAS
eas build:configure

# Build pour Android
eas build --platform android --profile production

# Build pour développement
eas build --platform android --profile development
```

#### **Build pour iOS**

```bash
# Build pour iOS
eas build --platform ios --profile production

# Build pour développement
eas build --platform ios --profile development
```

#### **Soumission aux Stores**

```bash
# Soumission Android
eas submit --platform android

# Soumission iOS
eas submit --platform ios
```

### Configuration d'Environnement

#### **Variables d'Environnement**

```typescript
// .env
API_URL=https://martialcomp.com/api/v1
EXPO_PUBLIC_API_URL=https://martialcomp.com/api/v1
SENTRY_DSN=https://your-sentry-dsn
ANALYTICS_KEY=your-analytics-key
```

#### **Configuration par Environnement**

```typescript
const ENV_CONFIG = {
  development: {
    apiUrl: "http://localhost:8000/api/v1",
    enableLogs: true,
    enableAnalytics: false,
  },
  staging: {
    apiUrl: "https://staging.martialcomp.com/api/v1",
    enableLogs: true,
    enableAnalytics: true,
  },
  production: {
    apiUrl: "https://martialcomp.com/api/v1",
    enableLogs: false,
    enableAnalytics: true,
  },
};
```

### Monitoring et Analytics

#### **Sentry pour le Monitoring**

```typescript
import * as Sentry from "@sentry/react-native";

Sentry.init({
  dsn: process.env.SENTRY_DSN,
  environment: __DEV__ ? "development" : "production",
  enableAutoSessionTracking: true,
  debug: __DEV__,
});
```

#### **Analytics**

```typescript
import analytics from "@react-native-firebase/analytics";

// Événements personnalisés
analytics.logEvent("qr_code_scanned", {
  qr_type: "organization_register",
  organization_id: "123",
});
```

---

## 🔧 Maintenance

### Tests

#### **Tests Unitaires**

```typescript
// Exemple de test unitaire
describe("OrganizationService", () => {
  it("should fetch organizations successfully", async () => {
    const organizations = await OrganizationService.getOrganizations();
    expect(organizations).toBeDefined();
    expect(Array.isArray(organizations)).toBe(true);
  });
});
```

#### **Tests d'Intégration**

```typescript
// Test d'intégration API
describe("API Integration", () => {
  it("should authenticate user and fetch profile", async () => {
    const authResult = await AuthService.login(email, password);
    expect(authResult.success).toBe(true);

    const profile = await ProfileService.getProfile();
    expect(profile).toBeDefined();
  });
});
```

#### **Tests E2E**

```typescript
// Test de parcours utilisateur
describe("User Journey", () => {
  it("should complete onboarding flow", async () => {
    await element(by.id("welcome-button")).tap();
    await element(by.id("auth-email")).typeText("test@example.com");
    await element(by.id("auth-password")).typeText("password123");
    await element(by.id("login-button")).tap();

    await expect(element(by.id("home-screen"))).toBeVisible();
  });
});
```

### Performance

#### **Optimisations**

```typescript
// Lazy loading des composants
const LazyComponent = React.lazy(() => import('./HeavyComponent'));

// Memoization
const MemoizedComponent = React.memo(ExpensiveComponent);

// Optimisation des images
const OptimizedImage = ({ uri, ...props }) => (
  <Image
    source={{ uri }}
    resizeMode="cover"
    fadeDuration={0}
    {...props}
  />
);
```

#### **Monitoring des Performances**

```typescript
import { Performance } from "@react-native-firebase/perf";

// Mesure des performances
const trace = Performance.startTrace("api_request");
try {
  await apiCall();
} finally {
  trace.stop();
}
```

### Mises à Jour

#### **Système de Mises à Jour**

```typescript
import * as Updates from "expo-updates";

class UpdateService {
  // Vérification des mises à jour
  static async checkForUpdates(): Promise<boolean> {
    const update = await Updates.checkForUpdateAsync();
    return update.isAvailable;
  }

  // Application des mises à jour
  static async applyUpdate(): Promise<void> {
    await Updates.fetchUpdateAsync();
    await Updates.reloadAsync();
  }
}
```

#### **Gestion des Versions**

```typescript
const VERSION_CONFIG = {
  current: "0.2.0",
  minimum: "0.1.0",
  latest: "0.2.0",
  forceUpdate: false,
};
```

### Support et Documentation

#### **Documentation Technique**

- **Architecture** : Documentation de l'architecture
- **API** : Documentation des endpoints
- **Composants** : Documentation des composants
- **Déploiement** : Guide de déploiement

#### **Support Utilisateur**

- **FAQ** : Questions fréquentes
- **Guides** : Guides d'utilisation
- **Contact** : Support technique
- **Feedback** : Système de feedback

---

## 📊 Métriques et KPIs

### Métriques Techniques

#### **Performance**

- **Temps de chargement** : < 3 secondes
- **Taux de crash** : < 1%
- **Utilisation mémoire** : < 100MB
- **Taille de l'app** : < 50MB

#### **Qualité**

- **Couverture de tests** : > 80%
- **Bugs critiques** : 0
- **Temps de résolution** : < 24h

### Métriques Business

#### **Adoption**

- **Téléchargements** : Objectif 10k/mois
- **Utilisateurs actifs** : Objectif 5k/mois
- **Rétention 30 jours** : Objectif 60%

#### **Engagement**

- **Temps d'utilisation** : Objectif 15min/session
- **Sessions par jour** : Objectif 2.5
- **Fonctionnalités utilisées** : Objectif 3/session

---

## 🎯 Conclusion

L'application mobile MartialComp offre une expérience complète et cohérente avec la plateforme web, permettant aux utilisateurs d'accéder à toutes les fonctionnalités de gestion d'arts martiaux depuis leur appareil mobile.

### Points Clés

- **Architecture robuste** basée sur React Native et Expo
- **Fonctionnalités complètes** couvrant tous les aspects de la plateforme
- **Onboarding optimisé** pour une adoption rapide
- **Sécurité renforcée** avec authentification JWT et chiffrement
- **Performance optimisée** pour les appareils mobiles
- **Maintenance facilitée** avec tests automatisés et monitoring

### Évolutions Futures

- **Notifications push** en temps réel
- **Mode hors-ligne complet**
- **Intégration de paiements mobiles**
- **Support des tablettes**
- **Réalité augmentée** pour les compétitions

L'application mobile MartialComp représente une solution complète et moderne pour la gestion d'arts martiaux sur mobile, offrant une expérience utilisateur exceptionnelle tout en maintenant la cohérence avec l'écosystème MartialComp.
