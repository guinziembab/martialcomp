# 🚀 Commandes Rapides - Visualisation Application Mobile

## 📱 **Méthodes de Visualisation**

### **1. Expo Go (Recommandé)**

```bash
cd mobile
npm start
# ou
npx expo start
```

- **Android** : Scanner le QR code avec l'app Expo Go
- **iOS** : Scanner le QR code avec l'appareil photo

### **2. Émulateur Android**

```bash
cd mobile
npm run android
# ou
npx expo start --android
```

### **3. Simulateur iOS (Mac uniquement)**

```bash
cd mobile
npm run ios
# ou
npx expo start --ios
```

### **4. Navigateur Web**

```bash
cd mobile
npm run web
# ou
npx expo start --web
```

### **5. Tunnel WiFi**

```bash
cd mobile
npx expo start --tunnel
```

## 🛠️ **Scripts de Démarrage Rapide**

### **Windows :**

```bash
cd mobile
start-app.bat
```

### **macOS/Linux :**

```bash
cd mobile
./start-app.sh
```

## 📊 **Interface Expo**

Une fois lancé, vous verrez :

```
› Metro waiting on exp://192.168.1.100:8081
› Scan the QR code above with Expo Go (Android) or the Camera app (iOS)
› Press a │ open Android
› Press i │ open iOS simulator
› Press w │ open web
› Press r │ reload app
› Press m │ toggle menu
› Press ? │ show all commands
```

## 🔧 **Raccourcis Clavier**

- **`a`** : Ouvrir Android
- **`i`** : Ouvrir iOS
- **`w`** : Ouvrir Web
- **`r`** : Recharger l'app
- **`m`** : Menu de développement
- **`?`** : Afficher toutes les commandes

## 📱 **Installation Expo Go**

### **Android :**

- Google Play Store : "Expo Go"

### **iOS :**

- App Store : "Expo Go"

## 🚀 **Démarrage Immédiat**

Pour commencer rapidement :

```bash
cd mobile
npm start
```

Puis scanner le QR code avec votre téléphone !



