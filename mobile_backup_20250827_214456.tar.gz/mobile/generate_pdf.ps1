# Script PowerShell pour générer un PDF à partir du document Markdown
# Nécessite: Node.js et markdown-pdf

param(
  [string]$InputFile = "DOCUMENTATION_COMPLETE.md",
  [string]$OutputFile = "DOCUMENTATION_COMPLETE.pdf",
  [string]$CssFile = "pdf-style.css"
)

# Fonction pour afficher les messages avec couleurs
function Write-ColorOutput {
  param(
    [string]$Message,
    [string]$Color = "White"
  )
  Write-Host $Message -ForegroundColor $Color
}

# Fonction pour créer le fichier CSS
function Create-CSSFile {
  $cssContent = @"
body {
  font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
  line-height: 1.6;
  color: #333;
  max-width: 800px;
  margin: 0 auto;
  padding: 20px;
}

h1, h2, h3, h4, h5, h6 {
  color: #2c3e50;
  margin-top: 30px;
  margin-bottom: 15px;
}

h1 {
  font-size: 2.5em;
  border-bottom: 3px solid #3498db;
  padding-bottom: 10px;
}

h2 {
  font-size: 2em;
  border-bottom: 2px solid #3498db;
  padding-bottom: 8px;
}

h3 {
  font-size: 1.5em;
  color: #2980b9;
}

h4 {
  font-size: 1.3em;
  color: #34495e;
}

p {
  margin-bottom: 15px;
  text-align: justify;
}

ul, ol {
  margin-bottom: 15px;
  padding-left: 30px;
}

li {
  margin-bottom: 5px;
}

code {
  background-color: #f8f9fa;
  padding: 2px 6px;
  border-radius: 3px;
  font-family: 'Courier New', monospace;
  font-size: 0.9em;
}

pre {
  background-color: #f8f9fa;
  padding: 15px;
  border-radius: 5px;
  overflow-x: auto;
  border-left: 4px solid #3498db;
}

pre code {
  background-color: transparent;
  padding: 0;
}

blockquote {
  border-left: 4px solid #3498db;
  padding-left: 15px;
  margin-left: 0;
  color: #7f8c8d;
}

table {
  border-collapse: collapse;
  width: 100%;
  margin: 20px 0;
}

th, td {
  border: 1px solid #ddd;
  padding: 12px;
  text-align: left;
}

th {
  background-color: #3498db;
  color: white;
  font-weight: bold;
}

tr:nth-child(even) {
  background-color: #f2f2f2;
}

.architecture-diagram {
  text-align: center;
  margin: 20px 0;
  padding: 15px;
  background-color: #ecf0f1;
  border-radius: 5px;
}

.feature-list {
  background-color: #e8f5e8;
  padding: 15px;
  border-radius: 5px;
  margin: 15px 0;
}

.onboarding-step {
  background-color: #fff3cd;
  padding: 15px;
  border-radius: 5px;
  margin: 15px 0;
  border-left: 4px solid #ffc107;
}

.code-example {
  background-color: #f8f9fa;
  padding: 15px;
  border-radius: 5px;
  margin: 15px 0;
  border: 1px solid #dee2e6;
}

.emoji {
  font-size: 1.2em;
  margin-right: 5px;
}

.page-break {
  page-break-before: always;
}

.header {
  text-align: center;
  margin-bottom: 30px;
  padding-bottom: 20px;
  border-bottom: 2px solid #3498db;
}

.footer {
  text-align: center;
  margin-top: 30px;
  padding-top: 20px;
  border-top: 1px solid #bdc3c7;
  font-size: 0.9em;
  color: #7f8c8d;
}

.toc {
  background-color: #f8f9fa;
  padding: 20px;
  border-radius: 5px;
  margin: 20px 0;
}

.toc ul {
  list-style-type: none;
  padding-left: 0;
}

.toc li {
  margin-bottom: 8px;
}

.toc a {
  color: #3498db;
  text-decoration: none;
}

.toc a:hover {
  text-decoration: underline;
}

@media print {
  body {
    font-size: 12pt;
  }
  
  h1 { font-size: 18pt; }
  h2 { font-size: 16pt; }
  h3 { font-size: 14pt; }
  h4 { font-size: 12pt; }
  
  .page-break {
    page-break-before: always;
  }
}
"@

  Set-Content -Path $CssFile -Value $cssContent -Encoding UTF8
  Write-ColorOutput "✅ Fichier CSS créé: $CssFile" "Green"
}

# Fonction pour vérifier si Node.js est installé
function Test-NodeJS {
  try {
    $nodeVersion = node --version
    Write-ColorOutput "✅ Node.js installé: $nodeVersion" "Green"
    return $true
  }
  catch {
    Write-ColorOutput "❌ Node.js n'est pas installé" "Red"
    Write-ColorOutput "📥 Veuillez installer Node.js depuis https://nodejs.org/" "Yellow"
    return $false
  }
}

# Fonction pour vérifier si markdown-pdf est installé
function Test-MarkdownPdf {
  try {
    $markdownPdfVersion = markdown-pdf --version
    Write-ColorOutput "✅ markdown-pdf installé: $markdownPdfVersion" "Green"
    return $true
  }
  catch {
    Write-ColorOutput "❌ markdown-pdf n'est pas installé" "Red"
    Write-ColorOutput "📦 Installation de markdown-pdf..." "Yellow"
        
    try {
      npm install -g markdown-pdf
      Write-ColorOutput "✅ markdown-pdf installé avec succès" "Green"
      return $true
    }
    catch {
      Write-ColorOutput "❌ Impossible d'installer markdown-pdf" "Red"
      return $false
    }
  }
}

# Fonction pour générer le PDF
function Generate-PDF {
  param(
    [string]$InputFile,
    [string]$OutputFile,
    [string]$CssFile
  )
    
  Write-ColorOutput "🔄 Génération du PDF..." "Yellow"
    
  $command = "markdown-pdf $InputFile -o $OutputFile -c $CssFile"
  Write-ColorOutput "📝 Commande: $command" "Cyan"
    
  try {
    Invoke-Expression $command
    Write-ColorOutput "✅ PDF généré avec succès: $OutputFile" "Green"
    return $true
  }
  catch {
    Write-ColorOutput "❌ Erreur lors de la génération du PDF" "Red"
    return $false
  }
}

# Fonction principale
function Main {
  Write-ColorOutput "🚀 Début de la génération du PDF..." "Cyan"
    
  # Vérifier que le fichier Markdown existe
  if (-not (Test-Path $InputFile)) {
    Write-ColorOutput "❌ Le fichier $InputFile n'existe pas" "Red"
    exit 1
  }
    
  # Vérifier Node.js
  if (-not (Test-NodeJS)) {
    exit 1
  }
    
  # Créer le fichier CSS
  Create-CSSFile
    
  # Vérifier markdown-pdf
  if (-not (Test-MarkdownPdf)) {
    exit 1
  }
    
  # Générer le PDF
  if (Generate-PDF -InputFile $InputFile -OutputFile $OutputFile -CssFile $CssFile) {
    Write-ColorOutput "🎉 Génération terminée avec succès !" "Green"
    Write-ColorOutput "📄 Fichier PDF créé: $OutputFile" "Cyan"
        
    # Nettoyer le fichier CSS temporaire
    if (Test-Path $CssFile) {
      Remove-Item $CssFile
      Write-ColorOutput "🧹 Fichier CSS temporaire supprimé" "Yellow"
    }
        
    # Ouvrir le PDF si possible
    $openPdf = Read-Host "Voulez-vous ouvrir le PDF ? (y/n)"
    if ($openPdf -eq "y" -or $openPdf -eq "Y") {
      Start-Process $OutputFile
    }
  }
  else {
    Write-ColorOutput "❌ Échec de la génération du PDF" "Red"
    exit 1
  }
}

# Exécuter le script principal
Main 
# Nécessite: Node.js et markdown-pdf

param(
  [string]$InputFile = "DOCUMENTATION_COMPLETE.md",
  [string]$OutputFile = "DOCUMENTATION_COMPLETE.pdf",
  [string]$CssFile = "pdf-style.css"
)

# Fonction pour afficher les messages avec couleurs
function Write-ColorOutput {
  param(
    [string]$Message,
    [string]$Color = "White"
  )
  Write-Host $Message -ForegroundColor $Color
}

# Fonction pour créer le fichier CSS
function Create-CSSFile {
  $cssContent = @"
body {
  font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
  line-height: 1.6;
  color: #333;
  max-width: 800px;
  margin: 0 auto;
  padding: 20px;
}

h1, h2, h3, h4, h5, h6 {
  color: #2c3e50;
  margin-top: 30px;
  margin-bottom: 15px;
}

h1 {
  font-size: 2.5em;
  border-bottom: 3px solid #3498db;
  padding-bottom: 10px;
}

h2 {
  font-size: 2em;
  border-bottom: 2px solid #3498db;
  padding-bottom: 8px;
}

h3 {
  font-size: 1.5em;
  color: #2980b9;
}

h4 {
  font-size: 1.3em;
  color: #34495e;
}

p {
  margin-bottom: 15px;
  text-align: justify;
}

ul, ol {
  margin-bottom: 15px;
  padding-left: 30px;
}

li {
  margin-bottom: 5px;
}

code {
  background-color: #f8f9fa;
  padding: 2px 6px;
  border-radius: 3px;
  font-family: 'Courier New', monospace;
  font-size: 0.9em;
}

pre {
  background-color: #f8f9fa;
  padding: 15px;
  border-radius: 5px;
  overflow-x: auto;
  border-left: 4px solid #3498db;
}

pre code {
  background-color: transparent;
  padding: 0;
}

blockquote {
  border-left: 4px solid #3498db;
  padding-left: 15px;
  margin-left: 0;
  color: #7f8c8d;
}

table {
  border-collapse: collapse;
  width: 100%;
  margin: 20px 0;
}

th, td {
  border: 1px solid #ddd;
  padding: 12px;
  text-align: left;
}

th {
  background-color: #3498db;
  color: white;
  font-weight: bold;
}

tr:nth-child(even) {
  background-color: #f2f2f2;
}

.architecture-diagram {
  text-align: center;
  margin: 20px 0;
  padding: 15px;
  background-color: #ecf0f1;
  border-radius: 5px;
}

.feature-list {
  background-color: #e8f5e8;
  padding: 15px;
  border-radius: 5px;
  margin: 15px 0;
}

.onboarding-step {
  background-color: #fff3cd;
  padding: 15px;
  border-radius: 5px;
  margin: 15px 0;
  border-left: 4px solid #ffc107;
}

.code-example {
  background-color: #f8f9fa;
  padding: 15px;
  border-radius: 5px;
  margin: 15px 0;
  border: 1px solid #dee2e6;
}

.emoji {
  font-size: 1.2em;
  margin-right: 5px;
}

.page-break {
  page-break-before: always;
}

.header {
  text-align: center;
  margin-bottom: 30px;
  padding-bottom: 20px;
  border-bottom: 2px solid #3498db;
}

.footer {
  text-align: center;
  margin-top: 30px;
  padding-top: 20px;
  border-top: 1px solid #bdc3c7;
  font-size: 0.9em;
  color: #7f8c8d;
}

.toc {
  background-color: #f8f9fa;
  padding: 20px;
  border-radius: 5px;
  margin: 20px 0;
}

.toc ul {
  list-style-type: none;
  padding-left: 0;
}

.toc li {
  margin-bottom: 8px;
}

.toc a {
  color: #3498db;
  text-decoration: none;
}

.toc a:hover {
  text-decoration: underline;
}

@media print {
  body {
    font-size: 12pt;
  }
  
  h1 { font-size: 18pt; }
  h2 { font-size: 16pt; }
  h3 { font-size: 14pt; }
  h4 { font-size: 12pt; }
  
  .page-break {
    page-break-before: always;
  }
}
"@

  Set-Content -Path $CssFile -Value $cssContent -Encoding UTF8
  Write-ColorOutput "✅ Fichier CSS créé: $CssFile" "Green"
}

# Fonction pour vérifier si Node.js est installé
function Test-NodeJS {
  try {
    $nodeVersion = node --version
    Write-ColorOutput "✅ Node.js installé: $nodeVersion" "Green"
    return $true
  }
  catch {
    Write-ColorOutput "❌ Node.js n'est pas installé" "Red"
    Write-ColorOutput "📥 Veuillez installer Node.js depuis https://nodejs.org/" "Yellow"
    return $false
  }
}

# Fonction pour vérifier si markdown-pdf est installé
function Test-MarkdownPdf {
  try {
    $markdownPdfVersion = markdown-pdf --version
    Write-ColorOutput "✅ markdown-pdf installé: $markdownPdfVersion" "Green"
    return $true
  }
  catch {
    Write-ColorOutput "❌ markdown-pdf n'est pas installé" "Red"
    Write-ColorOutput "📦 Installation de markdown-pdf..." "Yellow"
        
    try {
      npm install -g markdown-pdf
      Write-ColorOutput "✅ markdown-pdf installé avec succès" "Green"
      return $true
    }
    catch {
      Write-ColorOutput "❌ Impossible d'installer markdown-pdf" "Red"
      return $false
    }
  }
}

# Fonction pour générer le PDF
function Generate-PDF {
  param(
    [string]$InputFile,
    [string]$OutputFile,
    [string]$CssFile
  )
    
  Write-ColorOutput "🔄 Génération du PDF..." "Yellow"
    
  $command = "markdown-pdf $InputFile -o $OutputFile -c $CssFile"
  Write-ColorOutput "📝 Commande: $command" "Cyan"
    
  try {
    Invoke-Expression $command
    Write-ColorOutput "✅ PDF généré avec succès: $OutputFile" "Green"
    return $true
  }
  catch {
    Write-ColorOutput "❌ Erreur lors de la génération du PDF" "Red"
    return $false
  }
}

# Fonction principale
function Main {
  Write-ColorOutput "🚀 Début de la génération du PDF..." "Cyan"
    
  # Vérifier que le fichier Markdown existe
  if (-not (Test-Path $InputFile)) {
    Write-ColorOutput "❌ Le fichier $InputFile n'existe pas" "Red"
    exit 1
  }
    
  # Vérifier Node.js
  if (-not (Test-NodeJS)) {
    exit 1
  }
    
  # Créer le fichier CSS
  Create-CSSFile
    
  # Vérifier markdown-pdf
  if (-not (Test-MarkdownPdf)) {
    exit 1
  }
    
  # Générer le PDF
  if (Generate-PDF -InputFile $InputFile -OutputFile $OutputFile -CssFile $CssFile) {
    Write-ColorOutput "🎉 Génération terminée avec succès !" "Green"
    Write-ColorOutput "📄 Fichier PDF créé: $OutputFile" "Cyan"
        
    # Nettoyer le fichier CSS temporaire
    if (Test-Path $CssFile) {
      Remove-Item $CssFile
      Write-ColorOutput "🧹 Fichier CSS temporaire supprimé" "Yellow"
    }
        
    # Ouvrir le PDF si possible
    $openPdf = Read-Host "Voulez-vous ouvrir le PDF ? (y/n)"
    if ($openPdf -eq "y" -or $openPdf -eq "Y") {
      Start-Process $OutputFile
    }
  }
  else {
    Write-ColorOutput "❌ Échec de la génération du PDF" "Red"
    exit 1
  }
}

# Exécuter le script principal
Main 