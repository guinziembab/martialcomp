#!/bin/bash

echo "=== Déploiement de la correction du champ Pays ==="
echo ""

# Backup du fichier actuel
echo "1. Sauvegarde du fichier actuel..."
BACKUP_FILE="onboarding.py.backup_$(date +%Y%m%d_%H%M%S)"
cp apps/competitions/forms/onboarding.py "$BACKUP_FILE"
echo "   Sauvegarde créée: $BACKUP_FILE"

# Appliquer la correction
echo "2. Application de la correction..."
cp onboarding.py apps/competitions/forms/onboarding.py
echo "   Fichier mis à jour"

# Redémarrer l'application
echo "3. Redémarrage de l'application..."
touch tmp/restart.txt 2>/dev/null || echo "   (Pas de fichier restart.txt)"

echo ""
echo "✅ Correction appliquée avec succès!"
echo ""
echo "Changements apportés:"
echo "- Le champ 'country' utilise maintenant un widget Select normal au lieu de HiddenInput"
echo "- Les utilisateurs peuvent maintenant sélectionner leur pays dans une liste déroulante"
echo "- La correction s'applique aux formulaires ClubCreationForm, FederationCreationForm et PractitionerProfileForm"
echo ""
echo "Test: Visitez /fr/competitions/onboarding/club/creation/ pour vérifier que le champ Pays est visible"
