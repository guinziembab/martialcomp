# Correction du champ Pays dans l'onboarding

## Problème
Le champ pays n'apparaît pas sur les formulaires de création de club et de fédération.
L'URL affectée: https://martialcomp.com/fr/competitions/onboarding/club/creation/

## Cause
Les formulaires utilisaient `forms.HiddenInput()` pour le widget du champ pays, le rendant invisible.

## Solution
Remplacer le widget par `forms.Select()` avec la liste des pays disponibles.

## Fichiers modifiés
- `apps/competitions/forms/onboarding.py`
  - `ClubCreationForm`: ligne 198-204
  - `FederationCreationForm`: ligne 64-70
  - `PractitionerProfileForm`: ligne 324-330

## Déploiement
```bash
cd /chemin/vers/martialcomp
tar -xzf country_field_fix_*.tar.gz
cd country_field_fix_*
./deploy.sh
```

## Vérification
1. Visitez https://martialcomp.com/fr/competitions/onboarding/club/creation/
2. Le champ "Pays" doit maintenant être visible avec une liste déroulante
3. La sélection par défaut est "Sélectionnez un pays"
4. 193 pays sont disponibles dans la liste

## Rollback
Si nécessaire, restaurez le fichier de sauvegarde:
```bash
cp onboarding.py.backup_* apps/competitions/forms/onboarding.py
```
