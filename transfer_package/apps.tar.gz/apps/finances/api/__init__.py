# Expose urlpatterns for include('apps.finances.api') by delegating to the module file
from ..api import urlpatterns  # noqa: F401