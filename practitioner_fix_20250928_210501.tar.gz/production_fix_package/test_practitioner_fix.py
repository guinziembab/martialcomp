#!/usr/bin/env python3
"""
Script de test pour vérifier que les corrections Practitioner fonctionnent
"""

import os
import sys
import django
from django.test import Client
from django.urls import reverse

# Configuration Django
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'config.settings.production')
django.setup()

def test_practitioner_urls():
    """Test des URLs practitioner pour vérifier les redirections"""
    
    print("🧪 TEST DES CORRECTIONS PRACTITIONER")
    print("=" * 50)
    
    client = Client()
    
    # URLs à tester
    test_urls = [
        '/fr/admin/competitions/practitioner/',
        '/en/admin/competitions/practitioner/',
        '/admin/competitions/practitioner/',
        '/fr/admin/competitions/practitioner/add/',
        '/fr/admin/competitions/practitioner/1/',
    ]
    
    success_count = 0
    total_tests = len(test_urls)
    
    for url in test_urls:
        print(f"\n🔍 Test de l'URL: {url}")
        
        try:
            response = client.get(url, follow=True)
            
            # Vérifier que c'est une redirection
            if response.status_code in [301, 302]:
                print(f"   ✅ Redirection détectée (status: {response.status_code})")
                print(f"   📍 Redirigé vers: {response.url}")
                success_count += 1
            elif response.status_code == 200:
                # Vérifier que ce n'est pas la page practitioner
                if 'practitioner' not in response.content.decode().lower():
                    print(f"   ✅ Page chargée sans erreur practitioner")
                    success_count += 1
                else:
                    print(f"   ❌ Page practitioner encore accessible")
            else:
                print(f"   ⚠️ Status inattendu: {response.status_code}")
                
        except Exception as e:
            print(f"   ❌ Erreur lors du test: {e}")
    
    print(f"\n📊 RÉSULTATS DU TEST")
    print("=" * 30)
    print(f"Tests réussis: {success_count}/{total_tests}")
    print(f"Taux de réussite: {(success_count/total_tests)*100:.1f}%")
    
    if success_count == total_tests:
        print("🎉 TOUS LES TESTS SONT PASSÉS!")
        return True
    else:
        print("⚠️ Certains tests ont échoué")
        return False

def test_middleware_logging():
    """Test du logging du middleware"""
    print(f"\n📝 VÉRIFICATION DU LOGGING")
    print("=" * 30)
    
    # Vérifier que le fichier de log existe
    log_file = '/var/log/django/martialcomp.log'
    if os.path.exists(log_file):
        print(f"✅ Fichier de log trouvé: {log_file}")
        
        # Lire les dernières lignes
        try:
            with open(log_file, 'r') as f:
                lines = f.readlines()
                recent_lines = lines[-10:] if len(lines) > 10 else lines
                
            print("📄 Dernières lignes du log:")
            for line in recent_lines:
                if 'practitioner' in line.lower():
                    print(f"   🔍 {line.strip()}")
        except Exception as e:
            print(f"❌ Erreur lors de la lecture du log: {e}")
    else:
        print(f"⚠️ Fichier de log non trouvé: {log_file}")

def test_admin_registration():
    """Test de la désinscription du modèle Practitioner"""
    print(f"\n🔧 VÉRIFICATION DE L'ADMIN DJANGO")
    print("=" * 35)
    
    try:
        from django.contrib import admin
        from apps.competitions.models import Practitioner
        
        # Vérifier si Practitioner est encore enregistré
        if Practitioner in admin.site._registry:
            print("❌ Practitioner est encore enregistré dans l'admin")
            return False
        else:
            print("✅ Practitioner correctement désinscrit de l'admin")
            return True
            
    except Exception as e:
        print(f"❌ Erreur lors de la vérification: {e}")
        return False

if __name__ == "__main__":
    print("🚨 TEST DES CORRECTIONS URGENTES PRACTITIONER")
    print("=" * 55)
    
    # Tests
    url_test_passed = test_practitioner_urls()
    admin_test_passed = test_admin_registration()
    test_middleware_logging()
    
    print(f"\n🏁 RÉSUMÉ FINAL")
    print("=" * 20)
    print(f"Test URLs: {'✅ PASSÉ' if url_test_passed else '❌ ÉCHOUÉ'}")
    print(f"Test Admin: {'✅ PASSÉ' if admin_test_passed else '❌ ÉCHOUÉ'}")
    
    if url_test_passed and admin_test_passed:
        print("\n🎉 TOUTES LES CORRECTIONS FONCTIONNENT!")
        sys.exit(0)
    else:
        print("\n⚠️ CERTAINES CORRECTIONS NÉCESSITENT UNE ATTENTION")
        sys.exit(1)