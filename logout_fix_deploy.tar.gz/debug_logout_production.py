#!/usr/bin/env python
"""
Script pour déboguer le problème de logout en production
"""
import os
import sys
import django

# Configuration Django
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'config.settings.production')
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
django.setup()

from django.urls import reverse, resolve
from django.conf import settings

print("=== Debug Logout Production ===\n")

# 1. Vérifier les URLs de logout
print("1. URLs de logout:")
try:
    print(f"   - account_logout: {reverse('account_logout')}")
except:
    print("   - account_logout: NON TROUVÉE")

try:
    print(f"   - competitions:logout: {reverse('competitions:logout')}")
except:
    print("   - competitions:logout: NON TROUVÉE")

# 2. Paramètres de redirection
print("\n2. Paramètres de redirection:")
print(f"   - LOGOUT_REDIRECT_URL: {getattr(settings, 'LOGOUT_REDIRECT_URL', 'Non défini')}")
print(f"   - ACCOUNT_LOGOUT_REDIRECT_URL: {getattr(settings, 'ACCOUNT_LOGOUT_REDIRECT_URL', 'Non défini')}")
print(f"   - LOGIN_URL: {settings.LOGIN_URL}")
print(f"   - LOGIN_REDIRECT_URL: {getattr(settings, 'LOGIN_REDIRECT_URL', 'Non défini')}")

# 3. Adaptateur
print("\n3. Adaptateur allauth:")
print(f"   - ACCOUNT_ADAPTER: {settings.ACCOUNT_ADAPTER}")

# 4. Test de résolution d'URL
print("\n4. Résolution de l'URL /accounts/logout/:")
try:
    match = resolve('/accounts/logout/')
    print(f"   - Vue: {match.view_name}")
    print(f"   - Fonction: {match.func.__module__}.{match.func.__name__ if hasattr(match.func, '__name__') else 'view'}")
except Exception as e:
    print(f"   - ERREUR: {str(e)}")

# 5. Sessions et middlewares
print("\n5. Configuration sessions:")
print(f"   - SESSION_COOKIE_NAME: {settings.SESSION_COOKIE_NAME}")
print(f"   - SESSION_COOKIE_DOMAIN: {getattr(settings, 'SESSION_COOKIE_DOMAIN', 'Non défini')}")
print(f"   - SESSION_EXPIRE_AT_BROWSER_CLOSE: {settings.SESSION_EXPIRE_AT_BROWSER_CLOSE}")

# 6. Middleware de redirection
print("\n6. Middlewares de redirection:")
for middleware in settings.MIDDLEWARE:
    if 'redirect' in middleware.lower() or 'auth' in middleware.lower():
        print(f"   - {middleware}")

print("\n=== Recommandations ===")
print("1. Vérifier que le lien de déconnexion utilise {% url 'account_logout' %}")
print("2. Vérifier dans le navigateur quelle URL est appelée lors du clic sur 'Déconnexion'")
print("3. Vérifier les logs Apache/Nginx pour voir la séquence de redirections")
print("4. Tester avec une session privée/incognito pour éliminer les problèmes de cache")