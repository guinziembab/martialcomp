from django.core.exceptions import PermissionDenied
from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth import login
from django.contrib import messages
from django.utils.translation import gettext_lazy as _
from django.utils import timezone
from django.views.decorators.csrf import csrf_exempt
from django.http import HttpResponse

from ...models import Club, ClubQRCode
from ...services.club_qr_service import ClubQRService
from ...forms import DirectRegistrationForm
from apps.core.isolation import OrganizationIsolationMixin, get_organization_queryset

@csrf_exempt
def direct_club_registration(request, club_id=None):
    """Inscription directe au club via QR code"""

    # Récupérer club_id depuis l'URL ou les paramètres GET
    if club_id is None:
        club_id = request.GET.get('club_id')

    if not club_id:
        messages.error(request, _("Aucun club spécifié."))
        return redirect('competitions:welcome')

    club = get_object_or_404(Club, id=club_id)
    qr_id = request.GET.get('qr')
    source = request.GET.get('source', 'qr_code')
    
    # Enregistrer le scan si un QR code est fourni
    if qr_id:
        try:
            qr_code = ClubQRCode.objects.get(id=qr_id, club=club, qr_type='registration')
            ClubQRService.record_scan(qr_code, request)
        except ClubQRCode.DoesNotExist:
            pass
    
    # Si l'utilisateur est déjà connecté, le rediriger
    if request.user.is_authenticated:
        messages.info(request, _("Vous êtes déjà connecté."))
        return redirect('competitions:club:dashboard', club_id=club.id)
    
    if request.method == 'POST':
        form = DirectRegistrationForm(request.POST)
        if form.is_valid():
            try:
                # Créer l'utilisateur
                user = form.save()
                
                # Créer le profil utilisateur
                profile = user.profile
                profile.role = 'participant'
                profile.primary_club = club
                profile.created_by_club_manager = True
                profile.save()
                
                # Connecter l'utilisateur
                login(request, user)
                
                # Enregistrer l'inscription via QR code
                if qr_id:
                    try:
                        qr_code = ClubQRCode.objects.get(id=qr_id, club=club, qr_type='registration')
                        ClubQRService.record_registration(qr_code, user)
                    except ClubQRCode.DoesNotExist:
                        pass
                
                messages.success(request, _("Inscription réussie ! Bienvenue dans le club {}.").format(club.name))
                return redirect('competitions:club:dashboard', club_id=club.id)
                
            except Exception as e:
                messages.error(request, _("Erreur lors de l'inscription : {}").format(str(e)))
    else:
        form = DirectRegistrationForm()
    
    context = {
        'club': club,
        'form': form,
        'qr_id': qr_id,
        'source': source,
        'page_title': _("Inscription au Club"),
    }
    
    return render(request, 'competitions/club/direct_registration.html', context)
