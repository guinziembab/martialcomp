"""Vue de débogage temporaire pour tester l'accès practitioners"""
from django.http import JsonResponse
from django.contrib.auth.decorators import login_required
import logging

logger = logging.getLogger(__name__)

@login_required
def debug_practitioner_access(request):
    """Vue de débogage pour comprendre le problème 403"""
    try:
        from apps.competitions.views.club.practitioners import get_user_club, manual_permission_check
        
        # Collecter les informations de débogage
        debug_info = {
            'user': request.user.username,
            'is_authenticated': request.user.is_authenticated,
            'is_superuser': request.user.is_superuser,
            'is_staff': request.user.is_staff,
            'has_organization': hasattr(request, 'user_organization'),
            'organization': str(request.user_organization) if hasattr(request, 'user_organization') else None,
        }
        
        # Tester get_user_club
        try:
            user_club = get_user_club(request)
            debug_info['user_club'] = str(user_club) if user_club else None
            debug_info['user_club_type'] = type(user_club).__name__ if user_club else None
            
            # Tester manual_permission_check si on a un club
            if user_club:
                has_permission = manual_permission_check(request.user, user_club)
                debug_info['has_permission'] = has_permission
            else:
                debug_info['has_permission'] = 'No club found'
                
        except Exception as e:
            debug_info['club_error'] = str(e)
            logger.error(f"Erreur get_user_club: {e}")
        
        # Vérifier UserProfile
        try:
            from apps.competitions.models.users import UserProfile
            profile = UserProfile.objects.filter(user=request.user).first()
            debug_info['has_profile'] = profile is not None
            if profile:
                debug_info['profile_organization'] = str(profile.organization) if profile.organization else None
                debug_info['profile_club'] = str(profile.club) if hasattr(profile, 'club') and profile.club else None
        except Exception as e:
            debug_info['profile_error'] = str(e)
            
        # Vérifier les clubs possédés
        try:
            from apps.competitions.models import Club
            owned_clubs = Club.objects.filter(owner=request.user)
            debug_info['owned_clubs_count'] = owned_clubs.count()
            debug_info['owned_clubs'] = [str(club) for club in owned_clubs[:5]]
        except Exception as e:
            debug_info['owned_clubs_error'] = str(e)
            
        return JsonResponse({
            'status': 'debug',
            'debug_info': debug_info
        })
        
    except Exception as e:
        logger.error(f"Erreur debug_practitioner_access: {e}")
        return JsonResponse({
            'status': 'error',
            'error': str(e)
        }, status=500)