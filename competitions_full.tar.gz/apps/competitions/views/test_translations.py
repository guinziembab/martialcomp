from django.core.exceptions import PermissionDenied
from django.shortcuts import render
from django.utils.translation import gettext as _
from apps.core.isolation import OrganizationIsolationMixin, get_organization_queryset

def test_translations(request):
    """Vue de test pour vérifier les traductions."""
    context = {
        'test_strings': [
            _('Accueil'),
            _('Se connecter'),
            _('Inscription'),
            _('Déconnexion'),
            _('Bienvenue'),
            _('Profil'),
            _('Compétitions'),
            _('Participants'),
            _('Administration'),
        ]
    }
    return render(request, 'test_translations.html', context) 
