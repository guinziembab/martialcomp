from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
from django.views.decorators.http import require_POST

@csrf_exempt
@require_POST
def test_language_change(request):
    """Vue de test pour vérifier que les POST fonctionnent"""
    return JsonResponse({
        'status': 'ok',
        'method': request.method,
        'language': request.POST.get('language', 'none'),
        'next': request.POST.get('next', '/'),
    })