from django.core.exceptions import PermissionDenied
# -*- coding: utf-8 -*-
"""
Page d'accueil d'urgence avec liens de connexion directs
"""
from django.http import HttpResponse
from django.views.decorators.csrf import csrf_exempt
from apps.core.isolation import OrganizationIsolationMixin, get_organization_queryset

@csrf_exempt
def emergency_home(request):
    """Page d'accueil d'urgence avec tous les liens de debug"""
    
    html = """
    <!DOCTYPE html>
    <html>
    <head>
        <title>MartialComp - Mode d'urgence</title>
        <style>
            body { font-family: Arial, sans-serif; margin: 40px; background: #f5f5f5; }
            .container { max-width: 800px; margin: 0 auto; background: white; padding: 30px; border-radius: 10px; box-shadow: 0 4px 6px rgba(0,0,0,0.1); }
            .emergency { background: #fff3cd; color: #856404; padding: 20px; border-radius: 5px; margin-bottom: 30px; border: 1px solid #ffeaa7; }
            .section { background: #f8f9fa; padding: 20px; margin: 20px 0; border-radius: 5px; border-left: 4px solid #007bff; }
            .btn { display: inline-block; background: #007bff; color: white; padding: 12px 20px; text-decoration: none; border-radius: 5px; margin: 5px; }
            .btn:hover { background: #0056b3; }
            .btn-success { background: #28a745; }
            .btn-warning { background: #ffc107; color: #212529; }
            .btn-danger { background: #dc3545; }
            .quick-links { display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 15px; margin: 20px 0; }
            .quick-link { background: #e9ecef; padding: 15px; border-radius: 5px; text-align: center; }
        </style>
    </head>
    <body>
        <div class="container">
            <h1>🚨 MartialComp - Mode d'urgence</h1>
            
            <div class="emergency">
                <h3>⚠️ Mode d'urgence activé</h3>
                <p>Des problèmes de CSRF empêchent les connexions normales. Utilisez les liens ci-dessous pour accéder au système.</p>
            </div>
            
            <div class="section">
                <h3>🚀 Connexion ultra-rapide (sans mot de passe)</h3>
                <div class="quick-links">
                    <div class="quick-link">
                        <h4>COACH1</h4>
                        <a href="/competitions/quick-coach1/" class="btn btn-success">Connexion COACH1</a>
                    </div>
                    <div class="quick-link">
                        <h4>COACH2</h4>
                        <a href="/competitions/quick-coach2/" class="btn btn-success">Connexion COACH2</a>
                    </div>
                </div>
            </div>
            
            <div class="section">
                <h3>🔐 Connexion avec mot de passe</h3>
                <p>Formulaire de login d'urgence sans vérification CSRF :</p>
                <a href="/competitions/emergency-login/" class="btn">Login d'urgence</a>
            </div>
            
            <div class="section">
                <h3>🔗 Liens directs</h3>
                <div class="quick-links">
                    <div class="quick-link">
                        <h4>Dashboards</h4>
                        <a href="/competitions/dashboard/" class="btn">Dashboard général</a><br>
                        <a href="/competitions/dashboard/coach/" class="btn">Dashboard coach</a><br>
                        <a href="/competitions/dashboard/spectator/" class="btn">Dashboard spectateur</a>
                    </div>
                    <div class="quick-link">
                        <h4>Admin</h4>
                        <a href="/admin/" class="btn btn-warning">Admin Django</a>
                    </div>
                </div>
            </div>
            
            <div class="section">
                <h3>🔧 Debug & Test</h3>
                <p>Pour tester le routage dans le shell Django :</p>
                <code>
                    python manage.py shell<br>
                    exec(open('test_connexion_urgence.py').read())
                </code>
            </div>
            
            <div class="section">
                <h3>📋 État du système</h3>
                <ul>
                    <li>✅ Mode d'urgence actif</li>
                    <li>⚠️ CSRF désactivé temporairement</li>
                    <li>✅ Vue coach d'urgence active</li>
                    <li>✅ Routage coach corrigé</li>
                </ul>
            </div>
            
            <p style="text-align: center; margin-top: 30px;">
                <a href="/accounts/login/" class="btn btn-danger">← Retour au login normal</a>
            </p>
        </div>
    </body>
    </html>
    """
    return HttpResponse(html)