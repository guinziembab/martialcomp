from django.core.exceptions import PermissionDenied

from django.shortcuts import render
from django.utils.translation import gettext as _
from django.utils import translation
from apps.core.isolation import OrganizationIsolationMixin, get_organization_queryset

def test_translations_enhanced(request):
    """Vue de test améliorée pour vérifier les traductions."""
    
    # Activer la langue de la requête
    if hasattr(request, 'LANGUAGE_CODE'):
        translation.activate(request.LANGUAGE_CODE)
    
    context = {
        'test_strings': [
            _('Accueil'),
            _('Se connecter'),
            _('Inscription'),
            _('Déconnexion'),
            _('Bienvenue'),
            _('Profil'),
            _('Compétitions'),
            _('Participants'),
            _('Administration'),
        ],
        'current_language': translation.get_language(),
        'available_languages': [
            ('fr', 'Français'),
            ('en', 'English'),
            ('es', 'Español'),
            ('de', 'Deutsch'),
            ('it', 'Italiano'),
        ]
    }
    return render(request, 'test_translations_enhanced.html', context)

