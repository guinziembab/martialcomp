# competitions/models/__init__.py

# Réorganisation des importations pour éviter les dépendances circulaires

# 1. D'abord les modèles fondamentaux (sans dépendances)
from .discipline import Discipline

from apps.organizations.models import Organization, OrganizationMember, OrganizationRole
from .club import Club
from .federations import Federation

# 2. Ensuite les modèles liés aux utilisateurs
from .users import UserProfile
from .practitioners import Practitioner, PractitionerTransfer, create_user_for_practitioner
from .qualifications import PractitionerQualification, PractitionerDiscipline
from .medical import MedicalRecord, MedicalCertificate
from .membership import Membership, License

# Modèles pour les coaches multi-disciplines
try:
    from .coach_profile import CoachProfile, DisciplineExpertise, TeachingSchedule, CoachAchievement
except ImportError:
    CoachProfile = None
    DisciplineExpertise = None
    TeachingSchedule = None
    CoachAchievement = None

# 3. Puis les modèles de compétition
from .competitions import Competition, CompetitionType, CompetitionRole

# 4. Import des modèles de catégories
from .categories import CategoryTemplate, CompetitionCategory

# Import tardif pour éviter les imports circulaires
# Les modèles grades seront importés quand nécessaire dans les vues/formulaires

# 5. Les modèles de registration
from .registrations import CompetitionRegistration, JudgeCompetitionAssignment

# 6. Puis les modèles de participation qui dépendent des catégories
try:
    from .competitions import ParticipantCategoryRegistration
except ImportError:
    ParticipantCategoryRegistration = None

# 7. Ensuite les modèles de juges
try:
    from .judges import Judge, JudgeQualification, QUALIFICATION_LEVELS, JudgeTechnicalApplication, JudgeAssignment
except ImportError:
    # Import ce qui est disponible
    try:
        from .judges import Judge, JudgeQualification, QUALIFICATION_LEVELS, JudgeTechnicalApplication
        JudgeAssignment = None
    except ImportError:
        Judge = None
        JudgeQualification = None
        QUALIFICATION_LEVELS = None
        JudgeTechnicalApplication = None
        JudgeAssignment = None

# 7.1 Modèle de juges ad-hoc (temporaires/bénévoles)
try:
    from .adhoc_judges import AdHocJudge
except ImportError:
    AdHocJudge = None

# 8. Import du modèle JudgeTraining pour les formations
# Note: Ces modèles semblent Ãªtre dans un autre fichier
try:
    from .judge_training import JudgeTraining, JudgeTrainingRegistration
except ImportError:
    JudgeTraining = None
    JudgeTrainingRegistration = None

from .administrators import FederationAdministrator, ClubAdministrator

# 8.1 Nouveaux modèles de rôles organisationnels (système de permissions granulaires)
try:
    from .organizational_roles import OrganizationalRole, ClubMember, FederationMember, MemberRoleHistory
except ImportError:
    OrganizationalRole = None
    ClubMember = None
    FederationMember = None
    MemberRoleHistory = None

# 9. Les modèles de match
from .match import Match

# 9.1 Les modèles de combat
try:
    from .combat import (
        TeamConfiguration,  # Sprint 1: Config équipes (N+M titulaires/remplaçants)
        CombatConfiguration,
        Equipe,
        MembreEquipe,
        Poule,
        Combat,
        ActionCombat,
        Entente,     # Sprint 2: Prêt de joueurs (REQ-06)
        TeamMerge,   # Sprint 2: Fusion d'équipes (REQ-07)
        PhaseFinale,        # Sprint 3: Phase finale (REQ-05)
        CombatPhaseFinale,  # Sprint 3: Combat de phase finale
        PodiumEquipe,       # Sprint 3: Podium équipe complet
        AireCombat,         # Mode Kiosque: Aires de combat multi-tatami
        AireCombatSession,  # Mode Kiosque: Sessions d'aires
    )
except ImportError:
    TeamConfiguration = None
    CombatConfiguration = None
    Equipe = None
    MembreEquipe = None
    Poule = None
    Combat = None
    ActionCombat = None
    Entente = None
    TeamMerge = None
    PhaseFinale = None
    CombatPhaseFinale = None
    PodiumEquipe = None
    AireCombat = None
    AireCombatSession = None

# 10. Les modèles de notation technique
try:
    from .technical_scoring import (
        ScoringCriterion, 
        Performance, 
        Score, 
        JudgeSubmissionStatus,
        JudgeSettings,
        JudgeApplication,
        TechnicalPerformance,
        ScoringConfiguration,
        TechnicalScore,
        CompetitionRanking
    )
    
    # Import des modèles renommés de scoring_results pour éviter les conflits
    try:
        from .scoring_results import (
            TechnicalPerformanceResult,
            TechnicalScoreResult,
            JudgeSubmissionStatusResult,
            CompetitionResult,
            PerformanceResult,
            CategoryRanking,
            RankingEntry,
            PodiumEntry
        )
    except ImportError:
        TechnicalPerformanceResult = None
        TechnicalScoreResult = None
        JudgeSubmissionStatusResult = None
        CompetitionResult = None
        PerformanceResult = None
        CategoryRanking = None
        RankingEntry = None
        PodiumEntry = None
except ImportError:
    try:
        from .technical_scoring import (
            ScoringCriterion, 
            Performance, 
            Score, 
            JudgeSubmissionStatus,
            JudgeSettings,
            JudgeApplication,
            TechnicalPerformance,
            ScoringConfiguration,
            TechnicalScore
        )
        CompetitionRanking = None
        TechnicalPerformanceResult = None
        TechnicalScoreResult = None
        JudgeSubmissionStatusResult = None
        CompetitionResult = None
    except ImportError:
        ScoringCriterion = None
        Performance = None
        Score = None
        JudgeSubmissionStatus = None
        JudgeSettings = None
        JudgeApplication = None
        TechnicalPerformance = None
        ScoringConfiguration = None
        TechnicalScore = None
        CompetitionRanking = None

# 10b. Session de notation (workflow juge principal)
try:
    from .session_workflow import CategorySession
except ImportError:
    CategorySession = None

# 10c. Placateur (appel des compétiteurs — accès bénévole sans compte)
try:
    from .placateur import PlacateurAccess, CompetitorCallStatus
except ImportError:
    PlacateurAccess = None
    CompetitorCallStatus = None

# 11. Les modèles de notification
try:
    from .notifications import Notification, NotificationPreference
except ImportError:
    Notification = None
    NotificationPreference = None

# 12. Les modèles de support
try:
    from .support import SupportTicket, SupportMessage, FAQ
except ImportError:
    SupportTicket = None
    SupportMessage = None
    FAQ = None

# 13. Les modèles d'événements
try:
    from .event import (
        Event,
        EventParticipant,
        # Modèles de récurrence
        EventOccurrence,
        EventOccurrenceAttendance,
        # Enums de récurrence
        EventFormat,
        RecurrenceFrequency,
        Weekday,
        OccurrenceStatus,
        AttendanceStatus,
    )
    # Importer le modèle de feedback d'événement
    try:
        from .event_feedback import EventFeedback
    except ImportError:
        EventFeedback = None
except ImportError:
    Event = None
    EventParticipant = None
    EventOccurrence = None
    EventOccurrenceAttendance = None
    EventFormat = None
    RecurrenceFrequency = None
    Weekday = None
    OccurrenceStatus = None
    AttendanceStatus = None

# 14. Les modèles de planification d'événements
try:
    from .event_planning import EventPoll, PollOption, PollResponse, EventReminder, EventStatistics
except ImportError:
    EventPoll = None
    PollOption = None
    PollResponse = None
    EventReminder = None
    EventStatistics = None

# 12. Références aux modèles de grades de l'application 'grades'
# Note: Nous avons déjÃ  essayé d'importer ces modèles plus haut, donc pas besoin de répéter
GradeSystem = GradingSystem if 'GradingSystem' in locals() else None  # Alias pour compatibilité
GradeHistory = PractitionerGrade if 'PractitionerGrade' in locals() else None  # Alias pour compatibilité

# 13. La gestion des certifications et examens
try:
    from .certifications import (
        JudgeCertification,
        CertificationRegistration,
        Exam,
        ExamRegistration,
        CertificateTemplate,
        IssuedCertificate,
        CertificationRequest
    )
except ImportError:
    JudgeCertification = None
    CertificationRegistration = None
    Exam = None
    ExamRegistration = None
    CertificateTemplate = None
    IssuedCertificate = None
    CertificationRequest = None

try:
    from .categories import CategoryGrade
except ImportError:
    CategoryGrade = None

try:
    from .club_requests import AffiliationRequest
except ImportError:
    AffiliationRequest = None

# SUPPRIMER les références Ã  ClubRole et UserClubRole qui semblent ne plus exister
# Ces classes ont peut-Ãªtre été remplacées par ClubAdministrator

# Exportez les modèles pour qu'ils soient disponibles via competitions.models
__all__ = [
    # Modèles fondamentaux
    'Discipline', 'Club', 'Federation',
    
    # Modèles liés aux utilisateurs
    'UserProfile', 'Practitioner', 'create_user_for_practitioner',
    
    # Modèles de qualification et médical
    'PractitionerQualification', 'PractitionerDiscipline',
    'MedicalRecord', 'MedicalCertificate',
    'Membership', 'License',
    
    # Modèles de compétition
    'Competition', 'CompetitionType', 'CompetitionRole',
    
    # Modèles de catégories
    'CategoryTemplate', 'CompetitionCategory',
    
    # Modèles de registration
    'CompetitionRegistration', 'JudgeCompetitionAssignment',
    
    # Modèles d'administration
    'FederationAdministrator', 'ClubAdministrator',

    # Nouveaux modèles de rôles organisationnels
    'OrganizationalRole', 'ClubMember', 'FederationMember', 'MemberRoleHistory',
    
    # Modèles de match
    'Match',
    
    # Modèles de combat (ajoutés conditionnellement ci-dessous),
]

# Ajout conditionnel des modèles qui pourraient ne pas exister
if CategoryGrade is not None:
    __all__.append('CategoryGrade')

if AffiliationRequest is not None:
    __all__.append('AffiliationRequest')

# Retirer JudgeCertification de __all__ car il semble ne plus exister
if CertificationRegistration is not None:
    __all__.append('CertificationRegistration')

if Exam is not None:
    __all__.append('Exam')
    
if ExamRegistration is not None:
    __all__.append('ExamRegistration')

if ParticipantCategoryRegistration is not None:
    __all__.append('ParticipantCategoryRegistration')

if Judge is not None:
    __all__.append('Judge')
    
if JudgeQualification is not None:
    __all__.append('JudgeQualification')
    
if QUALIFICATION_LEVELS is not None:
    __all__.append('QUALIFICATION_LEVELS')
    
if JudgeTechnicalApplication is not None:
    __all__.append('JudgeTechnicalApplication')

if JudgeAssignment is not None:
    __all__.append('JudgeAssignment')

if AdHocJudge is not None:
    __all__.append('AdHocJudge')

# Ajout des modèles de formation
if JudgeTraining is not None:
    __all__.append('JudgeTraining')

if JudgeTrainingRegistration is not None:
    __all__.append('JudgeTrainingRegistration')

# Ajout conditionnel des modèles de notation technique
if ScoringCriterion is not None:
    __all__.extend([
        'ScoringCriterion', 
        'Performance',
        'Score',
        'JudgeSubmissionStatus',
        'JudgeSettings',
        'JudgeApplication',
        'TechnicalPerformance',
        'ScoringConfiguration',
        'TechnicalScore'
    ])

if CompetitionRanking is not None:
    __all__.append('CompetitionRanking')
    
# Ajout des modèles renommés pour éviter les conflits
if 'TechnicalPerformanceResult' in locals():
    __all__.append('TechnicalPerformanceResult')
    
if 'TechnicalScoreResult' in locals():
    __all__.append('TechnicalScoreResult')
    
if 'JudgeSubmissionStatusResult' in locals():
    __all__.append('JudgeSubmissionStatusResult')
    
if 'CompetitionResult' in locals():
    __all__.append('CompetitionResult')
    
# Ajout des autres entités de scoring_results.py
if 'PerformanceResult' in locals():
    __all__.append('PerformanceResult')
    
if 'CategoryRanking' in locals():
    __all__.append('CategoryRanking')
    
if 'RankingEntry' in locals():
    __all__.append('RankingEntry')

if 'PodiumEntry' in locals() and PodiumEntry is not None:
    __all__.append('PodiumEntry')

if Notification is not None:
    __all__.append('Notification')
    
if NotificationPreference is not None:
    __all__.append('NotificationPreference')
    
# Ajout des modèles de support
if SupportTicket is not None:
    __all__.append('SupportTicket')
    
if SupportMessage is not None:
    __all__.append('SupportMessage')
    
if FAQ is not None:
    __all__.append('FAQ')
    
# Ajout des modèles d'événements
if Event is not None:
    __all__.append('Event')

if EventParticipant is not None:
    __all__.append('EventParticipant')

if EventFeedback is not None:
    __all__.append('EventFeedback')

# Ajout des modèles de récurrence d'événements
if EventOccurrence is not None:
    __all__.append('EventOccurrence')

if EventOccurrenceAttendance is not None:
    __all__.append('EventOccurrenceAttendance')

# Ajout des enums de récurrence
if EventFormat is not None:
    __all__.extend(['EventFormat', 'RecurrenceFrequency', 'Weekday', 'OccurrenceStatus', 'AttendanceStatus'])

# Ajout des modèles de planification d'événements
if EventPoll is not None:
    __all__.append('EventPoll')
    
if PollOption is not None:
    __all__.append('PollOption')
    
if PollResponse is not None:
    __all__.append('PollResponse')
    
if EventReminder is not None:
    __all__.append('EventReminder')
    
if EventStatistics is not None:
    __all__.append('EventStatistics')

# Ajout des modèles de combat
if TeamConfiguration is not None:
    __all__.append('TeamConfiguration')

if CombatConfiguration is not None:
    __all__.append('CombatConfiguration')

if Equipe is not None:
    __all__.append('Equipe')

if MembreEquipe is not None:
    __all__.append('MembreEquipe')

if Poule is not None:
    __all__.append('Poule')

if Combat is not None:
    __all__.append('Combat')

if ActionCombat is not None:
    __all__.append('ActionCombat')

# Sprint 2: Ententes et Fusions (REQ-06, REQ-07)
if Entente is not None:
    __all__.append('Entente')

if TeamMerge is not None:
    __all__.append('TeamMerge')

# Sprint 3: Phase Finale et Podium (REQ-05)
if PhaseFinale is not None:
    __all__.append('PhaseFinale')

if CombatPhaseFinale is not None:
    __all__.append('CombatPhaseFinale')

if PodiumEquipe is not None:
    __all__.append('PodiumEquipe')

# Mode Kiosque: Aires de combat
if AireCombat is not None:
    __all__.append('AireCombat')

if AireCombatSession is not None:
    __all__.append('AireCombatSession')

# 14. Les modèles d'entraÃ®nement et formation
try:
    from .training import (
        TrainingSlot,
        TrainingSession,
        TrainingReservation,
        Attendance,
        TrainingProgram,
        TrainingModule,
        TrainingExercise,
        PractitionerProgress,
        ProgramEnrollment,
        PersonalGoal,
        AbsenceDeclaration
    )
except ImportError:
    TrainingSlot = None
    TrainingSession = None
    TrainingReservation = None
    Attendance = None
    TrainingProgram = None
    TrainingModule = None
    TrainingExercise = None
    PractitionerProgress = None
    ProgramEnrollment = None
    PersonalGoal = None
    AbsenceDeclaration = None

# 15. Les modèles de communication
try:
    from .communication import (
        Conversation,
        ConversationParticipant,
        Message,
        MessageTemplate
    )
except ImportError:
    Conversation = None
    ConversationParticipant = None
    Message = None
    MessageTemplate = None

# 16. Les modèles de gestion documentaire (déplacés vers le module documents)
# Ces modèles ont été déplacés vers l'application 'documents' pour éviter les conflits
DocumentCategory = None
Document = None  
DocumentAccess = None
DocumentShare = None

# Ajout des modèles d'entraînement
if TrainingSlot is not None:
    __all__.extend([
        'TrainingSlot',
        'TrainingSession',
        'TrainingReservation',
        'Attendance',
        'TrainingProgram',
        'TrainingModule',
        'TrainingExercise',
        'PractitionerProgress',
        'ProgramEnrollment',
        'PersonalGoal'
    ])

# Ajout du modèle de déclaration d'absence
if AbsenceDeclaration is not None:
    __all__.append('AbsenceDeclaration')

# Ajout des modèles de communication
if Conversation is not None:
    __all__.extend([
        'Conversation',
        'ConversationParticipant',
        'Message',
        'MessageTemplate'
    ])

# Ajout des modèles de documents
if DocumentCategory is not None:
    __all__.extend([
        'DocumentCategory',
        'Document',
        'DocumentAccess',
        'DocumentShare'
    ])

# 17. Les modèles de QR code
try:
    from .qr_code import PractitionerQRCode, QRCodeScan
except ImportError:
    PractitionerQRCode = None
    QRCodeScan = None

# Ajout des modèles de QR code
if PractitionerQRCode is not None:
    __all__.extend([
        'PractitionerQRCode',
        'QRCodeScan'
    ])

from .organization_qr_code import OrganizationQRCode, OrganizationQRCodeScan, ReferralLink, ReferralUse

# 18. Les modèles de QR code pour les clubs
try:
    from .club_qr_code import ClubQRCode, ClubQRScan
except ImportError:
    ClubQRCode = None
    ClubQRScan = None

# Ajout des modèles de QR code pour les clubs
if ClubQRCode is not None:
    __all__.extend([
        'ClubQRCode',
        'ClubQRScan'
    ])

# Patch temporaire pour Notification.federation
try:
    from .notification_patch import patch_notification_model
    patch_notification_model()
except ImportError:
    pass

# 19. Modèles de diffusion (Broadcast Groups)
try:
    from .broadcast import BroadcastGroup, BroadcastMessage, BroadcastReceipt
    __all__.extend([
        'BroadcastGroup',
        'BroadcastMessage',
        'BroadcastReceipt'
    ])
except ImportError:
    BroadcastGroup = None
    BroadcastMessage = None
    BroadcastReceipt = None

# 20. Contact submissions
from .contact import ContactSubmission
__all__.append('ContactSubmission')

# 21. Tutoriels
try:
    from .tutorials import TutorialSection, Tutorial
except ImportError:
    TutorialSection = None
    Tutorial = None

if TutorialSection is not None:
    __all__.extend(['TutorialSection', 'Tutorial'])
