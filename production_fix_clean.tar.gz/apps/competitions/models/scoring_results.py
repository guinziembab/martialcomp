from django.db import models
from django.utils.translation import gettext_lazy as _
from django.core.validators import MinValueValidator, MaxValueValidator
from django.utils import timezone
from django.conf import settings
from django.db.models import Avg, Max, Min, Sum, F, Q

from apps.organizations.models import Organization, OrganizationMember, OrganizationRole

from . import Practitioner, CompetitionCategory


class TechnicalPerformanceResult(models.Model):
    """
    Représente une prestation technique d'un pratiquant dans une compétition.
    Par exemple, l'exécution d'un kata, d'une forme (tao), d'une démonstration technique, etc.
    Renommé de TechnicalPerformance pour éviter un conflit avec technical_scoring.py
    """
    STATUS_CHOICES = [
        ('pending', _('En attente')),
        ('ready', _('PrÃªt')),
        ('in_progress', _('En cours')),
        ('completed', _('Terminé')),
        ('disqualified', _('Disqualifié')),
        ('cancelled', _('Annulé')),
    ]
    
    # Relations principales
    practitioner = models.ForeignKey(
        'competitions.Practitioner', 
        on_delete=models.CASCADE, 
        related_name='technical_performance_results',
        verbose_name=_("Pratiquant")
    )
    category = models.ForeignKey(
        'competitions.CompetitionCategory', 
        on_delete=models.CASCADE, 
        related_name='performance_results',
        verbose_name=_("Catégorie")
    )
    competition = models.ForeignKey(
        'competitions.Competition', 
        on_delete=models.CASCADE, 
        related_name='technical_performance_results',
        verbose_name=_("Compétition")
    )
    
    # Informations sur le passage
    performance_order = models.PositiveSmallIntegerField(
        _("Ordre de passage"), 
        default=0,
        help_text=_("Ordre de passage dans la catégorie")
    )
    start_time = models.DateTimeField(_("Heure de début"), null=True, blank=True)
    end_time = models.DateTimeField(_("Heure de fin"), null=True, blank=True)
    status = models.CharField(
        _("Statut"), 
        max_length=20, 
        choices=STATUS_CHOICES, 
        default='pending'
    )
    
    # Informations supplémentaires
    notes = models.TextField(_("Notes"), blank=True)
    disqualification_reason = models.CharField(
        _("Raison de disqualification"), 
        max_length=255, 
        blank=True
    )
    
    # Suivi des modifications
    created_at = models.DateTimeField(_("Créé le"), auto_now_add=True)
    updated_at = models.DateTimeField(_("Mis Ã  jour le"), auto_now=True)
    
    class Meta:
        app_label = 'competitions'
        verbose_name = _("Prestation technique")
        verbose_name_plural = _("Prestations techniques")
        ordering = ['category', 'performance_order']
        unique_together = ['competition', 'category', 'practitioner']
    
    def __str__(self):
        return f"{self.practitioner.full_name} - {self.category.name}"
    
    def start_performance(self):
        """Démarre la prestation et enregistre l'heure de début."""
        self.start_time = timezone.now()
        self.status = 'in_progress'
        self.save(update_fields=['start_time', 'status', 'updated_at'])
    
    def end_performance(self):
        """Termine la prestation et enregistre l'heure de fin."""
        self.end_time = timezone.now()
        self.status = 'completed'
        self.save(update_fields=['end_time', 'status', 'updated_at'])
    
    def disqualify(self, reason=''):
        """Disqualifie la prestation avec une raison optionnelle."""
        self.status = 'disqualified'
        self.disqualification_reason = reason
        if not self.end_time:
            self.end_time = timezone.now()
        self.save(update_fields=['status', 'disqualification_reason', 'end_time', 'updated_at'])
    
    def cancel(self):
        """Annule la prestation."""
        self.status = 'cancelled'
        self.save(update_fields=['status', 'updated_at'])
    
    @property
    def duration(self):
        """Calcule la durée de la prestation en secondes."""
        if self.start_time and self.end_time:
            return (self.end_time - self.start_time).total_seconds()
        return None
    
    @property
    def final_score(self):
        """Calcule le score final Ã  partir des scores individuels des juges."""
        try:
            return self.result.final_score
        except PerformanceResult.DoesNotExist:
            # Si aucun résultat n'existe encore, calculer Ã  la volée
            return self.calculate_final_score()
    
    def get_judges_scores(self):
        """Récupère tous les scores des juges pour cette prestation."""
        return TechnicalScoreResult.objects.filter(performance=self)
    
    def calculate_final_score(self):
        """
        Calcule le score final en fonction des notes des juges et de la configuration.
        Cette méthode respecte les règles définies dans la configuration de notation.
        """
        # Récupérer la configuration de notation
        try:
            config = self.category.scoring_configuration
        except:
            # Si pas de configuration, utiliser des valeurs par défaut
            exclude_extreme = False
            return self._calculate_average_score(exclude_extreme)
        
        # Déterminer si on exclut les notes extrÃªmes
        exclude_extreme = config.exclude_extreme_scores
        
        # Calculer le score selon les règles de la configuration
        return self._calculate_average_score(exclude_extreme)
    
    def _calculate_average_score(self, exclude_extreme=False):
        """
        Méthode interne pour calculer le score moyen.
        Si exclude_extreme est True, exclut la note la plus haute et la plus basse.
        """
        # Récupérer tous les scores par critère et par juge
        all_scores = TechnicalScoreResult.objects.filter(performance=self)
        
        # Si pas de scores, retourner 0
        if not all_scores.exists():
            return 0
        
        # Récupérer les critères de notation
        criteria = self.category.scoring_criteria.filter(is_active=True)
        
        # Calculer pour chaque critère
        final_score = 0
        total_weight = 0
        
        for criterion in criteria:
            criterion_scores = all_scores.filter(criterion=criterion)
            
            if not criterion_scores.exists():
                continue
            
            # Déterminer le poids du critère
            weight = criterion.weight
            total_weight += weight
            
            # Calculer la moyenne pour ce critère (avec ou sans exclusion des extrÃªmes)
            if exclude_extreme and criterion_scores.count() > 2:
                # Exclure la note la plus haute et la plus basse
                max_score = criterion_scores.order_by('-value').first()
                min_score = criterion_scores.order_by('value').first()
                
                avg_value = criterion_scores.exclude(
                    id__in=[max_score.id, min_score.id]
                ).aggregate(avg=Avg('value'))['avg'] or 0
            else:
                # Moyenne simple
                avg_value = criterion_scores.aggregate(avg=Avg('value'))['avg'] or 0
            
            # Ajouter au score final pondéré
            final_score += avg_value * weight
        
        # Normaliser par le poids total
        if total_weight > 0:
            final_score = final_score / total_weight
            
        return final_score
    
    def save_result(self):
        """
        Sauvegarde le résultat final de la performance.
        Crée ou met Ã  jour l'objet PerformanceResult associé.
        """
        final_score = self.calculate_final_score()
        
        # Créer ou mettre Ã  jour le résultat
        result, created = PerformanceResult.objects.update_or_create(
            performance=self,
            defaults={
                'final_score': final_score,
                'status': 'final' if self.status == 'completed' else 'provisional'
            }
        )
        
        return result


class TechnicalScoreResult(models.Model):
    """
    Score attribué par un juge pour un critère spécifique d'une performance.
    Renommé de TechnicalScore pour éviter un conflit avec technical_scoring.py
    """
    # Relations
    performance = models.ForeignKey(
        TechnicalPerformanceResult, 
        on_delete=models.CASCADE, 
        related_name='technical_scores',
        verbose_name=_("Performance")
    )
    judge = models.ForeignKey(
        settings.AUTH_USER_MODEL, 
        on_delete=models.CASCADE, 
        related_name='technical_score_results',
        verbose_name=_("Juge")
    )
    criterion = models.ForeignKey(
        'competitions.ScoringCriterion', 
        on_delete=models.CASCADE, 
        related_name='score_results',
        verbose_name=_("Critère")
    )
    
    # Score et état
    value = models.DecimalField(
        _("Valeur"), 
        max_digits=4, 
        decimal_places=2,
        validators=[MinValueValidator(0)]
    )
    is_locked = models.BooleanField(
        _("Verrouillé"), 
        default=False,
        help_text=_("Si True, le score ne peut plus Ãªtre modifié")
    )
    is_training_score = models.BooleanField(
        _("Score d'entraÃ®nement"), 
        default=False,
        help_text=_("Si True, le score est donné par un juge en formation et ne compte pas dans le résultat")
    )
    
    # Commentaires et suivi
    comments = models.TextField(_("Commentaires"), blank=True)
    submitted_at = models.DateTimeField(_("Soumis le"), auto_now_add=True)
    updated_at = models.DateTimeField(_("Mis Ã  jour le"), auto_now=True)
    
    class Meta:
        app_label = 'competitions'
        verbose_name = _("Score technique")
        verbose_name_plural = _("Scores techniques")
        unique_together = ['performance', 'judge', 'criterion']
        ordering = ['criterion__order', 'judge__id']
    
    def __str__(self):
        return f"{self.judge.username}: {self.value} - {self.criterion.name}"
    
    def lock(self):
        """Verrouille le score pour empÃªcher toute modification ultérieure."""
        self.is_locked = True
        self.save(update_fields=['is_locked', 'updated_at'])
    
    def clean(self):
        """Validation des données."""
        from django.core.exceptions import ValidationError
        
        # Vérifier que la valeur est dans la plage autorisée pour ce critère
        if self.criterion:
            if self.value < self.criterion.min_score or self.value > self.criterion.max_score:
                raise ValidationError({
                    'value': _(f"La valeur doit Ãªtre comprise entre {self.criterion.min_score} et {self.criterion.max_score}")
                })
            
            # Vérifier que la valeur respecte le pas défini
            if self.criterion.step > 0:
                # Calculer le reste de la division pour voir si la valeur est un multiple du pas
                from decimal import Decimal
                value_decimal = Decimal(str(self.value))
                min_score_decimal = Decimal(str(self.criterion.min_score))
                step_decimal = Decimal(str(self.criterion.step))
                
                # Vérifier si (value - min_score) est un multiple du pas
                diff = value_decimal - min_score_decimal
                remainder = diff % step_decimal
                
                # Tolérance pour les erreurs d'arrondi
                tolerance = Decimal('0.001')
                
                if remainder > tolerance and abs(remainder - step_decimal) > tolerance:
                    raise ValidationError({
                        'value': _(f"La valeur doit Ãªtre un multiple de {self.criterion.step} Ã  partir de {self.criterion.min_score}")
                    })


class PerformanceResult(models.Model):
    """
    Résultat final d'une performance technique.
    Stocke le score final et le classement.
    """
    STATUS_CHOICES = [
        ('provisional', _('Provisoire')),
        ('final', _('Final')),
        ('disputed', _('Contesté')),
        ('corrected', _('Corrigé')),
    ]
    
    # Relations
    performance = models.OneToOneField(
        TechnicalPerformanceResult, 
        on_delete=models.CASCADE, 
        related_name='result',
        verbose_name=_("Performance")
    )
    
    # Résultats
    final_score = models.DecimalField(
        _("Score final"), 
        max_digits=5, 
        decimal_places=2
    )
    rank = models.PositiveSmallIntegerField(
        _("Classement"), 
        null=True, 
        blank=True
    )
    status = models.CharField(
        _("Statut"), 
        max_length=20, 
        choices=STATUS_CHOICES, 
        default='provisional'
    )
    
    # Informations supplémentaires
    notes = models.TextField(_("Notes"), blank=True)
    is_tie = models.BooleanField(
        _("Ex-Ã¦quo"), 
        default=False
    )
    
    # Suivi des modifications
    created_at = models.DateTimeField(_("Créé le"), auto_now_add=True)
    updated_at = models.DateTimeField(_("Mis Ã  jour le"), auto_now=True)
    validated_by = models.ForeignKey(
        settings.AUTH_USER_MODEL, 
        on_delete=models.SET_NULL, 
        null=True, 
        blank=True,
        related_name='validated_results',
        verbose_name=_("Validé par")
    )
    validated_at = models.DateTimeField(_("Validé le"), null=True, blank=True)
    
    class Meta:
        app_label = 'competitions'
        verbose_name = _("Résultat de performance")
        verbose_name_plural = _("Résultats de performances")
        ordering = ['-final_score']
    
    def __str__(self):
        return f"{self.performance.practitioner.full_name}: {self.final_score}"
    
    def validate(self, user):
        """Valide le résultat final."""
        self.status = 'final'
        self.validated_by = user
        self.validated_at = timezone.now()
        self.save(update_fields=['status', 'validated_by', 'validated_at', 'updated_at'])
    
    def dispute(self, reason=''):
        """Marque le résultat comme contesté."""
        self.status = 'disputed'
        if reason:
            self.notes = f"{self.notes}\nContestation: {reason}"
        self.save(update_fields=['status', 'notes', 'updated_at'])
    
    def correct(self, new_score, user, reason=''):
        """Corrige le score final après une contestation."""
        old_score = self.final_score
        self.final_score = new_score
        self.status = 'corrected'
        self.validated_by = user
        self.validated_at = timezone.now()
        
        if reason:
            self.notes = f"{self.notes}\nCorrection de {old_score} Ã  {new_score}: {reason}"
        
        self.save(update_fields=['final_score', 'status', 'validated_by', 'validated_at', 'notes', 'updated_at'])


class CategoryRanking(models.Model):
    """
    Classement final d'une catégorie de compétition.
    Stocke les rangs finaux de tous les participants d'une catégorie.
    """
    # Relations
    category = models.ForeignKey(
        'competitions.CompetitionCategory', 
        on_delete=models.CASCADE, 
        related_name='category_rankings',
        verbose_name=_("Catégorie")
    )
    competition = models.ForeignKey(
        'competitions.Competition', 
        on_delete=models.CASCADE, 
        related_name='category_rankings',
        verbose_name=_("Compétition")
    )
    
    # Meta-informations
    is_published = models.BooleanField(
        _("Publié"), 
        default=False,
        help_text=_("Si True, le classement est visible par le public")
    )
    is_final = models.BooleanField(
        _("Final"), 
        default=False,
        help_text=_("Si True, le classement est considéré comme définitif")
    )
    generated_at = models.DateTimeField(_("Généré le"), auto_now=True)
    published_at = models.DateTimeField(_("Publié le"), null=True, blank=True)
    
    # Suivi
    created_by = models.ForeignKey(
        settings.AUTH_USER_MODEL, 
        on_delete=models.SET_NULL, 
        null=True, 
        blank=True,
        related_name='created_rankings',
        verbose_name=_("Créé par")
    )
    
    class Meta:
        app_label = 'competitions'
        verbose_name = _("Classement de catégorie")
        verbose_name_plural = _("Classements de catégories")
        unique_together = ['category', 'competition']
    
    def __str__(self):
        return f"Classement - {self.category.name} ({self.competition.title})"
    
    def publish(self, user=None):
        """Publie le classement et l'horodate."""
        self.is_published = True
        self.published_at = timezone.now()
        self.save(update_fields=['is_published', 'published_at'])
    
    def finalize(self, user=None):
        """Marque le classement comme final."""
        self.is_final = True
        self.save(update_fields=['is_final'])
    
    def generate_ranking(self):
        """
        Génère le classement Ã  partir des résultats.
        Crée ou met Ã  jour les entrées RankingEntry pour chaque participant.
        """
        # Obtenir la configuration de notation pour savoir si on autorise les ex-Ã¦quo
        try:
            config = self.category.scoring_configuration
            allow_ties = config.allow_ties
        except:
            # Valeur par défaut si pas de configuration
            allow_ties = True
        
        # Récupérer tous les résultats pour cette catégorie
        results = PerformanceResult.objects.filter(
            performance__category=self.category,
            performance__competition=self.competition,
            performance__status='completed'  # Ne prendre que les performances terminées
        ).select_related('performance__practitioner').order_by('-final_score')
        
        # Si pas de résultats, ne rien faire
        if not results.exists():
            return
        
        # Supprimer les entrées de classement existantes
        RankingEntry.objects.filter(ranking=self).delete()
        
        # Créer les nouvelles entrées de classement
        current_rank = 1
        previous_score = None
        entries_to_create = []
        
        for idx, result in enumerate(results):
            is_tie = False
            
            # Si le score est identique au précédent, utiliser le mÃªme rang (ex-Ã¦quo)
            if previous_score is not None and result.final_score == previous_score:
                # Si les ex-Ã¦quo sont autorisés ou si ce n'est pas pour la 3e place
                if allow_ties or current_rank != 3:
                    is_tie = True
                else:
                    # Si le score est identique mais qu'on n'autorise pas les ex-Ã¦quo pour la 3e place
                    current_rank = idx + 1
            else:
                # Nouveau score, nouveau rang
                current_rank = idx + 1
            
            # Créer l'entrée de classement
            entry = RankingEntry(
                ranking=self,
                practitioner=result.performance.practitioner,
                rank=current_rank,
                score=result.final_score,
                is_tie=is_tie,
                performance=result.performance
            )
            entries_to_create.append(entry)
            
            # Mettre Ã  jour le rang dans le résultat
            result.rank = current_rank
            result.is_tie = is_tie
            result.save(update_fields=['rank', 'is_tie'])
            
            # Mettre Ã  jour le score précédent pour la comparaison suivante
            previous_score = result.final_score
        
        # Créer toutes les entrées en une seule requÃªte
        RankingEntry.objects.bulk_create(entries_to_create)
        
        return len(entries_to_create)


class RankingEntry(models.Model):
    """
    Entrée individuelle dans un classement.
    Représente le rang d'un pratiquant dans une catégorie.
    """
    # Relations
    ranking = models.ForeignKey(
        CategoryRanking, 
        on_delete=models.CASCADE, 
        related_name='entries',
        verbose_name=_("Classement")
    )
    practitioner = models.ForeignKey(
        'competitions.Practitioner', 
        on_delete=models.CASCADE, 
        related_name='ranking_entries',
        verbose_name=_("Pratiquant")
    )
    performance = models.ForeignKey(
        TechnicalPerformanceResult, 
        on_delete=models.SET_NULL, 
        null=True,
        related_name='ranking_entries',
        verbose_name=_("Performance")
    )
    
    # Informations de classement
    rank = models.PositiveSmallIntegerField(_("Rang"))
    score = models.DecimalField(_("Score"), max_digits=5, decimal_places=2)
    is_tie = models.BooleanField(_("Ex-Ã¦quo"), default=False)
    
    # Meta-informations
    created_at = models.DateTimeField(_("Créé le"), auto_now_add=True)
    
    class Meta:
        app_label = 'competitions'
        verbose_name = _("Entrée de classement")
        verbose_name_plural = _("Entrées de classement")
        ordering = ['rank', '-score']
        unique_together = ['ranking', 'practitioner']
    
    def __str__(self):
        return f"{self.rank}. {self.practitioner.full_name} ({self.score})"


class CompetitionResult(models.Model):
    """
    Résultats d'une compétition pour un participant.
    Stocke les informations sur les résultats finaux, médailles, etc.
    
    Note: Ce modèle a été ajouté pour résoudre un problème d'importation dans participant.py
    """
    # Relations
    practitioner = models.ForeignKey(
        'competitions.Practitioner', 
        on_delete=models.CASCADE, 
        related_name='competition_results',
        verbose_name=_("Pratiquant")
    )
    competition = models.ForeignKey(
        'competitions.Competition', 
        on_delete=models.CASCADE, 
        related_name='results',
        verbose_name=_("Compétition")
    )
    category = models.ForeignKey(
        'competitions.CompetitionCategory', 
        on_delete=models.SET_NULL, 
        null=True,
        related_name='results',
        verbose_name=_("Catégorie")
    )
    
    # Données de résultat
    rank = models.PositiveSmallIntegerField(_("Classement"), null=True, blank=True)
    score = models.DecimalField(_("Score"), max_digits=5, decimal_places=2, null=True, blank=True)
    medal = models.CharField(_("Médaille"), max_length=20, blank=True, choices=[
        ('gold', _('Or')),
        ('silver', _('Argent')),
        ('bronze', _('Bronze')),
        ('none', _('Aucune'))
    ], default='none')
    
    # Métadonnées
    date = models.DateField(_("Date"), default=timezone.now)
    notes = models.TextField(_("Notes"), blank=True)
    
    class Meta:
        app_label = 'competitions'
        verbose_name = _("Résultat de compétition")
        verbose_name_plural = _("Résultats de compétition")
        ordering = ['competition', 'category', 'rank']
        unique_together = ['competition', 'category', 'practitioner']
    
    def __str__(self):
        return f"{self.practitioner.full_name} - {self.competition.title} - {'#'+str(self.rank) if self.rank else '-'}"
    
    @property
    def is_medal(self):
        """Vérifie si c'est une médaille (top 3)."""
        return self.rank is not None and self.rank <= 3


class JudgeSubmissionStatusResult(models.Model):
    """
    Suivi de l'état de soumission des notes par les juges.
    Permet de savoir si un juge a terminé d'évaluer une performance.
    Renommé de JudgeSubmissionStatus pour éviter un conflit avec technical_scoring.py
    """
    # Relations
    judge = models.ForeignKey(
        settings.AUTH_USER_MODEL, 
        on_delete=models.CASCADE, 
        related_name='submission_status_results',
        verbose_name=_("Juge")
    )
    performance = models.ForeignKey(
        TechnicalPerformanceResult, 
        on_delete=models.CASCADE, 
        related_name='submission_statuses',
        verbose_name=_("Performance")
    )
    
    # Statut
    is_submitted = models.BooleanField(_("Soumis"), default=False)
    submitted_at = models.DateTimeField(_("Soumis le"), null=True, blank=True)
    
    # Suivi
    created_at = models.DateTimeField(_("Créé le"), auto_now_add=True)
    updated_at = models.DateTimeField(_("Mis Ã  jour le"), auto_now=True)
    
    class Meta:
        app_label = 'competitions'
        verbose_name = _("Statut de soumission")
        verbose_name_plural = _("Statuts de soumission")
        unique_together = ['judge', 'performance']
    
    def __str__(self):
        status = _("Soumis") if self.is_submitted else _("En attente")
        return f"{self.judge.username} - {self.performance} : {status}"
    
    def mark_as_submitted(self):
        """Marque les notes comme soumises."""
        self.is_submitted = True
        self.submitted_at = timezone.now()
        self.save(update_fields=['is_submitted', 'submitted_at', 'updated_at'])
        
        # Verrouiller les scores associés
        TechnicalScoreResult.objects.filter(
            performance=self.performance,
            judge=self.judge
        ).update(is_locked=True)
    
    def mark_as_incomplete(self):
        """Marque les notes comme incomplètes (pour permettre des modifications)."""
        self.is_submitted = False
        self.save(update_fields=['is_submitted', 'updated_at'])
        
        # Déverrouiller les scores associés si la configuration le permet
        try:
            config = self.performance.category.scoring_configuration
            if config.allow_score_modification:
                TechnicalScoreResult.objects.filter(
                    performance=self.performance,
                    judge=self.judge
                ).update(is_locked=False)
        except:
            # Ne rien faire si pas de configuration
            pass



