# Import all admin modules to register them with the admin site
# NOTE: practitioner admin is now handled in apps/competitions/admin.py
# to avoid conflicts and Discipline.objects.get() errors

# This file serves as a central point for all admin registrations