"""
Tests pour les types de compétition
"""

from django.test import TestCase, Client
from django.urls import reverse
from django.contrib.auth import get_user_model
from django.utils.translation import activate

from apps.organizations.models import Organization
from apps.competitions.models import CompetitionType, Discipline

User = get_user_model()


class CompetitionTypeModelTest(TestCase):
    """Tests pour le modèle CompetitionType"""
    
    def setUp(self):
        """Configuration des tests"""
        self.discipline = Discipline.objects.create(
            name="Test Discipline",
            description="Discipline de test",
            is_active=True
        )
        
        self.competition_type = CompetitionType.objects.create(
            name="Test Type",
            description="Type de test",
            discipline=self.discipline,
            team_based=False,
            scoring_system='technical',
            order=1
        )
    
    def test_competition_type_creation(self):
        """Test de création d'un type de compétition"""
        self.assertEqual(self.competition_type.name, "Test Type")
        self.assertEqual(self.competition_type.scoring_system, 'technical')
        self.assertFalse(self.competition_type.team_based)
        self.assertEqual(self.competition_type.order, 1)
    
    def test_competition_type_str(self):
        """Test de la représentation string"""
        expected = "Test Type (Test Discipline)"
        self.assertEqual(str(self.competition_type), expected)
    
    def test_scoring_system_choices(self):
        """Test des choix de système de notation"""
        choices = [choice[0] for choice in CompetitionType.SCORING_SYSTEM_CHOICES]
        expected_choices = ['technical', 'combat', 'mixed', 'custom']
        self.assertEqual(choices, expected_choices)
    
    def test_team_based_validation(self):
        """Test de validation pour les compétitions par équipe"""
        # Test avec team_based=True mais sans tailles d'équipe
        competition_type = CompetitionType(
            name="Team Type",
            discipline=self.discipline,
            team_based=True,
            scoring_system='combat'
        )
        # Le modèle devrait accepter cela (validation dans le formulaire)
        competition_type.save()
        self.assertTrue(competition_type.team_based)


class CompetitionTypeViewsTest(TestCase):
    """Tests pour les vues des types de compétition"""
    
    def setUp(self):
        """Configuration des tests"""
        self.client = Client()
        self.user = User.objects.create_user(
            username='testuser',
            email='test@example.com',
            password='testpass123'
        )
        self.client.login(username='testuser', password='testpass123')
        
        self.discipline = Discipline.objects.create(
            name="Test Discipline",
            description="Discipline de test",
            is_active=True
        )
        
        self.competition_type = CompetitionType.objects.create(
            name="Test Type",
            description="Type de test",
            discipline=self.discipline,
            team_based=False,
            scoring_system='technical',
            order=1
        )
    
    def test_competition_type_list_view(self):
        """Test de la vue liste des types de compétition"""
        url = reverse('competitions:competition_types:list')
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, "Test Type")
    
    def test_competition_type_create_view(self):
        """Test de la vue création d'un type de compétition"""
        url = reverse('competitions:competition_types:create')
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, "Créer un type de compétition")
    
    def test_competition_type_detail_view(self):
        """Test de la vue détail d'un type de compétition"""
        url = reverse('competitions:competition_types:detail', args=[self.competition_type.pk])
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, "Test Type")
    
    def test_competition_type_update_view(self):
        """Test de la vue modification d'un type de compétition"""
        url = reverse('competitions:competition_types:update', args=[self.competition_type.pk])
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, "Modifier le type de compétition")
    
    def test_competition_type_delete_view(self):
        """Test de la vue suppression d'un type de compétition"""
        url = reverse('competitions:competition_types:delete', args=[self.competition_type.pk])
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, "Confirmation de suppression")
    
    def test_competition_type_api_list_view(self):
        """Test de l'API liste des types de compétition"""
        url = reverse('competitions:competition_types:api_list')
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)
        self.assertJSONEqual(response.content, {
            'types': [{
                'id': self.competition_type.id,
                'name': 'Test Type',
                'description': 'Type de test',
                'scoring_system': 'technical',
                'team_based': False,
                'discipline': 'Test Discipline'
            }],
            'count': 1
        })


class CompetitionTypeFormsTest(TestCase):
    """Tests pour les formulaires des types de compétition"""
    
    def setUp(self):
        """Configuration des tests"""
        self.discipline = Discipline.objects.create(
            name="Test Discipline",
            description="Discipline de test",
            is_active=True
        )
    
    def test_competition_type_form_valid_data(self):
        """Test du formulaire avec des données valides"""
        from apps.competitions.forms import CompetitionTypeForm
        
        form_data = {
            'name': 'New Type',
            'description': 'New description',
            'discipline': self.discipline.id,
            'team_based': False,
            'scoring_system': 'technical',
            'order': 1
        }
        
        form = CompetitionTypeForm(data=form_data)
        self.assertTrue(form.is_valid())
    
    def test_competition_type_form_team_based_validation(self):
        """Test de validation pour les compétitions par équipe"""
        from apps.competitions.forms import CompetitionTypeForm
        
        form_data = {
            'name': 'Team Type',
            'description': 'Team description',
            'discipline': self.discipline.id,
            'team_based': True,
            'min_team_size': 2,
            'max_team_size': 4,
            'scoring_system': 'combat',
            'order': 1
        }
        
        form = CompetitionTypeForm(data=form_data)
        self.assertTrue(form.is_valid())
    
    def test_competition_type_form_invalid_team_sizes(self):
        """Test de validation avec des tailles d'équipe invalides"""
        from apps.competitions.forms import CompetitionTypeForm
        
        form_data = {
            'name': 'Team Type',
            'description': 'Team description',
            'discipline': self.discipline.id,
            'team_based': True,
            'min_team_size': 5,  # Plus grand que max_team_size
            'max_team_size': 3,
            'scoring_system': 'combat',
            'order': 1
        }
        
        form = CompetitionTypeForm(data=form_data)
        self.assertFalse(form.is_valid())
        self.assertIn('max_team_size', form.errors)
    
    def test_competition_type_form_unique_name_per_discipline(self):
        """Test d'unicité du nom par discipline"""
        from apps.competitions.forms import CompetitionTypeForm
        
        # Créer un type existant
        CompetitionType.objects.create(
            name="Existing Type",
            discipline=self.discipline,
            scoring_system='technical'
        )
        
        form_data = {
            'name': 'Existing Type',  # Même nom
            'description': 'Description',
            'discipline': self.discipline.id,  # Même discipline
            'scoring_system': 'combat',
            'order': 1
        }
        
        form = CompetitionTypeForm(data=form_data)
        self.assertFalse(form.is_valid())
        self.assertIn('name', form.errors)


class CompetitionTypeIntegrationTest(TestCase):
    """Tests d'intégration pour les types de compétition"""
    
    def setUp(self):
        """Configuration des tests"""
        self.client = Client()
        self.user = User.objects.create_user(
            username='testuser',
            email='test@example.com',
            password='testpass123'
        )
        self.client.login(username='testuser', password='testpass123')
        
        self.discipline = Discipline.objects.create(
            name="Test Discipline",
            description="Discipline de test",
            is_active=True
        )
    
    def test_create_competition_type_workflow(self):
        """Test du workflow complet de création d'un type de compétition"""
        # 1. Accéder à la page de création
        create_url = reverse('competitions:competition_types:create')
        response = self.client.get(create_url)
        self.assertEqual(response.status_code, 200)
        
        # 2. Soumettre le formulaire
        form_data = {
            'name': 'Integration Test Type',
            'description': 'Type créé par test d\'intégration',
            'discipline': self.discipline.id,
            'team_based': False,
            'scoring_system': 'technical',
            'order': 1
        }
        
        response = self.client.post(create_url, form_data)
        self.assertEqual(response.status_code, 302)  # Redirection après création
        
        # 3. Vérifier que le type a été créé
        self.assertTrue(CompetitionType.objects.filter(name='Integration Test Type').exists())
        
        # 4. Vérifier la redirection vers la liste
        self.assertRedirects(response, reverse('competitions:competition_types:list'))
    
    def test_update_competition_type_workflow(self):
        """Test du workflow complet de modification d'un type de compétition"""
        # 1. Créer un type de compétition
        competition_type = CompetitionType.objects.create(
            name="Original Type",
            discipline=self.discipline,
            scoring_system='technical'
        )
        
        # 2. Accéder à la page de modification
        update_url = reverse('competitions:competition_types:update', args=[competition_type.pk])
        response = self.client.get(update_url)
        self.assertEqual(response.status_code, 200)
        
        # 3. Soumettre les modifications
        form_data = {
            'name': 'Updated Type',
            'description': 'Type modifié',
            'discipline': self.discipline.id,
            'team_based': False,
            'scoring_system': 'combat',
            'order': 2
        }
        
        response = self.client.post(update_url, form_data)
        self.assertEqual(response.status_code, 302)  # Redirection après modification
        
        # 4. Vérifier que le type a été modifié
        competition_type.refresh_from_db()
        self.assertEqual(competition_type.name, 'Updated Type')
        self.assertEqual(competition_type.scoring_system, 'combat')
    
    def test_delete_competition_type_workflow(self):
        """Test du workflow complet de suppression d'un type de compétition"""
        # 1. Créer un type de compétition
        competition_type = CompetitionType.objects.create(
            name="To Delete Type",
            discipline=self.discipline,
            scoring_system='technical'
        )
        
        # 2. Accéder à la page de suppression
        delete_url = reverse('competitions:competition_types:delete', args=[competition_type.pk])
        response = self.client.get(delete_url)
        self.assertEqual(response.status_code, 200)
        
        # 3. Confirmer la suppression
        response = self.client.post(delete_url)
        self.assertEqual(response.status_code, 302)  # Redirection après suppression
        
        # 4. Vérifier que le type a été supprimé
        self.assertFalse(CompetitionType.objects.filter(name='To Delete Type').exists())