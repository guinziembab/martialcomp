"""
Tests de validation de conformité pour la plateforme MartialComp
"""

from django.test import TestCase, Client
from django.urls import reverse
from django.contrib.auth import get_user_model
from django.core.management import call_command
from django.db import connection

from apps.organizations.models import Organization
from apps.competitions.models import CompetitionType, Discipline, Competition

User = get_user_model()


class ConformityValidationTest(TestCase):
    """Tests de validation de conformité globale"""
    
    def setUp(self):
        """Configuration des tests"""
        self.client = Client()
        self.user = User.objects.create_user(
            username='testuser',
            email='test@example.com',
            password='testpass123'
        )
        self.client.login(username='testuser', password='testpass123')
        
        self.discipline = Discipline.objects.create(
            name="Test Discipline",
            description="Discipline de test",
            is_active=True
        )
    
    def test_database_schema_conformity(self):
        """Test de conformité du schéma de base de données"""
        with connection.cursor() as cursor:
            # Vérifier que le champ scoring_system existe dans CompetitionType
            cursor.execute("""
                SELECT column_name, data_type, is_nullable, column_default
                FROM information_schema.columns 
                WHERE table_name = 'competitions_competitiontype' 
                AND column_name = 'scoring_system'
            """)
            result = cursor.fetchone()
            
            self.assertIsNotNone(result, "Le champ scoring_system n'existe pas dans CompetitionType")
            self.assertEqual(result[0], 'scoring_system')
            self.assertEqual(result[1], 'character varying')
            self.assertEqual(result[2], 'NO')  # NOT NULL
            self.assertEqual(result[3], "'technical'")  # Valeur par défaut
    
    def test_model_fields_conformity(self):
        """Test de conformité des champs du modèle"""
        # Test des choix de scoring_system
        choices = [choice[0] for choice in CompetitionType.SCORING_SYSTEM_CHOICES]
        expected_choices = ['technical', 'combat', 'mixed', 'custom']
        self.assertEqual(choices, expected_choices)
        
        # Test de création avec tous les champs
        competition_type = CompetitionType.objects.create(
            name="Conformity Test",
            description="Test de conformité",
            discipline=self.discipline,
            team_based=True,
            min_team_size=2,
            max_team_size=4,
            weight_category=True,
            scoring_system='combat',
            order=1
        )
        
        self.assertEqual(competition_type.scoring_system, 'combat')
        self.assertTrue(competition_type.team_based)
        self.assertTrue(competition_type.weight_category)
    
    def test_urls_conformity(self):
        """Test de conformité des URLs"""
        # URLs des types de compétition
        urls_to_test = [
            'competitions:competition_types:list',
            'competitions:competition_types:create',
            'competitions:competition_types:api_list',
        ]
        
        for url_name in urls_to_test:
            try:
                url = reverse(url_name)
                response = self.client.get(url)
                self.assertIn(response.status_code, [200, 302], 
                            f"URL {url_name} ne répond pas correctement")
            except Exception as e:
                self.fail(f"URL {url_name} n'existe pas: {e}")
    
    def test_forms_conformity(self):
        """Test de conformité des formulaires"""
        from apps.competitions.forms import CompetitionTypeForm, CompetitionTypeFilterForm
        
        # Test du formulaire principal
        form = CompetitionTypeForm()
        self.assertIn('scoring_system', form.fields)
        self.assertIn('team_based', form.fields)
        self.assertIn('min_team_size', form.fields)
        self.assertIn('max_team_size', form.fields)
        
        # Test du formulaire de filtrage
        filter_form = CompetitionTypeFilterForm()
        self.assertIn('discipline', filter_form.fields)
        self.assertIn('scoring_system', filter_form.fields)
        self.assertIn('team_based', filter_form.fields)
        self.assertIn('search', filter_form.fields)
    
    def test_templates_conformity(self):
        """Test de conformité des templates"""
        # Créer un type de compétition pour les tests
        competition_type = CompetitionType.objects.create(
            name="Template Test",
            discipline=self.discipline,
            scoring_system='technical'
        )
        
        # Test de la liste
        response = self.client.get(reverse('competitions:competition_types:list'))
        self.assertContains(response, "Types de compétition")
        self.assertContains(response, "Nouveau type")
        
        # Test du détail
        response = self.client.get(reverse('competitions:competition_types:detail', 
                                         args=[competition_type.pk]))
        self.assertContains(response, "Template Test")
        self.assertContains(response, "Système de notation")
    
    def test_api_conformity(self):
        """Test de conformité de l'API"""
        # Créer des données de test
        CompetitionType.objects.create(
            name="API Test 1",
            discipline=self.discipline,
            scoring_system='technical'
        )
        CompetitionType.objects.create(
            name="API Test 2",
            discipline=self.discipline,
            scoring_system='combat'
        )
        
        # Test de l'API
        response = self.client.get(reverse('competitions:competition_types:api_list'))
        self.assertEqual(response.status_code, 200)
        
        data = response.json()
        self.assertIn('types', data)
        self.assertIn('count', data)
        self.assertEqual(data['count'], 2)
        
        # Vérifier la structure des données
        type_data = data['types'][0]
        required_fields = ['id', 'name', 'description', 'scoring_system', 'team_based', 'discipline']
        for field in required_fields:
            self.assertIn(field, type_data)
    
    def test_validation_rules_conformity(self):
        """Test de conformité des règles de validation"""
        from apps.competitions.forms import CompetitionTypeForm
        
        # Test de validation des tailles d'équipe
        form_data = {
            'name': 'Team Test',
            'discipline': self.discipline.id,
            'team_based': True,
            'min_team_size': 5,  # Plus grand que max
            'max_team_size': 3,
            'scoring_system': 'combat',
            'order': 1
        }
        
        form = CompetitionTypeForm(data=form_data)
        self.assertFalse(form.is_valid())
        self.assertIn('max_team_size', form.errors)
    
    def test_performance_conformity(self):
        """Test de conformité des performances"""
        import time
        
        # Créer plusieurs types de compétition
        for i in range(10):
            CompetitionType.objects.create(
                name=f"Performance Test {i}",
                discipline=self.discipline,
                scoring_system='technical'
            )
        
        # Test de performance de la liste
        start_time = time.time()
        response = self.client.get(reverse('competitions:competition_types:list'))
        end_time = time.time()
        
        self.assertEqual(response.status_code, 200)
        self.assertLess(end_time - start_time, 2.0, "La page met trop de temps à charger")
        
        # Test de performance de l'API
        start_time = time.time()
        response = self.client.get(reverse('competitions:competition_types:api_list'))
        end_time = time.time()
        
        self.assertEqual(response.status_code, 200)
        self.assertLess(end_time - start_time, 1.0, "L'API met trop de temps à répondre")
    
    def test_security_conformity(self):
        """Test de conformité de sécurité"""
        # Test d'accès non authentifié
        self.client.logout()
        
        protected_urls = [
            'competitions:competition_types:list',
            'competitions:competition_types:create',
            'competitions:competition_types:api_list',
        ]
        
        for url_name in protected_urls:
            response = self.client.get(reverse(url_name))
            self.assertIn(response.status_code, [302, 403], 
                        f"URL {url_name} n'est pas protégée")
    
    def test_internationalization_conformity(self):
        """Test de conformité de l'internationalisation"""
        from django.utils.translation import gettext as _
        
        # Test des traductions
        self.assertEqual(_("Types de compétition"), "Types de compétition")
        self.assertEqual(_("Système de notation"), "Système de notation")
        self.assertEqual(_("Technique"), "Technique")
        self.assertEqual(_("Combat"), "Combat")
    
    def test_data_integrity_conformity(self):
        """Test de conformité de l'intégrité des données"""
        # Test de contrainte d'unicité nom/discipline
        CompetitionType.objects.create(
            name="Unique Test",
            discipline=self.discipline,
            scoring_system='technical'
        )
        
        # Tentative de créer un doublon
        duplicate = CompetitionType(
            name="Unique Test",
            discipline=self.discipline,
            scoring_system='combat'
        )
        
        # Le modèle devrait permettre cela (validation dans le formulaire)
        duplicate.save()
        
        # Vérifier qu'il y a bien 2 enregistrements
        count = CompetitionType.objects.filter(
            name="Unique Test",
            discipline=self.discipline
        ).count()
        self.assertEqual(count, 2)
    
    def test_migration_conformity(self):
        """Test de conformité des migrations"""
        # Vérifier que toutes les migrations sont appliquées
        from django.db.migrations.executor import MigrationExecutor
        from django.db import connection
        
        executor = MigrationExecutor(connection)
        plan = executor.migration_plan(executor.loader.graph.leaf_nodes())
        self.assertEqual(len(plan), 0, "Il y a des migrations non appliquées")
    
    def test_error_handling_conformity(self):
        """Test de conformité de la gestion d'erreurs"""
        # Test d'accès à un type inexistant
        response = self.client.get(reverse('competitions:competition_types:detail', args=[99999]))
        self.assertEqual(response.status_code, 404)
        
        # Test de soumission de formulaire invalide
        form_data = {
            'name': '',  # Nom vide
            'discipline': self.discipline.id,
            'scoring_system': 'invalid_choice',  # Choix invalide
        }
        
        response = self.client.post(reverse('competitions:competition_types:create'), form_data)
        self.assertEqual(response.status_code, 200)  # Retour au formulaire avec erreurs
        self.assertContains(response, "Ce champ est obligatoire")