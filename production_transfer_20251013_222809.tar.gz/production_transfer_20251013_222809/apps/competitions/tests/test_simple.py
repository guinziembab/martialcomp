"""
Tests simples pour vérifier le fonctionnement de base
"""

from django.test import TestCase
from django.contrib.auth import get_user_model

User = get_user_model()


class SimpleTest(TestCase):
    """Tests simples de base"""
    
    def test_basic_functionality(self):
        """Test de fonctionnalité de base"""
        self.assertTrue(True)
    
    def test_user_creation(self):
        """Test de création d'utilisateur"""
        user = User.objects.create_user(
            username='testuser',
            email='test@example.com',
            password='testpass123'
        )
        self.assertEqual(user.username, 'testuser')
        self.assertEqual(user.email, 'test@example.com')
    
    def test_database_connection(self):
        """Test de connexion à la base de données"""
        from django.db import connection
        with connection.cursor() as cursor:
            cursor.execute("SELECT 1")
            result = cursor.fetchone()
            self.assertEqual(result[0], 1)